-- 为文章表添加SEO字段
ALTER TABLE posts ADD COLUMN IF NOT EXISTS seo_title VARCHAR(100);
ALTER TABLE posts ADD COLUMN IF NOT EXISTS seo_description TEXT;
ALTER TABLE posts ADD COLUMN IF NOT EXISTS seo_keywords VARCHAR(255);

-- 添加评论
COMMENT ON COLUMN posts.seo_title IS 'SEO标题';
COMMENT ON COLUMN posts.seo_description IS 'SEO描述';
COMMENT ON COLUMN posts.seo_keywords IS 'SEO关键词';
