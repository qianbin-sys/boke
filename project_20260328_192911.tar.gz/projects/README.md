# WordPress风格博客系统

基于 Next.js 16 和 Supabase 构建的WordPress风格博客系统，支持文章管理、分类管理、用户管理、支付接口配置、付费阅读、会员订阅及AI智能写作功能。

## 技术栈

- **Framework**: Next.js 16 (App Router)
- **Core**: React 19
- **Language**: TypeScript 5
- **UI 组件**: shadcn/ui (基于 Radix UI)
- **Styling**: Tailwind CSS 4
- **Database**: Supabase (PostgreSQL)
- **Auth**: JWT (jose) + bcrypt
- **Storage**: S3 对象存储
- **LLM**: coze-coding-dev-sdk
- **Payment**: alipay-sdk 4.14.0

---

## 目录

- [快速开始](#快速开始)
- [环境变量配置](#环境变量配置)
- [部署指南](#部署指南)
- [项目结构](#项目结构)
- [API接口](#api接口)
- [开发规范](#开发规范)

---

## 快速开始

### 前置要求

- Node.js 20+ (推荐 24+)
- pnpm 9+
- Supabase 账户（用于数据库）
- 支付宝商户账户（可选，用于支付功能）

### 安装步骤

#### 1. 克隆项目

```bash
git clone <repository-url>
cd projects
```

#### 2. 安装依赖

```bash
pnpm install
```

#### 3. 配置环境变量

创建 `.env.local` 文件（开发环境）或配置系统环境变量：

```bash
# 复制示例配置（如果有的话）
cp .env.example .env.local
```

**必需的环境变量**：

```env
# Supabase 数据库配置（必需）
COZE_SUPABASE_URL=https://your-project.supabase.co
COZE_SUPABASE_ANON_KEY=your-anon-key

# JWT 密钥（必需，生产环境请使用强密码）
JWT_SECRET=your-secure-jwt-secret-key

# 对象存储配置（必需，用于图片上传）
COZE_BUCKET_ENDPOINT_URL=https://your-bucket.tos-cn-beijing.volces.com
COZE_BUCKET_NAME=your-bucket-name
```

#### 4. 初始化数据库

在 Supabase 后台执行数据库初始化脚本，创建必要的数据表。主要表结构包括：

- `users` - 用户表
- `posts` - 文章表
- `categories` - 分类表
- `tags` - 标签表
- `comments` - 评论表
- `membership_plans` - 会员套餐表
- `user_memberships` - 用户会员表
- `orders` - 订单表
- `payment_configs` - 支付配置表
- `settings` - 网站设置表

#### 5. 启动开发服务器

```bash
# 使用 Coze CLI（推荐）
coze dev

# 或使用 pnpm
pnpm dev
```

启动后访问 [http://localhost:5000](http://localhost:5000)

#### 6. 创建管理员账户

首次使用需要创建管理员账户：

1. 访问 `/register` 注册账户
2. 在 Supabase 后台将用户的 `role` 字段改为 `admin`
3. 访问 `/admin/login` 登录管理后台

---

## 环境变量配置

### 核心环境变量

| 变量名 | 必需 | 说明 | 示例值 |
|--------|------|------|--------|
| `COZE_SUPABASE_URL` | ✅ | Supabase 项目 URL | `https://xxx.supabase.co` |
| `COZE_SUPABASE_ANON_KEY` | ✅ | Supabase 匿名密钥 | `eyJhbGciOiJ...` |
| `JWT_SECRET` | ✅ | JWT 签名密钥 | `your-secure-secret` |
| `COZE_BUCKET_ENDPOINT_URL` | ✅ | 对象存储端点 | `https://bucket.tos-cn-beijing.volces.com` |
| `COZE_BUCKET_NAME` | ✅ | 存储桶名称 | `my-bucket` |

### 系统环境变量（沙箱环境自动注入）

| 变量名 | 说明 | 默认值 |
|--------|------|--------|
| `COZE_WORKSPACE_PATH` | 项目工作目录 | `/workspace/projects/` |
| `COZE_PROJECT_DOMAIN_DEFAULT` | 对外访问域名 | `https://xxx.dev.coze.site` |
| `DEPLOY_RUN_PORT` | 服务监听端口 | `5000` |
| `COZE_PROJECT_ENV` | 运行环境 | `DEV` / `PROD` |

### 可选环境变量

| 变量名 | 说明 | 默认值 |
|--------|------|--------|
| `PORT` | 服务端口 | `5000` |
| `NODE_ENV` | Node 环境 | `development` / `production` |

### 环境变量配置方式

#### 开发环境

在项目根目录创建 `.env.local` 文件：

```env
# .env.local
COZE_SUPABASE_URL=https://your-project.supabase.co
COZE_SUPABASE_ANON_KEY=your-anon-key
JWT_SECRET=your-jwt-secret
COZE_BUCKET_ENDPOINT_URL=https://your-bucket.tos-cn-beijing.volces.com
COZE_BUCKET_NAME=your-bucket-name
```

#### 生产环境

1. **云平台部署**：在平台控制台配置环境变量
2. **自托管部署**：在 `.env.production.local` 文件中配置
3. **Docker 部署**：通过 `-e` 参数或 `docker-compose.yml` 配置

```bash
# Docker 示例
docker run -d \
  -e COZE_SUPABASE_URL=https://xxx.supabase.co \
  -e COZE_SUPABASE_ANON_KEY=xxx \
  -e JWT_SECRET=xxx \
  -p 5000:5000 \
  your-image
```

---

## 部署指南

### 方式一：Coze 平台部署（推荐）

本项目专为 Coze 平台优化，支持一键部署。

#### 1. 构建项目

```bash
coze build
```

构建过程会：
1. 安装依赖 (`pnpm install`)
2. 构建 Next.js 项目 (`pnpm next build`)
3. 编译自定义服务器 (`pnpm tsup`)

#### 2. 启动生产服务

```bash
coze start
```

生产服务器会在端口 5000 启动。

#### 3. 部署到 Coze

在 Coze 平台配置：
1. 连接代码仓库
2. 配置环境变量
3. 设置构建命令：`bash ./scripts/build.sh`
4. 设置启动命令：`bash ./scripts/start.sh`
5. 部署！

### 方式二：Docker 部署

#### 1. 创建 Dockerfile

```dockerfile
FROM node:20-alpine

WORKDIR /app

# 安装 pnpm
RUN npm install -g pnpm

# 复制依赖文件
COPY package.json pnpm-lock.yaml ./
RUN pnpm install --frozen-lockfile

# 复制项目文件
COPY . .

# 构建
RUN pnpm build

# 暴露端口
EXPOSE 5000

# 启动
CMD ["node", "dist/server.js"]
```

#### 2. 构建镜像

```bash
docker build -t blog-system .
```

#### 3. 运行容器

```bash
docker run -d \
  -p 5000:5000 \
  -e COZE_SUPABASE_URL=xxx \
  -e COZE_SUPABASE_ANON_KEY=xxx \
  -e JWT_SECRET=xxx \
  -e COZE_BUCKET_ENDPOINT_URL=xxx \
  -e COZE_BUCKET_NAME=xxx \
  --name blog \
  blog-system
```

### 方式三：Vercel 部署

> ⚠️ 注意：本项目使用自定义服务器，部分功能在 Vercel 上可能受限。

#### 1. 导入项目

在 Vercel 控制台导入 Git 仓库

#### 2. 配置环境变量

在 Vercel 项目设置中添加所有必需的环境变量

#### 3. 部署

Vercel 会自动检测 Next.js 项目并部署

### 方式四：传统服务器部署

#### 1. 准备服务器

- Ubuntu 20.04+ 或 CentOS 8+
- Node.js 20+
- pnpm 9+
- PM2（推荐用于进程管理）

#### 2. 上传代码

```bash
# 使用 git clone 或 scp 上传代码
git clone <repository-url>
cd projects
```

#### 3. 安装依赖并构建

```bash
pnpm install
pnpm build
```

#### 4. 配置环境变量

创建 `/etc/environment` 或在启动脚本中设置环境变量

#### 5. 使用 PM2 启动

```bash
# 安装 PM2
npm install -g pm2

# 启动服务
PORT=5000 pm2 start dist/server.js --name blog

# 设置开机自启
pm2 startup
pm2 save
```

#### 6. 配置 Nginx 反向代理

```nginx
server {
    listen 80;
    server_name yourdomain.com;

    location / {
        proxy_pass http://127.0.0.1:5000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_cache_bypass $http_upgrade;
    }
}
```

---

## 项目结构

```
├── .coze                    # Coze 平台配置文件
├── scripts/                 # 构建与启动脚本
│   ├── build.sh            # 构建脚本
│   ├── dev.sh              # 开发环境启动脚本
│   ├── prepare.sh          # 预处理脚本
│   └── start.sh            # 生产环境启动脚本
├── src/
│   ├── app/                # 页面路由与布局
│   │   ├── account/        # 用户账户页面（会员、订单）
│   │   ├── admin/          # 管理后台
│   │   ├── api/            # API 接口
│   │   ├── category/       # 分类页面
│   │   ├── login/          # 登录页面
│   │   ├── membership/     # 会员订阅页面
│   │   ├── post/           # 文章详情页面
│   │   ├── posts/          # 文章列表页面
│   │   ├── register/       # 注册页面
│   │   ├── search/         # 搜索页面
│   │   └── tag/            # 标签页面
│   ├── components/         # 业务组件
│   │   ├── ui/             # shadcn UI 组件
│   │   ├── comments/       # 评论组件
│   │   └── ...             # 其他业务组件
│   ├── hooks/              # 自定义 Hooks
│   ├── lib/                # 工具库
│   │   ├── auth.ts         # 认证相关
│   │   ├── payment.ts      # 支付相关
│   │   └── utils.ts        # 通用工具
│   ├── storage/            # 数据库配置
│   └── server.ts           # 自定义服务器入口
├── public/                 # 静态资源
├── next.config.ts          # Next.js 配置
├── package.json            # 项目依赖
├── tsconfig.json           # TypeScript 配置
└── AGENTS.md               # 项目文档
```

---

## API接口

### 认证接口

| 方法 | 路径 | 说明 |
|------|------|------|
| POST | `/api/auth/register` | 用户注册 |
| POST | `/api/auth/login` | 用户登录 |
| POST | `/api/auth/logout` | 用户登出 |
| GET | `/api/auth/me` | 获取当前用户 |

### 文章接口

| 方法 | 路径 | 说明 |
|------|------|------|
| GET | `/api/posts` | 文章列表 |
| POST | `/api/posts` | 创建文章 |
| GET | `/api/posts/[id]` | 文章详情 |
| PUT | `/api/posts/[id]` | 更新文章 |
| DELETE | `/api/posts/[id]` | 删除文章 |

### 其他接口

完整 API 文档请参考 [AGENTS.md](./AGENTS.md)

---

## 开发规范

### 包管理

**必须使用 pnpm**，禁止使用 npm 或 yarn：

```bash
pnpm add package-name      # 添加依赖
pnpm add -D package-name   # 添加开发依赖
pnpm install               # 安装所有依赖
```

### 组件开发

优先使用 shadcn/ui 组件：

```tsx
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
```

### 路由规范

- 服务端组件：默认，无需声明
- 客户端组件：文件顶部添加 `'use client'`

### 代码风格

- 使用 TypeScript
- 使用 ESLint 检查代码
- 使用路径别名 `@/`

---

## 常见问题

### 1. 端口被占用

```bash
# 查找占用端口的进程
lsof -i:5000

# 或使用脚本自动清理
./scripts/dev.sh
```

### 2. 数据库连接失败

- 检查 `COZE_SUPABASE_URL` 和 `COZE_SUPABASE_ANON_KEY` 是否正确
- 确认 Supabase 项目是否正常运行
- 检查网络连接

### 3. 图片上传失败

- 检查对象存储配置是否正确
- 确认存储桶权限设置
- 检查文件大小限制（默认 5MB）

### 4. 支付功能异常

- 确认支付宝商户配置正确
- 检查 `payment_configs` 表中的配置
- 确认回调地址可访问

---

## 许可证

MIT License
