import { getSupabaseClient } from '../src/storage/database/supabase-client';
import { hashPassword } from '../src/lib/auth';

async function initializeDatabase() {
  const client = getSupabaseClient();
  
  console.log('开始初始化数据库...');
  
  // 检查管理员是否已存在
  const { data: existingAdmin, error: checkError } = await client
    .from('users')
    .select('id')
    .eq('username', 'qianbin')
    .maybeSingle();
  
  if (checkError) {
    console.error('检查管理员失败:', checkError);
    return;
  }
  
  if (existingAdmin) {
    console.log('管理员账户已存在，跳过创建');
  } else {
    // 创建管理员账户
    const passwordHash = await hashPassword('66524522');
    
    const { error: createError } = await client
      .from('users')
      .insert({
        username: 'qianbin',
        email: 'admin@example.com',
        password_hash: passwordHash,
        display_name: '钱斌',
        role: 'admin',
        is_active: true,
      });
    
    if (createError) {
      console.error('创建管理员失败:', createError);
      return;
    }
    
    console.log('管理员账户创建成功');
    console.log('用户名: qianbin');
    console.log('密码: 66524522');
  }
  
  // 创建默认分类
  const { data: existingCategories } = await client
    .from('categories')
    .select('id')
    .limit(1);
  
  if (!existingCategories || existingCategories.length === 0) {
    const defaultCategories = [
      { name: '未分类', slug: 'uncategorized', description: '默认分类' },
      { name: '技术', slug: 'tech', description: '技术相关文章' },
      { name: '生活', slug: 'life', description: '生活随笔' },
    ];
    
    const { error: categoryError } = await client
      .from('categories')
      .insert(defaultCategories);
    
    if (categoryError) {
      console.error('创建分类失败:', categoryError);
    } else {
      console.log('默认分类创建成功');
    }
  }
  
  // 创建支付配置
  const { data: existingPaymentConfigs } = await client
    .from('payment_configs')
    .select('id')
    .limit(1);
  
  if (!existingPaymentConfigs || existingPaymentConfigs.length === 0) {
    const paymentConfigs = [
      {
        payment_method: 'alipay',
        display_name: '支付宝',
        is_enabled: false,
        description: '支付宝支付',
        config: {
          app_id: '',
          private_key: '',
          public_key: '',
          notify_url: '',
        },
      },
      {
        payment_method: 'wechat',
        display_name: '微信支付',
        is_enabled: false,
        description: '微信支付',
        config: {
          app_id: '',
          mch_id: '',
          api_key: '',
          notify_url: '',
        },
      },
      {
        payment_method: 'paypal',
        display_name: 'PayPal',
        is_enabled: false,
        description: 'PayPal支付',
        config: {
          client_id: '',
          client_secret: '',
          mode: 'sandbox',
        },
      },
    ];
    
    const { error: paymentError } = await client
      .from('payment_configs')
      .insert(paymentConfigs);
    
    if (paymentError) {
      console.error('创建支付配置失败:', paymentError);
    } else {
      console.log('支付配置创建成功');
    }
  }
  
  // 创建默认设置
  const { data: existingSettings } = await client
    .from('settings')
    .select('id')
    .limit(1);
  
  if (!existingSettings || existingSettings.length === 0) {
    const defaultSettings = [
      { key: 'site_name', value: '我的博客', description: '网站名称' },
      { key: 'site_description', value: '一个基于 Next.js 的博客系统', description: '网站描述' },
      { key: 'site_url', value: '', description: '网站地址' },
      { key: 'posts_per_page', value: '10', description: '每页文章数' },
    ];
    
    const { error: settingsError } = await client
      .from('settings')
      .insert(defaultSettings);
    
    if (settingsError) {
      console.error('创建设置失败:', settingsError);
    } else {
      console.log('默认设置创建成功');
    }
  }
  
  console.log('数据库初始化完成！');
}

initializeDatabase().catch(console.error);
