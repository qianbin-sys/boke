-- AI模型配置表
CREATE TABLE IF NOT EXISTS ai_models (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name VARCHAR(255) NOT NULL,
  provider VARCHAR(50) NOT NULL,
  model_type VARCHAR(20) NOT NULL CHECK (model_type IN ('llm', 'image')),
  model_id VARCHAR(255) NOT NULL,
  api_endpoint TEXT,
  api_key_encrypted TEXT,
  config JSONB DEFAULT '{}',
  is_enabled BOOLEAN DEFAULT true,
  is_default BOOLEAN DEFAULT false,
  priority INTEGER DEFAULT 0,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- 创建索引
CREATE INDEX IF NOT EXISTS idx_ai_models_type ON ai_models(model_type);
CREATE INDEX IF NOT EXISTS idx_ai_models_enabled ON ai_models(is_enabled);
CREATE INDEX IF NOT EXISTS idx_ai_models_default ON ai_models(model_type, is_default) WHERE is_default = true;

-- 插入默认豆包模型配置
INSERT INTO ai_models (name, provider, model_type, model_id, is_enabled, is_default, priority)
VALUES 
  ('豆包 Seed 2.0 Pro', 'doubao', 'llm', 'doubao-seed-2-0-pro-260215', true, true, 100),
  ('豆包图片生成', 'doubao', 'image', 'default', true, true, 100)
ON CONFLICT DO NOTHING;

-- 添加注释
COMMENT ON TABLE ai_models IS 'AI模型配置表';
COMMENT ON COLUMN ai_models.name IS '模型显示名称';
COMMENT ON COLUMN ai_models.provider IS '提供商：doubao/deepseek/kimi/openai/custom';
COMMENT ON COLUMN ai_models.model_type IS '模型类型：llm/image';
COMMENT ON COLUMN ai_models.model_id IS '模型ID';
COMMENT ON COLUMN ai_models.api_endpoint IS 'API端点URL';
COMMENT ON COLUMN ai_models.api_key_encrypted IS 'API密钥（加密存储）';
COMMENT ON COLUMN ai_models.config IS '扩展配置JSON';
COMMENT ON COLUMN ai_models.is_enabled IS '是否启用';
COMMENT ON COLUMN ai_models.is_default IS '是否为该类型的默认模型';
COMMENT ON COLUMN ai_models.priority IS '优先级（数值越大越优先）';
