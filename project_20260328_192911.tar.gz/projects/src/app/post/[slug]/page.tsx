import { getSupabaseClient } from '@/storage/database/supabase-client';
import Link from 'next/link';
import { notFound } from 'next/navigation';
import { ProtectedContent } from '@/components/protected-content';
import Comments from '@/components/comments/comment-section';

interface Post {
  id: string;
  title: string;
  slug: string;
  content: string;
  excerpt: string;
  featured_image: string;
  category_id: string;
  status: string;
  view_count: number;
  created_at: string;
  published_at: string;
  is_paid: boolean;
  price: number;
  payment_methods: string[];
  free_content: string;
  seo_title: string | null;
  seo_description: string | null;
  seo_keywords: string | null;
  categories: {
    id: string;
    name: string;
    slug: string;
  } | null;
  users: {
    id: string;
    username: string;
    display_name: string;
    avatar_url: string;
  } | null;
}

async function getPost(slug: string): Promise<Post | null> {
  const client = getSupabaseClient();
  
  const { data, error } = await client
    .from('posts')
    .select(`
      *,
      categories(id, name, slug),
      users!posts_author_id_users_id_fk(id, username, display_name, avatar_url)
    `)
    .eq('slug', slug)
    .eq('status', 'published')
    .maybeSingle();
  
  if (error || !data) {
    return null;
  }
  
  await client
    .from('posts')
    .update({ view_count: data.view_count + 1 })
    .eq('id', data.id);
  
  return data;
}

async function getRelatedPosts(categoryId: string, currentPostId: string) {
  const client = getSupabaseClient();
  
  const { data } = await client
    .from('posts')
    .select('id, title, slug, created_at, excerpt')
    .eq('category_id', categoryId)
    .eq('status', 'published')
    .neq('id', currentPostId)
    .limit(4);
  
  return data || [];
}

export async function generateMetadata({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const post = await getPost(slug);
  
  if (!post) {
    return { title: '文章未找到' };
  }
  
  const title = post.seo_title || post.title;
  const description = post.seo_description || post.excerpt || post.content?.substring(0, 160);
  const keywords = post.seo_keywords || '';
  
  return {
    title,
    description,
    keywords: keywords.split(',').map(k => k.trim()).filter(Boolean),
    openGraph: {
      title,
      description,
      type: 'article',
      publishedTime: post.published_at || post.created_at,
      authors: [post.users?.display_name || post.users?.username || '匿名'],
      images: post.featured_image ? [{ url: post.featured_image }] : [],
    },
    twitter: {
      card: 'summary_large_image',
      title,
      description,
      images: post.featured_image ? [post.featured_image] : [],
    },
  };
}

const categoryColors: Record<string, { bg: string; text: string }> = {
  'tech': { bg: 'bg-blue-50 dark:bg-blue-900/30', text: 'text-blue-600 dark:text-blue-400' },
  'life': { bg: 'bg-green-50 dark:bg-green-900/30', text: 'text-green-600 dark:text-green-400' },
  'uncategorized': { bg: 'bg-gray-50 dark:bg-gray-800', text: 'text-gray-600 dark:text-gray-400' },
};

function getCategoryColor(slug: string) {
  return categoryColors[slug] || { bg: 'bg-purple-50 dark:bg-purple-900/30', text: 'text-purple-600 dark:text-purple-400' };
}

export default async function PostPage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const post = await getPost(slug);
  
  if (!post) {
    notFound();
  }
  
  const relatedPosts = post.category_id ? await getRelatedPosts(post.category_id, post.id) : [];
  const categoryColor = post.categories ? getCategoryColor(post.categories.slug) : getCategoryColor('uncategorized');
  const isPaidContent = post.is_paid && post.price > 0;

  return (
    <div className="max-w-4xl mx-auto">
      <article>
        {/* Header */}
        <header className="mb-10">
          {/* Breadcrumb */}
          <nav className="flex items-center gap-2 text-sm text-[#64748b] dark:text-[#94a3b8] mb-6">
            <Link href="/" className="hover:text-[#0ea5e9] transition-colors">首页</Link>
            <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
            </svg>
            {post.categories && (
              <>
                <Link href={`/category/${post.categories.slug}`} className="hover:text-[#0ea5e9] transition-colors">
                  {post.categories.name}
                </Link>
                <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                </svg>
              </>
            )}
            <span className="text-[#94a3b8] truncate max-w-[200px]">{post.title}</span>
          </nav>
          
          {/* Meta */}
          <div className="flex flex-wrap items-center gap-3 mb-4">
            {post.categories && (
              <Link href={`/category/${post.categories.slug}`}>
                <span className={`inline-flex items-center px-3 py-1 text-sm font-medium rounded-lg ${categoryColor.bg} ${categoryColor.text}`}>
                  {post.categories.name}
                </span>
              </Link>
            )}
          </div>
          
          {/* Title */}
          <div className="flex items-start gap-3">
            <h1 className="text-3xl md:text-4xl font-bold text-[#1e293b] dark:text-white leading-tight flex-1">
              {post.title}
            </h1>
            {isPaidContent && (
              <span className="flex-shrink-0 inline-flex items-center gap-1 px-3 py-1 bg-amber-100 dark:bg-amber-900/30 text-amber-600 dark:text-amber-400 text-sm font-medium rounded-lg">
                <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" />
                </svg>
                ¥{post.price}
              </span>
            )}
          </div>
          
          {/* Info */}
          <div className="flex flex-wrap items-center gap-4 text-sm text-[#64748b] dark:text-[#94a3b8] mt-4">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 bg-gradient-to-br from-[#0ea5e9] to-[#06b6d4] rounded-full flex items-center justify-center">
                <span className="text-white text-sm font-medium">
                  {(post.users?.display_name || post.users?.username || '匿')[0]}
                </span>
              </div>
              <span className="font-medium text-[#1e293b] dark:text-white">
                {post.users?.display_name || post.users?.username || '匿名'}
              </span>
            </div>
            <span className="text-[#cbd5e1]">·</span>
            <time>
              {new Date(post.published_at || post.created_at).toLocaleDateString('zh-CN', {
                year: 'numeric',
                month: 'long',
                day: 'numeric',
              })}
            </time>
            <span className="text-[#cbd5e1]">·</span>
            <span className="flex items-center gap-1">
              <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" />
              </svg>
              {post.view_count} 次阅读
            </span>
          </div>
          
          {/* Excerpt */}
          {post.excerpt && (
            <p className="mt-6 text-lg text-[#64748b] dark:text-[#94a3b8] leading-relaxed">
              {post.excerpt}
            </p>
          )}
        </header>

        {/* Featured Image */}
        {post.featured_image && (
          <div className="aspect-video bg-[#f1f5f9] dark:bg-[#334155] rounded-2xl overflow-hidden mb-10">
            <img
              src={post.featured_image}
              alt={post.title}
              className="w-full h-full object-cover"
            />
          </div>
        )}

        {/* Content - 使用客户端组件处理付费内容 */}
        {isPaidContent ? (
          <ProtectedContent 
            postId={post.id}
            content={post.content}
            price={post.price}
            paymentMethods={post.payment_methods || []}
            freeContent={post.free_content}
          />
        ) : (
          <div className="prose prose-lg dark:prose-invert max-w-none mb-12
            prose-headings:text-[#1e293b] dark:prose-headings:text-white
            prose-p:text-[#475569] dark:prose-p:text-[#cbd5e1]
            prose-a:text-[#0ea5e9] prose-a:no-underline hover:prose-a:underline
            prose-code:bg-[#f1f5f9] dark:prose-code:bg-[#334155] prose-code:px-1.5 prose-code:py-0.5 prose-code:rounded
            prose-pre:bg-[#1e293b] prose-pre:border prose-pre:border-[#334155]
            prose-blockquote:border-l-[#0ea5e9] prose-blockquote:bg-[#f0f9ff] dark:prose-blockquote:bg-[#0c4a6e]/20 prose-blockquote:py-1
          ">
            <div className="whitespace-pre-wrap leading-relaxed">
              {post.content}
            </div>
          </div>
        )}

        {/* Tags/Actions */}
        <div className="flex items-center justify-between py-6 border-t border-[#e2e8f0] dark:border-[#334155] mb-12">
          <div className="flex items-center gap-3">
            <span className="text-sm text-[#64748b]">这篇文章有帮助吗？</span>
            <button className="inline-flex items-center gap-1.5 px-3 py-1.5 text-sm text-[#64748b] hover:text-[#0ea5e9] hover:bg-[#f0f9ff] dark:hover:bg-[#0c4a6e]/20 rounded-lg transition-colors">
              <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M14 10h4.764a2 2 0 011.789 2.894l-3.5 7A2 2 0 0115.263 21h-4.017c-.163 0-.326-.02-.485-.06L7 20m7-10V5a2 2 0 00-2-2h-.095c-.5 0-.905.405-.905.905 0 .714-.211 1.412-.608 2.006L7 11v9m7-10h-2M7 20H5a2 2 0 01-2-2v-6a2 2 0 012-2h2.5" />
              </svg>
              有帮助
            </button>
          </div>
          <div className="flex items-center gap-2">
            <button className="inline-flex items-center gap-1.5 px-3 py-1.5 text-sm text-[#64748b] hover:text-[#0ea5e9] hover:bg-[#f0f9ff] dark:hover:bg-[#0c4a6e]/20 rounded-lg transition-colors">
              <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8.684 13.342C8.886 12.938 9 12.482 9 12c0-.482-.114-.938-.316-1.342m0 2.684a3 3 0 110-2.684m0 2.684l6.632 3.316m-6.632-6l6.632-3.316m0 0a3 3 0 105.367-2.684 3 3 0 00-5.367 2.684zm0 9.316a3 3 0 105.368 2.684 3 3 0 00-5.368-2.684z" />
              </svg>
              分享
            </button>
          </div>
        </div>

        {/* Author Card */}
        <div className="bg-[#f8fafc] dark:bg-[#1e293b] border border-[#e2e8f0] dark:border-[#334155] rounded-2xl p-6 mb-12">
          <div className="flex items-start gap-4">
            <div className="w-14 h-14 bg-gradient-to-br from-[#0ea5e9] to-[#06b6d4] rounded-xl flex items-center justify-center flex-shrink-0">
              {post.users?.avatar_url ? (
                <img
                  src={post.users.avatar_url}
                  alt={post.users.display_name || post.users.username}
                  className="w-full h-full object-cover rounded-xl"
                />
              ) : (
                <span className="text-white text-xl font-bold">
                  {(post.users?.display_name || post.users?.username || '?')[0].toUpperCase()}
                </span>
              )}
            </div>
            <div className="flex-1">
              <div className="flex items-center gap-2 mb-1">
                <span className="font-semibold text-[#1e293b] dark:text-white">
                  {post.users?.display_name || post.users?.username || '匿名'}
                </span>
                <span className="text-xs text-[#94a3b8] bg-[#f1f5f9] dark:bg-[#334155] px-2 py-0.5 rounded">
                  作者
                </span>
              </div>
              <p className="text-sm text-[#64748b] dark:text-[#94a3b8]">
                热爱技术，乐于分享。在这里记录学习与成长的点滴。
              </p>
            </div>
          </div>
        </div>

        {/* Comments */}
        <Comments postId={post.id} />

        {/* Related Posts */}
        {relatedPosts.length > 0 && (
          <div>
            <h2 className="text-xl font-bold text-[#1e293b] dark:text-white mb-6 flex items-center gap-2">
              <svg className="w-5 h-5 text-[#0ea5e9]" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 20H5a2 2 0 01-2-2V6a2 2 0 012-2h10a2 2 0 012 2v1m2 13a2 2 0 01-2-2V7m2 13a2 2 0 002-2V9a2 2 0 00-2-2h-2m-4-3H9M7 16h6M7 8h6v4H7V8z" />
              </svg>
              相关文章
            </h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {relatedPosts.map((related) => (
                <Link
                  key={related.id}
                  href={`/post/${related.slug}`}
                  className="group p-4 bg-white dark:bg-[#1e293b] border border-[#e2e8f0] dark:border-[#334155] rounded-xl hover:border-[#0ea5e9]/50 transition-colors"
                >
                  <h3 className="font-medium text-[#1e293b] dark:text-white group-hover:text-[#0ea5e9] transition-colors line-clamp-2 mb-2">
                    {related.title}
                  </h3>
                  <p className="text-sm text-[#64748b] dark:text-[#94a3b8] line-clamp-2 mb-2">
                    {related.excerpt || '暂无摘要'}
                  </p>
                  <span className="text-xs text-[#94a3b8]">
                    {new Date(related.created_at).toLocaleDateString('zh-CN')}
                  </span>
                </Link>
              ))}
            </div>
          </div>
        )}
      </article>
    </div>
  );
}
