import { getSupabaseClient } from '@/storage/database/supabase-client';
import Link from 'next/link';
import { notFound } from 'next/navigation';

async function getCategory(slug: string) {
  const client = getSupabaseClient();
  
  const { data, error } = await client
    .from('categories')
    .select('*')
    .eq('slug', slug)
    .maybeSingle();
  
  if (error || !data) {
    return null;
  }
  
  return data;
}

async function getPostsByCategory(categoryId: string) {
  const client = getSupabaseClient();
  
  const { data, error } = await client
    .from('posts')
    .select(`
      id,
      title,
      slug,
      excerpt,
      featured_image,
      view_count,
      created_at,
      published_at,
      users!posts_author_id_users_id_fk(id, username, display_name)
    `)
    .eq('category_id', categoryId)
    .eq('status', 'published')
    .order('published_at', { ascending: false });
  
  if (error) {
    console.error('Failed to fetch posts:', error);
    return [];
  }
  
  return (data || []) as unknown as Array<{
    id: string;
    title: string;
    slug: string;
    excerpt: string | null;
    featured_image: string | null;
    view_count: number;
    created_at: string;
    published_at: string | null;
    users: { id: string; username: string; display_name: string | null } | null;
  }>;
}

export async function generateMetadata({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const category = await getCategory(slug);
  
  if (!category) {
    return { title: '分类未找到' };
  }
  
  return {
    title: category.name,
    description: category.description || `查看 ${category.name} 分类下的所有文章`,
  };
}

// 分类颜色映射
const categoryStyles: Record<string, { bg: string; text: string; gradient: string }> = {
  'tech': { 
    bg: 'bg-blue-50 dark:bg-blue-900/30', 
    text: 'text-blue-600 dark:text-blue-400',
    gradient: 'from-blue-500 to-cyan-500'
  },
  'life': { 
    bg: 'bg-green-50 dark:bg-green-900/30', 
    text: 'text-green-600 dark:text-green-400',
    gradient: 'from-green-500 to-emerald-500'
  },
  'uncategorized': { 
    bg: 'bg-gray-50 dark:bg-gray-800', 
    text: 'text-gray-600 dark:text-gray-400',
    gradient: 'from-gray-400 to-gray-500'
  },
};

function getCategoryStyle(slug: string) {
  return categoryStyles[slug] || { 
    bg: 'bg-purple-50 dark:bg-purple-900/30', 
    text: 'text-purple-600 dark:text-purple-400',
    gradient: 'from-purple-500 to-pink-500'
  };
}

export default async function CategoryPage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const category = await getCategory(slug);
  
  if (!category) {
    notFound();
  }
  
  const posts = await getPostsByCategory(category.id);
  const style = getCategoryStyle(slug);

  return (
    <div>
      {/* Category Header */}
      <div className="mb-10">
        {/* Breadcrumb */}
        <nav className="flex items-center gap-2 text-sm text-[#64748b] dark:text-[#94a3b8] mb-6">
          <Link href="/" className="hover:text-[#0ea5e9] transition-colors">首页</Link>
          <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
          </svg>
          <span className="text-[#1e293b] dark:text-white">{category.name}</span>
        </nav>
        
        <div className="flex items-start gap-4">
          <div className={`w-14 h-14 bg-gradient-to-br ${style.gradient} rounded-xl flex items-center justify-center flex-shrink-0`}>
            <svg className="w-7 h-7 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 7h.01M7 3h5c.512 0 1.024.195 1.414.586l7 7a2 2 0 010 2.828l-7 7a2 2 0 01-2.828 0l-7-7A1.994 1.994 0 013 12V7a4 4 0 014-4z" />
            </svg>
          </div>
          <div>
            <h1 className="text-2xl font-bold text-[#1e293b] dark:text-white mb-2">
              {category.name}
            </h1>
            {category.description && (
              <p className="text-[#64748b] dark:text-[#94a3b8]">
                {category.description}
              </p>
            )}
            <p className="text-sm text-[#94a3b8] mt-2">
              共 {posts.length} 篇文章
            </p>
          </div>
        </div>
      </div>

      {/* Posts Grid */}
      {posts.length === 0 ? (
        <div className="text-center py-20">
          <div className="w-16 h-16 bg-[#f1f5f9] dark:bg-[#334155] rounded-2xl flex items-center justify-center mx-auto mb-4">
            <svg className="w-8 h-8 text-[#94a3b8]" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M19 20H5a2 2 0 01-2-2V6a2 2 0 012-2h10a2 2 0 012 2v1m2 13a2 2 0 01-2-2V7m2 13a2 2 0 002-2V9a2 2 0 00-2-2h-2m-4-3H9M7 16h6M7 8h6v4H7V8z" />
            </svg>
          </div>
          <p className="text-[#64748b] dark:text-[#94a3b8] text-lg mb-2">该分类下暂无文章</p>
          <Link href="/" className="text-[#0ea5e9] hover:underline">
            返回首页
          </Link>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {posts.map((post) => (
            <Link 
              key={post.id} 
              href={`/post/${post.slug}`}
              className="group block bg-white dark:bg-[#1e293b] border border-[#e2e8f0] dark:border-[#334155] rounded-xl overflow-hidden hover:border-[#0ea5e9]/50 transition-all duration-200"
            >
              {/* Image */}
              {post.featured_image ? (
                <div className="aspect-video bg-[#f1f5f9] dark:bg-[#334155] overflow-hidden">
                  <img
                    src={post.featured_image}
                    alt={post.title}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                  />
                </div>
              ) : (
                <div className="aspect-video bg-gradient-to-br from-[#f1f5f9] to-[#e2e8f0] dark:from-[#334155] dark:to-[#1e293b] flex items-center justify-center">
                  <svg className="w-12 h-12 text-[#cbd5e1] dark:text-[#475569]" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1} d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" />
                  </svg>
                </div>
              )}
              
              {/* Content */}
              <div className="p-5">
                {/* Date */}
                <div className="flex items-center gap-2 mb-3">
                  <span className="text-xs text-[#94a3b8]">
                    {new Date(post.published_at || post.created_at).toLocaleDateString('zh-CN', {
                      month: 'short',
                      day: 'numeric',
                    })}
                  </span>
                </div>
                
                {/* Title */}
                <h2 className="font-semibold text-[#1e293b] dark:text-white group-hover:text-[#0ea5e9] transition-colors mb-2 line-clamp-2">
                  {post.title}
                </h2>
                
                {/* Excerpt */}
                <p className="text-sm text-[#64748b] dark:text-[#94a3b8] line-clamp-2 mb-4">
                  {post.excerpt || '暂无摘要'}
                </p>
                
                {/* Footer */}
                <div className="flex items-center justify-between pt-3 border-t border-[#f1f5f9] dark:border-[#334155]">
                  <div className="flex items-center gap-2">
                    <div className="w-6 h-6 bg-gradient-to-br from-[#0ea5e9] to-[#06b6d4] rounded-full flex items-center justify-center">
                      <span className="text-white text-xs font-medium">
                        {(post.users?.display_name || post.users?.username || '匿')[0]}
                      </span>
                    </div>
                    <span className="text-xs text-[#64748b] dark:text-[#94a3b8]">
                      {post.users?.display_name || post.users?.username || '匿名'}
                    </span>
                  </div>
                  <div className="flex items-center gap-1 text-xs text-[#94a3b8]">
                    <svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" />
                    </svg>
                    <span>{post.view_count}</span>
                  </div>
                </div>
              </div>
            </Link>
          ))}
        </div>
      )}
    </div>
  );
}
