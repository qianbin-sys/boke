import { getSupabaseClient } from '@/storage/database/supabase-client';
import Link from 'next/link';

async function getPosts() {
  const client = getSupabaseClient();
  
  const { data, error } = await client
    .from('posts')
    .select(`
      id,
      title,
      slug,
      excerpt,
      featured_image,
      view_count,
      created_at,
      published_at,
      categories(id, name, slug),
      users!posts_author_id_users_id_fk(id, username, display_name)
    `)
    .eq('status', 'published')
    .order('published_at', { ascending: false })
    .limit(9);
  
  if (error) {
    console.error('Failed to fetch posts:', error);
    return [];
  }
  
  return (data || []) as unknown as Array<{
    id: string;
    title: string;
    slug: string;
    excerpt: string | null;
    featured_image: string | null;
    view_count: number;
    created_at: string;
    published_at: string | null;
    categories: { id: string; name: string; slug: string } | null;
    users: { id: string; username: string; display_name: string | null } | null;
  }>;
}

async function getSettings() {
  const client = getSupabaseClient();
  const { data } = await client.from('settings').select('*');
  
  const settings: Record<string, string> = {};
  data?.forEach((item) => {
    settings[item.key] = item.value || '';
  });
  
  return settings;
}

// 分类颜色映射
const categoryColors: Record<string, { bg: string; text: string }> = {
  'tech': { bg: 'bg-blue-50 dark:bg-blue-900/30', text: 'text-blue-600 dark:text-blue-400' },
  'life': { bg: 'bg-green-50 dark:bg-green-900/30', text: 'text-green-600 dark:text-green-400' },
  'uncategorized': { bg: 'bg-gray-50 dark:bg-gray-800', text: 'text-gray-600 dark:text-gray-400' },
};

function getCategoryColor(slug: string) {
  return categoryColors[slug] || { bg: 'bg-purple-50 dark:bg-purple-900/30', text: 'text-purple-600 dark:text-purple-400' };
}

export default async function HomePage() {
  const posts = await getPosts();
  const settings = await getSettings();

  return (
    <div>
      {/* Hero Section - 扁平化设计 */}
      <div className="mb-12 text-center">
        <div className="inline-flex items-center gap-2 px-4 py-2 bg-[#f0f9ff] dark:bg-[#0c4a6e]/30 rounded-full mb-6">
          <span className="w-2 h-2 bg-[#0ea5e9] rounded-full"></span>
          <span className="text-sm font-medium text-[#0369a1] dark:text-[#7dd3fc]">分享技术，记录生活</span>
        </div>
        <h1 className="text-4xl md:text-5xl font-bold text-[#1e293b] dark:text-white mb-4">
          {settings.site_name || '我的博客'}
        </h1>
        <p className="text-lg text-[#64748b] dark:text-[#94a3b8] max-w-2xl mx-auto">
          {settings.site_description || '一个基于 Next.js 的博客系统，记录技术与生活的点滴'}
        </p>
      </div>

      {/* Posts Grid */}
      {posts.length === 0 ? (
        <div className="text-center py-20">
          <div className="w-16 h-16 bg-[#f1f5f9] dark:bg-[#334155] rounded-2xl flex items-center justify-center mx-auto mb-4">
            <svg className="w-8 h-8 text-[#94a3b8]" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M19 20H5a2 2 0 01-2-2V6a2 2 0 012-2h10a2 2 0 012 2v1m2 13a2 2 0 01-2-2V7m2 13a2 2 0 002-2V9a2 2 0 00-2-2h-2m-4-3H9M7 16h6M7 8h6v4H7V8z" />
            </svg>
          </div>
          <p className="text-[#64748b] dark:text-[#94a3b8] text-lg mb-2">还没有文章</p>
          <p className="text-[#94a3b8] text-sm mb-6">开始创作你的第一篇博客文章吧</p>
          <Link 
            href="/admin/posts/new" 
            className="inline-flex items-center gap-2 px-5 py-2.5 text-sm font-medium text-white bg-[#0ea5e9] hover:bg-[#0284c7] rounded-lg transition-colors"
          >
            <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" />
            </svg>
            创建文章
          </Link>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {posts.map((post) => {
            const categoryColor = post.categories ? getCategoryColor(post.categories.slug) : getCategoryColor('uncategorized');
            
            return (
              <Link 
                key={post.id} 
                href={`/post/${post.slug}`}
                className="group block bg-white dark:bg-[#1e293b] border border-[#e2e8f0] dark:border-[#334155] rounded-xl overflow-hidden hover:border-[#0ea5e9]/50 hover:shadow-lg transition-all duration-200"
              >
                {/* Image */}
                {post.featured_image ? (
                  <div className="aspect-video bg-[#f1f5f9] dark:bg-[#334155] overflow-hidden">
                    <img
                      src={post.featured_image}
                      alt={post.title}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                    />
                  </div>
                ) : (
                  <div className="aspect-video bg-gradient-to-br from-[#f1f5f9] to-[#e2e8f0] dark:from-[#334155] dark:to-[#1e293b] flex items-center justify-center">
                    <svg className="w-12 h-12 text-[#cbd5e1] dark:text-[#475569]" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1} d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" />
                    </svg>
                  </div>
                )}
                
                {/* Content */}
                <div className="p-5">
                  {/* Category & Date */}
                  <div className="flex items-center gap-3 mb-3">
                    {post.categories && (
                      <span className={`inline-flex items-center px-2.5 py-1 text-xs font-medium rounded-md ${categoryColor.bg} ${categoryColor.text}`}>
                        {post.categories.name}
                      </span>
                    )}
                    <span className="text-xs text-[#94a3b8] dark:text-[#64748b]">
                      {new Date(post.published_at || post.created_at).toLocaleDateString('zh-CN', {
                        month: 'short',
                        day: 'numeric',
                      })}
                    </span>
                  </div>
                  
                  {/* Title */}
                  <h2 className="text-lg font-semibold text-[#1e293b] dark:text-white group-hover:text-[#0ea5e9] transition-colors mb-2 line-clamp-2">
                    {post.title}
                  </h2>
                  
                  {/* Excerpt */}
                  <p className="text-sm text-[#64748b] dark:text-[#94a3b8] line-clamp-2 mb-4">
                    {post.excerpt || '暂无摘要'}
                  </p>
                  
                  {/* Footer */}
                  <div className="flex items-center justify-between pt-3 border-t border-[#f1f5f9] dark:border-[#334155]">
                    <div className="flex items-center gap-2">
                      <div className="w-6 h-6 bg-gradient-to-br from-[#0ea5e9] to-[#06b6d4] rounded-full flex items-center justify-center">
                        <span className="text-white text-xs font-medium">
                          {(post.users?.display_name || post.users?.username || '匿')[0]}
                        </span>
                      </div>
                      <span className="text-xs text-[#64748b] dark:text-[#94a3b8]">
                        {post.users?.display_name || post.users?.username || '匿名'}
                      </span>
                    </div>
                    <div className="flex items-center gap-1 text-xs text-[#94a3b8]">
                      <svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" />
                      </svg>
                      <span>{post.view_count}</span>
                    </div>
                  </div>
                </div>
              </Link>
            );
          })}
        </div>
      )}

      {/* Load More */}
      {posts.length >= 9 && (
        <div className="text-center mt-10">
          <Link
            href="/posts"
            className="inline-flex items-center gap-2 px-6 py-3 text-sm font-medium text-[#0ea5e9] bg-[#f0f9ff] dark:bg-[#0c4a6e]/30 hover:bg-[#e0f2fe] dark:hover:bg-[#0c4a6e]/50 rounded-lg transition-colors"
          >
            查看更多文章
            <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 8l4 4m0 0l-4 4m4-4H3" />
            </svg>
          </Link>
        </div>
      )}
    </div>
  );
}
