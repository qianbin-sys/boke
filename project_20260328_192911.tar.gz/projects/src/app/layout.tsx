import type { Metadata } from 'next';
import { Inspector } from 'react-dev-inspector';
import './globals.css';
import { getSupabaseClient } from '@/storage/database/supabase-client';
import { cookies } from 'next/headers';
import { verifySessionToken } from '@/lib/auth';
import { ThemeProvider } from '@/components/theme-provider';
import { ThemeToggle } from '@/components/theme-toggle';
import { UserMenu } from '@/components/user-menu';

async function getSettings() {
  try {
    const client = getSupabaseClient();
    const { data } = await client.from('settings').select('*');
    
    const settings: Record<string, string> = {};
    data?.forEach((item) => {
      settings[item.key] = item.value || '';
    });
    
    return settings;
  } catch {
    return {};
  }
}

async function getCategories() {
  try {
    const client = getSupabaseClient();
    const { data } = await client
      .from('categories')
      .select('id, name, slug')
      .order('sort_order', { ascending: true })
      .limit(5);
    
    return data || [];
  } catch {
    return [];
  }
}

async function getCurrentUserFromCookie() {
  try {
    const cookieStore = await cookies();
    const token = cookieStore.get('session')?.value;
    
    if (!token) return null;
    
    const session = await verifySessionToken(token);
    if (!session) return null;
    
    const client = getSupabaseClient();
    const { data } = await client
      .from('users')
      .select('id, username, email, role, display_name')
      .eq('id', session.userId)
      .maybeSingle();
    
    if (!data) return null;
    
    return {
      userId: data.id,
      username: data.username,
      email: data.email,
      role: data.role,
      display_name: data.display_name,
    };
  } catch {
    return null;
  }
}

export async function generateMetadata(): Promise<Metadata> {
  const settings = await getSettings();
  
  return {
    title: {
      default: settings.site_name || '我的博客',
      template: `%s | ${settings.site_name || '我的博客'}`,
    },
    description: settings.site_description || '一个基于 Next.js 的博客系统',
  };
}

export default async function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  const isDev = process.env.COZE_PROJECT_ENV === 'DEV';
  const settings = await getSettings();
  const categories = await getCategories();
  const user = await getCurrentUserFromCookie();

  return (
    <html lang="zh-CN" suppressHydrationWarning>
      <body className="min-h-screen bg-[#f8fafc] dark:bg-[#0f172a] antialiased">
        {isDev && <Inspector />}
        <ThemeProvider defaultTheme="system" storageKey="theme">
          {/* Header - 扁平化设计 */}
          <header className="bg-white dark:bg-[#1e293b] border-b border-[#e2e8f0] dark:border-[#334155] sticky top-0 z-50">
            <div className="max-w-6xl mx-auto px-6 h-16 flex items-center justify-between">
              {/* Logo */}
              <a href="/" className="flex items-center gap-2 group">
                <div className="w-8 h-8 bg-gradient-to-br from-[#0ea5e9] to-[#06b6d4] rounded-lg flex items-center justify-center">
                  <span className="text-white font-bold text-sm">B</span>
                </div>
                <span className="text-lg font-semibold text-[#1e293b] dark:text-white group-hover:text-[#0ea5e9] transition-colors">
                  {settings.site_name || '我的博客'}
                </span>
              </a>
              
              {/* Navigation */}
              <nav className="flex items-center gap-1">
                <a 
                  href="/" 
                  className="px-4 py-2 text-sm font-medium text-[#64748b] dark:text-[#94a3b8] hover:text-[#0ea5e9] hover:bg-[#f1f5f9] dark:hover:bg-[#334155] rounded-lg transition-colors"
                >
                  首页
                </a>
                {categories.map((cat) => (
                  <a
                    key={cat.id}
                    href={`/category/${cat.slug}`}
                    className="px-4 py-2 text-sm font-medium text-[#64748b] dark:text-[#94a3b8] hover:text-[#0ea5e9] hover:bg-[#f1f5f9] dark:hover:bg-[#334155] rounded-lg transition-colors"
                  >
                    {cat.name}
                  </a>
                ))}
                <a
                  href="/membership"
                  className="px-4 py-2 text-sm font-medium text-[#64748b] dark:text-[#94a3b8] hover:text-[#0ea5e9] hover:bg-[#f1f5f9] dark:hover:bg-[#334155] rounded-lg transition-colors flex items-center gap-1"
                >
                  <svg className="w-4 h-4 text-amber-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 3v4M3 5h4M6 17v4m-2-2h4m5-16l2.286 6.857L21 12l-5.714 2.143L13 21l-2.286-6.857L5 12l5.714-2.143L13 3z" />
                  </svg>
                  会员
                </a>
                <a
                  href="/tags"
                  className="px-4 py-2 text-sm font-medium text-[#64748b] dark:text-[#94a3b8] hover:text-[#0ea5e9] hover:bg-[#f1f5f9] dark:hover:bg-[#334155] rounded-lg transition-colors"
                >
                  标签
                </a>
                <a
                  href="/search"
                  className="p-2 text-[#64748b] dark:text-[#94a3b8] hover:text-[#0ea5e9] hover:bg-[#f1f5f9] dark:hover:bg-[#334155] rounded-lg transition-colors"
                  title="搜索"
                >
                  <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                  </svg>
                </a>
                
                {/* 主题切换 */}
                <ThemeToggle />
                
                {/* 用户状态 */}
                {user ? (
                  <div className="flex items-center gap-2 ml-2">
                    {user.role === 'admin' && (
                      <a
                        href="/admin"
                        className="px-4 py-2 text-sm font-medium text-white bg-[#0ea5e9] hover:bg-[#0284c7] rounded-lg transition-colors"
                      >
                        管理
                      </a>
                    )}
                    <UserMenu user={user} />
                  </div>
                ) : (
                  <div className="flex items-center gap-2 ml-2">
                    <a
                      href="/login"
                      className="px-4 py-2 text-sm font-medium text-[#64748b] dark:text-[#94a3b8] hover:text-[#0ea5e9] hover:bg-[#f1f5f9] dark:hover:bg-[#334155] rounded-lg transition-colors"
                    >
                      登录
                    </a>
                    <a
                      href="/register"
                      className="px-4 py-2 text-sm font-medium text-white bg-[#0ea5e9] hover:bg-[#0284c7] rounded-lg transition-colors"
                    >
                      注册
                    </a>
                  </div>
                )}
              </nav>
            </div>
          </header>

          {/* Main Content */}
          <main className="max-w-6xl mx-auto px-6 py-10 min-h-[calc(100vh-200px)]">
            {children}
          </main>

          {/* Footer - 扁平化设计 */}
          <footer className="bg-white dark:bg-[#1e293b] border-t border-[#e2e8f0] dark:border-[#334155] mt-auto">
            <div className="max-w-6xl mx-auto px-6 py-8">
              <div className="flex flex-col md:flex-row items-center justify-between gap-4">
                <div className="flex items-center gap-2">
                  <div className="w-6 h-6 bg-gradient-to-br from-[#0ea5e9] to-[#06b6d4] rounded flex items-center justify-center">
                    <span className="text-white font-bold text-xs">B</span>
                  </div>
                  <span className="text-sm text-[#64748b] dark:text-[#94a3b8]">
                    © {new Date().getFullYear()} {settings.site_name || '我的博客'}
                  </span>
                </div>
                <div className="flex items-center gap-6">
                  <a href="/" className="text-sm text-[#64748b] dark:text-[#94a3b8] hover:text-[#0ea5e9] transition-colors">首页</a>
                  <a href="/membership" className="text-sm text-[#64748b] dark:text-[#94a3b8] hover:text-[#0ea5e9] transition-colors">会员</a>
                  <a href="/admin" className="text-sm text-[#64748b] dark:text-[#94a3b8] hover:text-[#0ea5e9] transition-colors">管理后台</a>
                </div>
                <p className="text-sm text-[#94a3b8] dark:text-[#64748b]">
                  Powered by Next.js
                </p>
              </div>
            </div>
          </footer>
        </ThemeProvider>
      </body>
    </html>
  );
}
