'use client';

import { useState, useEffect } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { Crown, Clock, CheckCircle, Loader2, CreditCard, User, LogOut, Receipt, ChevronRight, X, QrCode } from 'lucide-react';
import { PayPalButton } from '@/components/paypal-button';

interface Membership {
  id: string;
  status: string;
  started_at: string;
  expired_at: string;
  membership_plans: {
    id: string;
    name: string;
    slug: string;
    price: string;
    duration_days: number;
  };
}

interface Plan {
  id: string;
  name: string;
  slug: string;
  description: string;
  price: string;
  original_price: string;
  duration_days: number;
  features: string[];
  is_active: boolean;
}

interface UserInfo {
  userId: string;
  username: string;
  email: string;
  display_name: string;
}

export default function UserMembershipPage() {
  const router = useRouter();
  const [isLoading, setIsLoading] = useState(true);
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [userInfo, setUserInfo] = useState<UserInfo | null>(null);
  const [isMember, setIsMember] = useState(false);
  const [membership, setMembership] = useState<Membership | null>(null);
  const [plans, setPlans] = useState<Plan[]>([]);
  const [selectedPlan, setSelectedPlan] = useState<string | null>(null);
  const [selectedPaymentMethod, setSelectedPaymentMethod] = useState<string>('alipay');
  const [paymentMethods, setPaymentMethods] = useState<{payment_method: string; display_name: string}[]>([]);
  const [pendingOrderId, setPendingOrderId] = useState<string | null>(null);
  const [pendingOrderNo, setPendingOrderNo] = useState<string | null>(null);
  const [pendingAmount, setPendingAmount] = useState<number>(0);
  const [showPayPal, setShowPayPal] = useState(false);
  const [showAlipayQR, setShowAlipayQR] = useState(false);
  const [alipayQRCode, setAlipayQRCode] = useState<string | null>(null);
  const [isPaying, setIsPaying] = useState(false);
  const [isLoggingOut, setIsLoggingOut] = useState(false);
  const [polling, setPolling] = useState(false);
  const [paid, setPaid] = useState(false);

  useEffect(() => {
    fetchData();
  }, []);

  // 轮询检查支付状态
  useEffect(() => {
    if (!polling || !pendingOrderId || !pendingOrderNo) return;

    const pollPaymentStatus = async () => {
      try {
        // 先检查本地订单状态
        const orderResponse = await fetch(`/api/orders/${pendingOrderId}`);
        const orderData = await orderResponse.json();
        
        if (orderData.order?.payment_status === 'paid') {
          setPaid(true);
          setPolling(false);
          setTimeout(() => {
            setShowAlipayQR(false);
            alert('支付成功！您已成为会员');
            fetchData();
          }, 1500);
          return;
        }

        // 主动查询支付宝订单状态
        const queryResponse = await fetch('/api/payment/alipay/query', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ orderNo: pendingOrderNo }),
        });
        const queryData = await queryResponse.json();

        if (queryData.paid) {
          setPaid(true);
          setPolling(false);
          setTimeout(() => {
            setShowAlipayQR(false);
            alert('支付成功！您已成为会员');
            fetchData();
          }, 1500);
        }
      } catch (err) {
        console.error('Poll payment status error:', err);
      }
    };

    const interval = setInterval(pollPaymentStatus, 3000);
    pollPaymentStatus(); // 立即执行一次

    return () => clearInterval(interval);
  }, [polling, pendingOrderId, pendingOrderNo]);

  const fetchData = async () => {
    try {
      const authResponse = await fetch('/api/auth/me');
      if (authResponse.ok) {
        const authData = await authResponse.json();
        setUserInfo(authData.user);
        setIsLoggedIn(true);
      } else {
        setIsLoggedIn(false);
        setIsLoading(false);
        return;
      }

      const response = await fetch('/api/user/membership');
      if (response.ok) {
        const data = await response.json();
        setIsMember(data.isMember || false);
        setMembership(data.membership || null);
        setPlans(data.plans || []);
      }

      // 获取已启用的支付方式
      const paymentRes = await fetch('/api/payment-configs');
      if (paymentRes.ok) {
        const paymentData = await paymentRes.json();
        const enabled = (paymentData.configs || [])
          .filter((c: {is_enabled: boolean}) => c.is_enabled)
          .map((c: {payment_method: string; display_name: string}) => ({
            payment_method: c.payment_method,
            display_name: c.display_name,
          }));
        setPaymentMethods(enabled);
        // 默认选择第一个可用的支付方式
        if (enabled.length > 0) {
          setSelectedPaymentMethod(enabled[0].payment_method);
        }
      }
    } catch (error) {
      console.error('Failed to fetch membership:', error);
      setIsLoggedIn(false);
    } finally {
      setIsLoading(false);
    }
  };

  const handleLogout = async () => {
    setIsLoggingOut(true);
    try {
      await fetch('/api/auth/logout', { method: 'POST' });
      router.push('/');
    } catch (error) {
      console.error('Logout error:', error);
    } finally {
      setIsLoggingOut(false);
    }
  };

  const handleSubscribe = async () => {
    if (!selectedPlan) return;
    
    setIsPaying(true);
    try {
      // 1. 创建订单
      const createRes = await fetch('/api/orders', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          type: 'membership',
          plan_id: selectedPlan,
          payment_method: selectedPaymentMethod,
        }),
      });

      const createData = await createRes.json();
      if (!createRes.ok) {
        alert(createData.error || '创建订单失败');
        setIsPaying(false);
        return;
      }

      const order = createData.order;
      const plan = plans.find(p => p.id === selectedPlan);

      // 如果选择PayPal，显示PayPal按钮
      if (selectedPaymentMethod === 'paypal') {
        setPendingOrderId(order.id);
        setShowPayPal(true);
        setIsPaying(false);
        return;
      }

      // 如果选择支付宝，调用支付宝接口获取二维码
      if (selectedPaymentMethod === 'alipay') {
        const alipayRes = await fetch('/api/payment/alipay/create', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ orderId: order.id }),
        });

        const alipayData = await alipayRes.json();
        if (!alipayRes.ok) {
          alert(alipayData.error || '创建支付宝订单失败');
          setIsPaying(false);
          return;
        }

        setPendingOrderId(order.id);
        setPendingOrderNo(order.order_no);
        setPendingAmount(parseFloat(plan?.price || '0'));
        setAlipayQRCode(alipayData.qrCode);
        setShowAlipayQR(true);
        setPolling(true);
        setPaid(false);
        setIsPaying(false);
        return;
      }

      // 其他支付方式提示暂不支持
      alert('该支付方式暂不支持，请选择支付宝或PayPal');
      setIsPaying(false);
    } catch (error) {
      console.error('Subscribe error:', error);
      alert('支付失败，请稍后重试');
      setIsPaying(false);
    }
  };

  const handlePayPalSuccess = () => {
    setShowPayPal(false);
    setPendingOrderId(null);
    alert('支付成功！您已成为会员');
    fetchData();
  };

  const handlePayPalError = (error: string) => {
    console.error('PayPal error:', error);
    alert(`PayPal支付失败: ${error}`);
  };

  const handlePayPalCancel = () => {
    setShowPayPal(false);
    setPendingOrderId(null);
  };

  const handleCloseAlipayQR = () => {
    setShowAlipayQR(false);
    setPolling(false);
    setAlipayQRCode(null);
    setPendingOrderId(null);
    setPendingOrderNo(null);
  };

  const getDurationText = (days: number) => {
    if (days === 0) return '永久';
    if (days === 30) return '1个月';
    if (days === 365) return '1年';
    return `${days}天`;
  };

  const getStatusBadge = (status: string) => {
    const styles = {
      active: 'bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-400',
      expired: 'bg-gray-100 text-gray-700 dark:bg-gray-800 dark:text-gray-400',
      cancelled: 'bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-400',
    };
    const labels = {
      active: '有效',
      expired: '已过期',
      cancelled: '已取消',
    };
    return (
      <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-medium ${styles[status as keyof typeof styles]}`}>
        <CheckCircle className="w-3 h-3" />
        {labels[status as keyof typeof labels]}
      </span>
    );
  };

  if (isLoading) {
    return (
      <div className="max-w-4xl mx-auto py-12">
        <div className="flex items-center justify-center">
          <Loader2 className="w-8 h-8 animate-spin text-[#0ea5e9]" />
        </div>
      </div>
    );
  }

  if (!isLoggedIn) {
    return (
      <div className="max-w-4xl mx-auto py-12">
        <div className="text-center">
          <User className="w-16 h-16 mx-auto text-gray-400 mb-4" />
          <h1 className="text-2xl font-bold text-gray-900 dark:text-white mb-4">
            请先登录
          </h1>
          <p className="text-gray-500 dark:text-gray-400 mb-6">
            登录后查看您的会员状态和管理订阅
          </p>
          <Link
            href="/admin/login"
            className="inline-flex items-center gap-2 px-6 py-3 bg-[#0ea5e9] text-white rounded-lg hover:bg-[#0284c7] transition-colors"
          >
            前往登录
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto py-8">
      {/* Breadcrumb */}
      <nav className="flex items-center gap-2 text-sm text-[#64748b] dark:text-[#94a3b8] mb-6">
        <Link href="/" className="hover:text-[#0ea5e9] transition-colors">首页</Link>
        <ChevronRight className="w-4 h-4" />
        <span className="text-[#1e293b] dark:text-white">会员中心</span>
      </nav>

      <div className="flex items-center justify-between mb-6">
        <h1 className="text-2xl font-bold text-[#1e293b] dark:text-white">
          会员中心
        </h1>
        <button
          onClick={handleLogout}
          disabled={isLoggingOut}
          className="inline-flex items-center gap-2 px-4 py-2 text-sm font-medium text-[#64748b] dark:text-[#94a3b8] hover:text-red-600 dark:hover:text-red-400 hover:bg-red-50 dark:hover:bg-red-900/20 rounded-lg transition-colors"
        >
          {isLoggingOut ? (
            <Loader2 className="w-4 h-4 animate-spin" />
          ) : (
            <LogOut className="w-4 h-4" />
          )}
          退出登录
        </button>
      </div>

      {/* 用户信息 */}
      {userInfo && (
        <div className="bg-white dark:bg-[#1e293b] border border-[#e2e8f0] dark:border-[#334155] rounded-xl p-4 mb-6">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 bg-gradient-to-br from-[#0ea5e9] to-[#06b6d4] rounded-xl flex items-center justify-center">
              <span className="text-white text-lg font-bold">
                {(userInfo.display_name || userInfo.username || 'U')[0].toUpperCase()}
              </span>
            </div>
            <div className="flex-1">
              <p className="font-semibold text-[#1e293b] dark:text-white">
                {userInfo.display_name || userInfo.username}
              </p>
              <p className="text-sm text-[#64748b] dark:text-[#94a3b8]">
                {userInfo.email}
              </p>
            </div>
            {isMember && (
              <div className="flex items-center gap-1.5 px-3 py-1.5 bg-gradient-to-r from-amber-50 to-orange-50 dark:from-amber-900/20 dark:to-orange-900/20 border border-amber-200 dark:border-amber-800 rounded-lg">
                <Crown className="w-4 h-4 text-amber-500" />
                <span className="text-sm font-medium text-amber-600 dark:text-amber-400">会员</span>
              </div>
            )}
          </div>
        </div>
      )}

      {/* 快捷入口 */}
      <div className="grid grid-cols-2 gap-4 mb-6">
        <Link
          href="/account/orders"
          className="bg-white dark:bg-[#1e293b] border border-[#e2e8f0] dark:border-[#334155] rounded-xl p-4 hover:border-[#0ea5e9] transition-colors group"
        >
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-blue-100 dark:bg-blue-900/30 rounded-lg flex items-center justify-center">
              <Receipt className="w-5 h-5 text-blue-600" />
            </div>
            <div className="flex-1">
              <p className="font-medium text-[#1e293b] dark:text-white group-hover:text-[#0ea5e9]">
                订单记录
              </p>
              <p className="text-xs text-[#64748b] dark:text-[#94a3b8]">
                查看购买历史
              </p>
            </div>
            <ChevronRight className="w-5 h-5 text-gray-400 group-hover:text-[#0ea5e9]" />
          </div>
        </Link>
        <Link
          href="/membership"
          className="bg-white dark:bg-[#1e293b] border border-[#e2e8f0] dark:border-[#334155] rounded-xl p-4 hover:border-[#0ea5e9] transition-colors group"
        >
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-amber-100 dark:bg-amber-900/30 rounded-lg flex items-center justify-center">
              <Crown className="w-5 h-5 text-amber-600" />
            </div>
            <div className="flex-1">
              <p className="font-medium text-[#1e293b] dark:text-white group-hover:text-[#0ea5e9]">
                会员套餐
              </p>
              <p className="text-xs text-[#64748b] dark:text-[#94a3b8]">
                查看订阅方案
              </p>
            </div>
            <ChevronRight className="w-5 h-5 text-gray-400 group-hover:text-[#0ea5e9]" />
          </div>
        </Link>
      </div>

      {/* 当前会员状态 */}
      <div className="bg-white dark:bg-[#1e293b] border border-[#e2e8f0] dark:border-[#334155] rounded-xl p-5 mb-6">
        <div className="flex items-center gap-4 mb-3">
          <div className={`w-11 h-11 ${isMember ? 'bg-gradient-to-br from-amber-500 to-orange-500' : 'bg-gray-200 dark:bg-gray-700'} rounded-xl flex items-center justify-center`}>
            <Crown className={`w-5 h-5 ${isMember ? 'text-white' : 'text-gray-400'}`} />
          </div>
          <div className="flex-1">
            <div className="flex items-center gap-2">
              <h2 className="text-base font-bold text-[#1e293b] dark:text-white">
                {isMember ? '尊贵会员' : '普通用户'}
              </h2>
              {membership && getStatusBadge(membership.status)}
            </div>
            <p className="text-xs text-[#64748b] dark:text-[#94a3b8] mt-0.5">
              {isMember 
                ? membership?.membership_plans?.name 
                : '订阅会员，解锁全站付费内容'}
            </p>
          </div>
        </div>

        {isMember && membership && (
          <div className="grid grid-cols-3 gap-3 mt-4 pt-4 border-t border-[#e2e8f0] dark:border-[#334155]">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 bg-blue-100 dark:bg-blue-900/30 rounded-lg flex items-center justify-center">
                <Crown className="w-4 h-4 text-blue-600" />
              </div>
              <div>
                <p className="text-[10px] text-[#64748b] dark:text-[#94a3b8]">套餐类型</p>
                <p className="text-xs font-medium text-[#1e293b] dark:text-white">
                  {membership.membership_plans?.name}
                </p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 bg-green-100 dark:bg-green-900/30 rounded-lg flex items-center justify-center">
                <Clock className="w-4 h-4 text-green-600" />
              </div>
              <div>
                <p className="text-[10px] text-[#64748b] dark:text-[#94a3b8]">
                  {membership.expired_at ? '到期时间' : '有效期'}
                </p>
                <p className="text-xs font-medium text-[#1e293b] dark:text-white">
                  {membership.expired_at 
                    ? new Date(membership.expired_at).toLocaleDateString('zh-CN')
                    : '永久有效'}
                </p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 bg-purple-100 dark:bg-purple-900/30 rounded-lg flex items-center justify-center">
                <CreditCard className="w-4 h-4 text-purple-600" />
              </div>
              <div>
                <p className="text-[10px] text-[#64748b] dark:text-[#94a3b8]">开通时间</p>
                <p className="text-xs font-medium text-[#1e293b] dark:text-white">
                  {new Date(membership.started_at).toLocaleDateString('zh-CN')}
                </p>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* 订阅套餐 */}
      {!isMember && plans.length > 0 && (
        <div>
          <h2 className="text-base font-bold text-[#1e293b] dark:text-white mb-3">
            选择套餐
          </h2>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            {plans.map((plan) => {
              const isSelected = selectedPlan === plan.id;
              return (
                <div
                  key={plan.id}
                  onClick={() => setSelectedPlan(plan.id)}
                  className={`bg-white dark:bg-[#1e293b] border-2 rounded-xl p-3 cursor-pointer transition-all ${
                    isSelected 
                      ? 'border-[#0ea5e9] shadow-lg shadow-[#0ea5e9]/10' 
                      : 'border-[#e2e8f0] dark:border-[#334155] hover:border-[#0ea5e9]/50'
                  }`}
                >
                  <div className="flex items-center gap-1.5 mb-2">
                    <Crown className="w-4 h-4 text-amber-500" />
                    <span className="font-semibold text-xs text-[#1e293b] dark:text-white">
                      {plan.name}
                    </span>
                  </div>
                  <div className="flex items-baseline gap-1 mb-1">
                    <span className="text-lg font-bold text-[#0ea5e9]">
                      ¥{plan.price}
                    </span>
                    {plan.original_price && (
                      <span className="text-[10px] text-gray-400 line-through">
                        ¥{plan.original_price}
                      </span>
                    )}
                  </div>
                  <p className="text-[10px] text-[#64748b] dark:text-[#94a3b8]">
                    {getDurationText(plan.duration_days)}
                  </p>
                </div>
              );
            })}
          </div>

          {/* 支付方式选择 */}
          {paymentMethods.length > 0 && (
            <div className="mt-4">
              <h3 className="text-sm font-medium text-[#1e293b] dark:text-white mb-2">
                支付方式
              </h3>
              <div className="flex flex-wrap gap-2">
                {paymentMethods.map((method) => {
                  const isSelected = selectedPaymentMethod === method.payment_method;
                  const methodLabels: Record<string, string> = {
                    alipay: '支付宝',
                    wechat: '微信支付',
                    paypal: 'PayPal',
                    stripe: 'Stripe',
                  };
                  return (
                    <button
                      key={method.payment_method}
                      onClick={() => setSelectedPaymentMethod(method.payment_method)}
                      className={`px-4 py-2 rounded-lg text-sm transition-all ${
                        isSelected
                          ? 'bg-[#0ea5e9] text-white'
                          : 'bg-gray-100 dark:bg-gray-800 text-gray-700 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-700'
                      }`}
                    >
                      {methodLabels[method.payment_method] || method.display_name}
                    </button>
                  );
                })}
              </div>
            </div>
          )}

          {/* PayPal支付区域 */}
          {showPayPal && pendingOrderId && selectedPlan && (
            <div className="mt-4 p-4 bg-white dark:bg-[#1e293b] border border-[#e2e8f0] dark:border-[#334155] rounded-xl">
              <div className="flex items-center justify-between mb-3">
                <h4 className="font-medium text-[#1e293b] dark:text-white">PayPal支付</h4>
                <button
                  onClick={() => {
                    setShowPayPal(false);
                    setPendingOrderId(null);
                  }}
                  className="text-sm text-gray-500 hover:text-gray-700"
                >
                  取消
                </button>
              </div>
              <PayPalButton
                orderId={pendingOrderId}
                amount={parseFloat(plans.find(p => p.id === selectedPlan)?.price || '0')}
                onSuccess={handlePayPalSuccess}
                onError={handlePayPalError}
                onCancel={handlePayPalCancel}
              />
            </div>
          )}

          {/* 订阅按钮（非PayPal时显示） */}
          {!showPayPal && (
            <button
              onClick={handleSubscribe}
              disabled={!selectedPlan || isPaying}
              className={`w-full mt-4 py-3 rounded-xl font-medium transition-all flex items-center justify-center gap-2 ${
                selectedPlan
                  ? 'bg-[#0ea5e9] text-white hover:bg-[#0284c7] shadow-lg shadow-[#0ea5e9]/25'
                  : 'bg-gray-200 dark:bg-gray-700 text-gray-400 cursor-not-allowed'
              }`}
            >
              {isPaying ? (
                <>
                  <Loader2 className="w-5 h-5 animate-spin" />
                  正在创建订单...
                </>
              ) : (
                <>
                  <CreditCard className="w-5 h-5" />
                  立即订阅
                </>
              )}
            </button>
          )}
        </div>
      )}

      {/* 会员权益说明 */}
      <div className="mt-6 p-4 bg-[#f8fafc] dark:bg-[#1e293b]/50 border border-[#e2e8f0] dark:border-[#334155] rounded-xl">
        <h3 className="font-semibold text-[#1e293b] dark:text-white mb-2 text-sm">
          会员权益
        </h3>
        <ul className="space-y-1.5">
          <li className="flex items-center gap-2 text-xs text-[#475569] dark:text-[#cbd5e1]">
            <CheckCircle className="w-3.5 h-3.5 text-green-500" />
            无限阅读全站所有付费文章
          </li>
          <li className="flex items-center gap-2 text-xs text-[#475569] dark:text-[#cbd5e1]">
            <CheckCircle className="w-3.5 h-3.5 text-green-500" />
            显示尊贵会员专属标识
          </li>
          <li className="flex items-center gap-2 text-xs text-[#475569] dark:text-[#cbd5e1]">
            <CheckCircle className="w-3.5 h-3.5 text-green-500" />
            享受专属客服优先支持
          </li>
          <li className="flex items-center gap-2 text-xs text-[#475569] dark:text-[#cbd5e1]">
            <CheckCircle className="w-3.5 h-3.5 text-green-500" />
            支持作者持续创作优质内容
          </li>
        </ul>
      </div>

      {/* 支付宝二维码弹窗 */}
      {showAlipayQR && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm">
          <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-2xl p-6 max-w-sm w-full mx-4 relative">
            <button
              onClick={handleCloseAlipayQR}
              className="absolute top-4 right-4 p-1 rounded-full hover:bg-gray-100 dark:hover:bg-gray-700"
            >
              <X className="w-5 h-5 text-gray-500" />
            </button>

            {paid ? (
              <div className="flex flex-col items-center py-8">
                <CheckCircle className="w-16 h-16 text-green-500 mb-4" />
                <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-2">支付成功</h3>
                <p className="text-gray-500">正在跳转到会员中心...</p>
              </div>
            ) : (
              <>
                <div className="text-center mb-4">
                  <h3 className="text-lg font-bold text-gray-900 dark:text-white flex items-center justify-center gap-2">
                    <CreditCard className="w-5 h-5 text-[#1677ff]" />
                    支付宝扫码支付
                  </h3>
                  <p className="text-2xl font-bold text-[#1677ff] mt-2">¥{pendingAmount.toFixed(2)}</p>
                </div>

                {alipayQRCode && (
                  <div className="flex flex-col items-center">
                    <div className="bg-white p-4 rounded-lg shadow-inner">
                      <img 
                        src={`https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=${encodeURIComponent(alipayQRCode)}`}
                        alt="支付二维码"
                        width={200}
                        height={200}
                        className="rounded"
                      />
                    </div>
                    <p className="mt-3 text-sm text-gray-500">请使用支付宝扫码支付</p>
                  </div>
                )}

                <div className="mt-4 flex items-center justify-center gap-2 text-sm text-gray-500">
                  <Loader2 className="w-4 h-4 animate-spin" />
                  <span>等待支付中...</span>
                </div>

                <p className="text-xs text-gray-400 text-center mt-3">
                  请在30分钟内完成支付，支付成功后将自动跳转
                </p>
              </>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
