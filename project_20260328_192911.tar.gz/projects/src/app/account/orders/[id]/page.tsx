'use client';

import { useState, useEffect, use } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { 
  Clock, 
  CheckCircle, 
  XCircle, 
  Loader2, 
  Receipt, 
  Crown, 
  FileText,
  LogOut,
  ChevronRight,
  ArrowLeft,
  CreditCard,
  QrCode,
  AlertCircle
} from 'lucide-react';
import { AlipayButton } from '@/components/alipay-button';

interface Order {
  id: string;
  order_no: string;
  amount: string;
  currency: string;
  payment_method: string;
  payment_status: string;
  transaction_id: string;
  created_at: string;
  paid_at: string;
  metadata?: {
    plan_id?: string;
    plan_name?: string;
    duration_days?: number;
    post_id?: string;
    post_title?: string;
    post_slug?: string;
  };
  membership_plans?: {
    id: string;
    name: string;
    price: string;
    duration_days: number;
  };
  post_purchases?: Array<{
    id: string;
    post_id: string;
    price: string;
    posts: {
      id: string;
      title: string;
      slug: string;
    };
  }>;
}

interface UserInfo {
  userId: string;
  username: string;
  email: string;
  display_name: string;
}

export default function OrderDetailPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = use(params);
  const router = useRouter();
  const [isLoading, setIsLoading] = useState(true);
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [userInfo, setUserInfo] = useState<UserInfo | null>(null);
  const [order, setOrder] = useState<Order | null>(null);
  const [isCancelling, setIsCancelling] = useState(false);
  const [showPayment, setShowPayment] = useState(false);

  useEffect(() => {
    fetchData();
  }, [id]);

  const fetchData = async () => {
    try {
      // 获取用户信息
      const authResponse = await fetch('/api/auth/me');
      if (authResponse.ok) {
        const authData = await authResponse.json();
        setUserInfo(authData.user);
        setIsLoggedIn(true);
      } else {
        setIsLoggedIn(false);
        setIsLoading(false);
        return;
      }

      // 获取订单详情
      const response = await fetch(`/api/orders/${id}`);
      if (response.ok) {
        const data = await response.json();
        setOrder(data.order);
      } else {
        setOrder(null);
      }
    } catch (error) {
      console.error('Failed to fetch order:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleCancel = async () => {
    if (!order) return;
    
    if (!confirm('确定要取消这个订单吗？')) return;
    
    setIsCancelling(true);
    try {
      const response = await fetch(`/api/orders/${order.id}`, {
        method: 'DELETE',
      });

      const data = await response.json();
      if (response.ok) {
        alert('订单已取消');
        router.push('/account/orders');
      } else {
        alert(data.error || '取消订单失败');
      }
    } catch (error) {
      console.error('Cancel order error:', error);
      alert('取消订单失败');
    } finally {
      setIsCancelling(false);
    }
  };

  const handlePaymentSuccess = () => {
    setShowPayment(false);
    alert('支付成功！');
    fetchData();
    setTimeout(() => {
      router.push('/account/membership?success=true');
    }, 1500);
  };

  const getStatusBadge = (status: string) => {
    const styles: Record<string, { bg: string; text: string; icon: typeof Clock }> = {
      pending: { bg: 'bg-amber-100 dark:bg-amber-900/30', text: 'text-amber-700 dark:text-amber-400', icon: Clock },
      paid: { bg: 'bg-green-100 dark:bg-green-900/30', text: 'text-green-700 dark:text-green-400', icon: CheckCircle },
      failed: { bg: 'bg-red-100 dark:bg-red-900/30', text: 'text-red-700 dark:text-red-400', icon: XCircle },
      cancelled: { bg: 'bg-gray-100 dark:bg-gray-800', text: 'text-gray-700 dark:text-gray-400', icon: XCircle },
      refunded: { bg: 'bg-gray-100 dark:bg-gray-800', text: 'text-gray-700 dark:text-gray-400', icon: XCircle },
    };
    const labels: Record<string, string> = {
      pending: '待支付',
      paid: '已支付',
      failed: '支付失败',
      cancelled: '已取消',
      refunded: '已退款',
    };
    const style = styles[status] || styles.pending;
    const Icon = style.icon;
    
    return (
      <span className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full text-sm font-medium ${style.bg} ${style.text}`}>
        <Icon className="w-4 h-4" />
        {labels[status] || status}
      </span>
    );
  };

  const getOrderType = () => {
    if (order?.membership_plans || order?.metadata?.plan_name) {
      return { type: 'membership', label: '会员订阅', icon: Crown };
    }
    if (order?.post_purchases?.length || order?.metadata?.post_title) {
      return { type: 'post', label: '文章购买', icon: FileText };
    }
    return { type: 'unknown', label: '其他', icon: Receipt };
  };

  const getPaymentMethodName = (method: string) => {
    const names: Record<string, string> = {
      alipay: '支付宝',
      wechat: '微信支付',
      stripe: 'Stripe',
      paypal: 'PayPal',
    };
    return names[method] || method;
  };

  const getDurationText = (days: number) => {
    if (days === 0) return '永久';
    if (days === 30) return '1个月';
    if (days === 365) return '1年';
    return `${days}天`;
  };

  if (isLoading) {
    return (
      <div className="max-w-2xl mx-auto py-12">
        <div className="flex items-center justify-center">
          <Loader2 className="w-8 h-8 animate-spin text-[#0ea5e9]" />
        </div>
      </div>
    );
  }

  if (!isLoggedIn) {
    return (
      <div className="max-w-2xl mx-auto py-12">
        <div className="text-center">
          <Receipt className="w-16 h-16 mx-auto text-gray-400 mb-4" />
          <h1 className="text-2xl font-bold text-gray-900 dark:text-white mb-4">
            请先登录
          </h1>
          <p className="text-gray-500 dark:text-gray-400 mb-6">
            登录后查看订单详情
          </p>
          <Link
            href="/admin/login"
            className="inline-flex items-center gap-2 px-6 py-3 bg-[#0ea5e9] text-white rounded-lg hover:bg-[#0284c7] transition-colors"
          >
            前往登录
          </Link>
        </div>
      </div>
    );
  }

  if (!order) {
    return (
      <div className="max-w-2xl mx-auto py-12">
        <div className="text-center">
          <AlertCircle className="w-16 h-16 mx-auto text-gray-400 mb-4" />
          <h1 className="text-2xl font-bold text-gray-900 dark:text-white mb-4">
            订单不存在
          </h1>
          <Link
            href="/account/orders"
            className="inline-flex items-center gap-2 px-6 py-3 bg-[#0ea5e9] text-white rounded-lg hover:bg-[#0284c7] transition-colors"
          >
            返回订单列表
          </Link>
        </div>
      </div>
    );
  }

  const orderType = getOrderType();
  const TypeIcon = orderType.icon;

  return (
    <div className="max-w-2xl mx-auto py-8">
      {/* Breadcrumb */}
      <nav className="flex items-center gap-2 text-sm text-[#64748b] dark:text-[#94a3b8] mb-6">
        <Link href="/" className="hover:text-[#0ea5e9] transition-colors">首页</Link>
        <ChevronRight className="w-4 h-4" />
        <Link href="/account/membership" className="hover:text-[#0ea5e9] transition-colors">会员中心</Link>
        <ChevronRight className="w-4 h-4" />
        <Link href="/account/orders" className="hover:text-[#0ea5e9] transition-colors">订单记录</Link>
        <ChevronRight className="w-4 h-4" />
        <span className="text-[#1e293b] dark:text-white">订单详情</span>
      </nav>

      {/* 返回按钮 */}
      <button
        onClick={() => router.back()}
        className="flex items-center gap-2 text-[#64748b] dark:text-[#94a3b8] hover:text-[#0ea5e9] transition-colors mb-6"
      >
        <ArrowLeft className="w-4 h-4" />
        返回
      </button>

      {/* 订单状态卡片 */}
      <div className="bg-white dark:bg-[#1e293b] border border-[#e2e8f0] dark:border-[#334155] rounded-xl p-6 mb-6">
        <div className="flex items-center justify-between mb-4">
          <h1 className="text-xl font-bold text-[#1e293b] dark:text-white">
            订单详情
          </h1>
          {getStatusBadge(order.payment_status)}
        </div>

        {/* 订单金额 */}
        <div className="text-center py-6 border-y border-[#e2e8f0] dark:border-[#334155]">
          <p className="text-sm text-[#64748b] dark:text-[#94a3b8] mb-2">订单金额</p>
          <p className="text-4xl font-bold text-[#1e293b] dark:text-white">
            ¥{order.amount}
          </p>
        </div>

        {/* 待支付提示 */}
        {order.payment_status === 'pending' && !showPayment && (
          <div className="mt-4 p-4 bg-amber-50 dark:bg-amber-900/20 border border-amber-200 dark:border-amber-800 rounded-lg">
            <div className="flex items-center gap-2 text-amber-700 dark:text-amber-400 mb-3">
              <Clock className="w-5 h-5" />
              <span className="font-medium">等待支付</span>
            </div>
            <p className="text-sm text-amber-600 dark:text-amber-500 mb-4">
              请在30分钟内完成支付，超时订单将自动取消
            </p>
            <div className="flex gap-3">
              <button
                onClick={() => setShowPayment(true)}
                className="flex-1 py-2.5 bg-[#0ea5e9] text-white rounded-lg hover:bg-[#0284c7] transition-colors font-medium"
              >
                立即支付
              </button>
              <button
                onClick={handleCancel}
                disabled={isCancelling}
                className="px-4 py-2.5 border border-gray-300 dark:border-gray-600 text-gray-600 dark:text-gray-400 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-800 transition-colors"
              >
                {isCancelling ? <Loader2 className="w-5 h-5 animate-spin" /> : '取消订单'}
              </button>
            </div>
          </div>
        )}

        {/* 支付区域 */}
        {order.payment_status === 'pending' && showPayment && (
          <div className="mt-4 p-4 bg-gray-50 dark:bg-gray-800/50 border border-gray-200 dark:border-gray-700 rounded-lg">
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-medium text-[#1e293b] dark:text-white">选择支付方式</h3>
              <button
                onClick={() => setShowPayment(false)}
                className="text-sm text-gray-500 hover:text-gray-700"
              >
                返回
              </button>
            </div>
            <AlipayButton
              orderId={order.id}
              amount={parseFloat(order.amount)}
              onSuccess={handlePaymentSuccess}
            />
          </div>
        )}

        {/* 支付成功提示 */}
        {order.payment_status === 'paid' && (
          <div className="mt-4 p-4 bg-green-50 dark:bg-green-900/20 border border-green-200 dark:border-green-800 rounded-lg">
            <div className="flex items-center gap-2 text-green-700 dark:text-green-400">
              <CheckCircle className="w-5 h-5" />
              <span className="font-medium">支付成功</span>
            </div>
            {orderType.type === 'membership' && (
              <Link
                href="/account/membership"
                className="mt-3 inline-flex items-center gap-2 text-sm text-green-600 hover:text-green-700"
              >
                查看会员状态 <ChevronRight className="w-4 h-4" />
              </Link>
            )}
            {orderType.type === 'post' && order.metadata?.post_slug && (
              <Link
                href={`/post/${order.metadata.post_slug}`}
                className="mt-3 inline-flex items-center gap-2 text-sm text-green-600 hover:text-green-700"
              >
                阅读文章 <ChevronRight className="w-4 h-4" />
              </Link>
            )}
          </div>
        )}

        {/* 已取消提示 */}
        {order.payment_status === 'cancelled' && (
          <div className="mt-4 p-4 bg-gray-50 dark:bg-gray-800/50 border border-gray-200 dark:border-gray-700 rounded-lg">
            <div className="flex items-center gap-2 text-gray-600 dark:text-gray-400">
              <XCircle className="w-5 h-5" />
              <span className="font-medium">订单已取消</span>
            </div>
          </div>
        )}
      </div>

      {/* 订单信息 */}
      <div className="bg-white dark:bg-[#1e293b] border border-[#e2e8f0] dark:border-[#334155] rounded-xl p-6 mb-6">
        <h2 className="font-semibold text-[#1e293b] dark:text-white mb-4">订单信息</h2>
        
        <div className="space-y-4">
          <div className="flex items-center justify-between py-3 border-b border-[#e2e8f0] dark:border-[#334155]">
            <span className="text-sm text-[#64748b] dark:text-[#94a3b8]">订单编号</span>
            <span className="text-sm font-mono text-[#1e293b] dark:text-white">{order.order_no}</span>
          </div>

          <div className="flex items-center justify-between py-3 border-b border-[#e2e8f0] dark:border-[#334155]">
            <span className="text-sm text-[#64748b] dark:text-[#94a3b8]">订单类型</span>
            <span className="text-sm text-[#1e293b] dark:text-white flex items-center gap-2">
              <TypeIcon className="w-4 h-4" />
              {orderType.label}
            </span>
          </div>

          <div className="flex items-center justify-between py-3 border-b border-[#e2e8f0] dark:border-[#334155]">
            <span className="text-sm text-[#64748b] dark:text-[#94a3b8]">支付方式</span>
            <span className="text-sm text-[#1e293b] dark:text-white">
              {getPaymentMethodName(order.payment_method || '')}
            </span>
          </div>

          <div className="flex items-center justify-between py-3 border-b border-[#e2e8f0] dark:border-[#334155]">
            <span className="text-sm text-[#64748b] dark:text-[#94a3b8]">创建时间</span>
            <span className="text-sm text-[#1e293b] dark:text-white">
              {new Date(order.created_at).toLocaleString('zh-CN')}
            </span>
          </div>

          {order.paid_at && (
            <div className="flex items-center justify-between py-3 border-b border-[#e2e8f0] dark:border-[#334155]">
              <span className="text-sm text-[#64748b] dark:text-[#94a3b8]">支付时间</span>
              <span className="text-sm text-[#1e293b] dark:text-white">
                {new Date(order.paid_at).toLocaleString('zh-CN')}
              </span>
            </div>
          )}

          {order.transaction_id && (
            <div className="flex items-center justify-between py-3">
              <span className="text-sm text-[#64748b] dark:text-[#94a3b8]">交易流水号</span>
              <span className="text-sm font-mono text-[#1e293b] dark:text-white">{order.transaction_id}</span>
            </div>
          )}
        </div>
      </div>

      {/* 商品信息 */}
      <div className="bg-white dark:bg-[#1e293b] border border-[#e2e8f0] dark:border-[#334155] rounded-xl p-6">
        <h2 className="font-semibold text-[#1e293b] dark:text-white mb-4">商品信息</h2>
        
        {orderType.type === 'membership' && (
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 bg-amber-100 dark:bg-amber-900/30 rounded-lg flex items-center justify-center">
              <Crown className="w-6 h-6 text-amber-600" />
            </div>
            <div className="flex-1">
              <p className="font-medium text-[#1e293b] dark:text-white">
                {order.membership_plans?.name || order.metadata?.plan_name}
              </p>
              <p className="text-sm text-[#64748b] dark:text-[#94a3b8]">
                有效期：{getDurationText(order.metadata?.duration_days || order.membership_plans?.duration_days || 30)}
              </p>
            </div>
            <p className="font-semibold text-[#1e293b] dark:text-white">
              ¥{order.membership_plans?.price || order.amount}
            </p>
          </div>
        )}

        {orderType.type === 'post' && (
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 bg-blue-100 dark:bg-blue-900/30 rounded-lg flex items-center justify-center">
              <FileText className="w-6 h-6 text-blue-600" />
            </div>
            <div className="flex-1">
              <p className="font-medium text-[#1e293b] dark:text-white">
                {order.post_purchases?.[0]?.posts?.title || order.metadata?.post_title}
              </p>
              <p className="text-sm text-[#64748b] dark:text-[#94a3b8]">
                文章购买
              </p>
            </div>
            <p className="font-semibold text-[#1e293b] dark:text-white">
              ¥{order.post_purchases?.[0]?.price || order.amount}
            </p>
          </div>
        )}
      </div>
    </div>
  );
}
