'use client';

import { useState, useEffect } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { 
  Clock, 
  CheckCircle, 
  XCircle, 
  Loader2, 
  Receipt, 
  Crown, 
  FileText,
  LogOut,
  ChevronRight,
  CreditCard,
  Eye
} from 'lucide-react';

interface Order {
  id: string;
  order_no: string;
  amount: string | number;
  currency: string;
  payment_method: string;
  payment_status: string;
  transaction_id: string;
  created_at: string;
  paid_at: string;
  membership_plans?: {
    id: string;
    name: string;
    price: string;
    duration_days: number;
  };
  post_purchases?: Array<{
    id: string;
    post_id: string;
    price: string;
    posts: {
      id: string;
      title: string;
      slug: string;
    };
  }>;
  metadata?: {
    plan_name?: string;
    plan_id?: string;
    duration_days?: number;
    post_title?: string;
    post_slug?: string;
    post_id?: string;
  };
}

interface UserInfo {
  userId: string;
  username: string;
  email: string;
  display_name: string;
}

export default function OrdersPage() {
  const router = useRouter();
  const [isLoading, setIsLoading] = useState(true);
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [userInfo, setUserInfo] = useState<UserInfo | null>(null);
  const [orders, setOrders] = useState<Order[]>([]);
  const [total, setTotal] = useState(0);
  const [page, setPage] = useState(1);
  const [statusFilter, setStatusFilter] = useState('');
  const [isLoggingOut, setIsLoggingOut] = useState(false);

  useEffect(() => {
    fetchData();
  }, [page, statusFilter]);

  const fetchData = async () => {
    try {
      // 获取用户信息
      const authResponse = await fetch('/api/auth/me');
      if (authResponse.ok) {
        const authData = await authResponse.json();
        setUserInfo(authData.user);
        setIsLoggedIn(true);
      } else {
        setIsLoggedIn(false);
        setIsLoading(false);
        return;
      }

      // 获取订单列表
      let url = `/api/orders?page=${page}&pageSize=10`;
      if (statusFilter) url += `&status=${statusFilter}`;
      
      const response = await fetch(url);
      if (response.ok) {
        const data = await response.json();
        setOrders(data.orders || []);
        setTotal(data.total || 0);
      }
    } catch (error) {
      console.error('Failed to fetch orders:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleLogout = async () => {
    setIsLoggingOut(true);
    try {
      await fetch('/api/auth/logout', { method: 'POST' });
      router.push('/');
    } catch (error) {
      console.error('Logout error:', error);
    } finally {
      setIsLoggingOut(false);
    }
  };

  const getStatusBadge = (status: string) => {
    const styles: Record<string, { bg: string; text: string; icon: typeof Clock }> = {
      pending: { bg: 'bg-amber-100 dark:bg-amber-900/30', text: 'text-amber-700 dark:text-amber-400', icon: Clock },
      paid: { bg: 'bg-green-100 dark:bg-green-900/30', text: 'text-green-700 dark:text-green-400', icon: CheckCircle },
      failed: { bg: 'bg-red-100 dark:bg-red-900/30', text: 'text-red-700 dark:text-red-400', icon: XCircle },
      cancelled: { bg: 'bg-gray-100 dark:bg-gray-800', text: 'text-gray-700 dark:text-gray-400', icon: XCircle },
      refunded: { bg: 'bg-gray-100 dark:bg-gray-800', text: 'text-gray-700 dark:text-gray-400', icon: XCircle },
    };
    const labels: Record<string, string> = {
      pending: '待支付',
      paid: '已支付',
      failed: '支付失败',
      cancelled: '已取消',
      refunded: '已退款',
    };
    const style = styles[status] || styles.pending;
    const Icon = style.icon;
    
    return (
      <span className={`inline-flex items-center gap-1 px-2 py-1 rounded-full text-xs font-medium ${style.bg} ${style.text}`}>
        <Icon className="w-3 h-3" />
        {labels[status] || status}
      </span>
    );
  };

  const getOrderType = (order: Order) => {
    if (order.membership_plans || order.metadata?.plan_name) {
      return { type: 'membership', label: '会员订阅', icon: Crown };
    }
    if (order.post_purchases?.length || order.metadata?.post_title) {
      return { type: 'post', label: '文章购买', icon: FileText };
    }
    return { type: 'unknown', label: '其他', icon: Receipt };
  };

  const getPaymentMethodName = (method: string) => {
    const names: Record<string, string> = {
      alipay: '支付宝',
      wechat: '微信支付',
      stripe: 'Stripe',
      paypal: 'PayPal',
    };
    return names[method] || method || '未选择';
  };

  if (isLoading) {
    return (
      <div className="max-w-4xl mx-auto py-12">
        <div className="flex items-center justify-center">
          <Loader2 className="w-8 h-8 animate-spin text-[#0ea5e9]" />
        </div>
      </div>
    );
  }

  if (!isLoggedIn) {
    return (
      <div className="max-w-4xl mx-auto py-12">
        <div className="text-center">
          <Receipt className="w-16 h-16 mx-auto text-gray-400 mb-4" />
          <h1 className="text-2xl font-bold text-gray-900 dark:text-white mb-4">
            请先登录
          </h1>
          <p className="text-gray-500 dark:text-gray-400 mb-6">
            登录后查看您的订单记录
          </p>
          <Link
            href="/admin/login"
            className="inline-flex items-center gap-2 px-6 py-3 bg-[#0ea5e9] text-white rounded-lg hover:bg-[#0284c7] transition-colors"
          >
            前往登录
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto py-8">
      {/* Breadcrumb */}
      <nav className="flex items-center gap-2 text-sm text-[#64748b] dark:text-[#94a3b8] mb-6">
        <Link href="/" className="hover:text-[#0ea5e9] transition-colors">首页</Link>
        <ChevronRight className="w-4 h-4" />
        <Link href="/account/membership" className="hover:text-[#0ea5e9] transition-colors">会员中心</Link>
        <ChevronRight className="w-4 h-4" />
        <span className="text-[#1e293b] dark:text-white">订单记录</span>
      </nav>

      <div className="flex items-center justify-between mb-6">
        <h1 className="text-2xl font-bold text-[#1e293b] dark:text-white">
          订单记录
        </h1>
        <button
          onClick={handleLogout}
          disabled={isLoggingOut}
          className="inline-flex items-center gap-2 px-4 py-2 text-sm font-medium text-[#64748b] dark:text-[#94a3b8] hover:text-red-600 dark:hover:text-red-400 hover:bg-red-50 dark:hover:bg-red-900/20 rounded-lg transition-colors"
        >
          {isLoggingOut ? (
            <Loader2 className="w-4 h-4 animate-spin" />
          ) : (
            <LogOut className="w-4 h-4" />
          )}
          退出登录
        </button>
      </div>

      {/* 用户信息 */}
      {userInfo && (
        <div className="bg-white dark:bg-[#1e293b] border border-[#e2e8f0] dark:border-[#334155] rounded-xl p-4 mb-6">
          <div className="flex items-center gap-4">
            <div className="w-10 h-10 bg-gradient-to-br from-[#0ea5e9] to-[#06b6d4] rounded-lg flex items-center justify-center">
              <span className="text-white text-sm font-bold">
                {(userInfo.display_name || userInfo.username || 'U')[0].toUpperCase()}
              </span>
            </div>
            <div className="flex-1">
              <p className="font-medium text-sm text-[#1e293b] dark:text-white">
                {userInfo.display_name || userInfo.username}
              </p>
              <p className="text-xs text-[#64748b] dark:text-[#94a3b8]">
                {userInfo.email}
              </p>
            </div>
            <Link 
              href="/account/membership"
              className="text-sm text-[#0ea5e9] hover:underline"
            >
              返回会员中心
            </Link>
          </div>
        </div>
      )}

      {/* 筛选 */}
      <div className="flex items-center gap-2 mb-6 overflow-x-auto pb-2">
        <button
          onClick={() => setStatusFilter('')}
          className={`px-3 py-1.5 text-sm rounded-lg transition-colors whitespace-nowrap ${
            statusFilter === '' 
              ? 'bg-[#0ea5e9] text-white' 
              : 'bg-gray-100 dark:bg-gray-800 text-gray-600 dark:text-gray-400 hover:bg-gray-200 dark:hover:bg-gray-700'
          }`}
        >
          全部
        </button>
        <button
          onClick={() => setStatusFilter('pending')}
          className={`px-3 py-1.5 text-sm rounded-lg transition-colors whitespace-nowrap ${
            statusFilter === 'pending' 
              ? 'bg-[#0ea5e9] text-white' 
              : 'bg-gray-100 dark:bg-gray-800 text-gray-600 dark:text-gray-400 hover:bg-gray-200 dark:hover:bg-gray-700'
          }`}
        >
          待支付
        </button>
        <button
          onClick={() => setStatusFilter('paid')}
          className={`px-3 py-1.5 text-sm rounded-lg transition-colors whitespace-nowrap ${
            statusFilter === 'paid' 
              ? 'bg-[#0ea5e9] text-white' 
              : 'bg-gray-100 dark:bg-gray-800 text-gray-600 dark:text-gray-400 hover:bg-gray-200 dark:hover:bg-gray-700'
          }`}
        >
          已支付
        </button>
        <button
          onClick={() => setStatusFilter('cancelled')}
          className={`px-3 py-1.5 text-sm rounded-lg transition-colors whitespace-nowrap ${
            statusFilter === 'cancelled' 
              ? 'bg-[#0ea5e9] text-white' 
              : 'bg-gray-100 dark:bg-gray-800 text-gray-600 dark:text-gray-400 hover:bg-gray-200 dark:hover:bg-gray-700'
          }`}
        >
          已取消
        </button>
      </div>

      {/* 订单列表 */}
      {orders.length === 0 ? (
        <div className="bg-white dark:bg-[#1e293b] border border-[#e2e8f0] dark:border-[#334155] rounded-xl p-12 text-center">
          <Receipt className="w-12 h-12 mx-auto text-gray-400 mb-4" />
          <p className="text-gray-500 dark:text-gray-400 mb-4">暂无订单记录</p>
          <Link
            href="/membership"
            className="inline-flex items-center gap-2 px-4 py-2 bg-[#0ea5e9] text-white rounded-lg hover:bg-[#0284c7] transition-colors text-sm"
          >
            <Crown className="w-4 h-4" />
            开通会员
          </Link>
        </div>
      ) : (
        <div className="space-y-4">
          {orders.map((order) => {
            const orderType = getOrderType(order);
            const Icon = orderType.icon;
            
            return (
              <Link
                key={order.id}
                href={`/account/orders/${order.id}`}
                className="block bg-white dark:bg-[#1e293b] border border-[#e2e8f0] dark:border-[#334155] rounded-xl p-4 hover:border-[#0ea5e9] transition-colors"
              >
                <div className="flex items-start justify-between mb-3">
                  <div className="flex items-center gap-3">
                    <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${
                      orderType.type === 'membership' 
                        ? 'bg-amber-100 dark:bg-amber-900/30' 
                        : 'bg-blue-100 dark:bg-blue-900/30'
                    }`}>
                      <Icon className={`w-5 h-5 ${
                        orderType.type === 'membership' 
                          ? 'text-amber-600' 
                          : 'text-blue-600'
                      }`} />
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-medium text-[#1e293b] dark:text-white">
                          {orderType.label}
                        </span>
                        {getStatusBadge(order.payment_status)}
                      </div>
                      <p className="text-xs text-[#64748b] dark:text-[#94a3b8] mt-0.5">
                        {order.order_no}
                      </p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="text-lg font-bold text-[#1e293b] dark:text-white">
                      ¥{typeof order.amount === 'number' ? order.amount.toFixed(2) : order.amount}
                    </p>
                    <p className="text-xs text-[#64748b] dark:text-[#94a3b8]">
                      {getPaymentMethodName(order.payment_method || '')}
                    </p>
                  </div>
                </div>

                {/* 订单详情 */}
                <div className="pt-3 border-t border-[#e2e8f0] dark:border-[#334155]">
                  <div className="flex items-center justify-between">
                    <div className="flex-1">
                      {orderType.type === 'membership' && (
                        <p className="text-sm text-[#64748b] dark:text-[#94a3b8]">
                          套餐：{order.membership_plans?.name || order.metadata?.plan_name || '未知套餐'}
                        </p>
                      )}
                      {orderType.type === 'post' && (
                        <p className="text-sm text-[#64748b] dark:text-[#94a3b8]">
                          文章：{order.post_purchases?.[0]?.posts?.title || order.metadata?.post_title || '未知文章'}
                        </p>
                      )}
                    </div>
                    
                    {/* 待支付显示去支付按钮 */}
                    {order.payment_status === 'pending' && (
                      <span className="flex items-center gap-1.5 px-3 py-1.5 bg-amber-500 text-white text-xs font-medium rounded-lg">
                        <CreditCard className="w-3.5 h-3.5" />
                        去支付
                      </span>
                    )}
                    
                    {/* 已支付显示查看详情 */}
                    {order.payment_status === 'paid' && (
                      <span className="flex items-center gap-1.5 px-3 py-1.5 bg-[#0ea5e9] text-white text-xs font-medium rounded-lg">
                        <Eye className="w-3.5 h-3.5" />
                        查看详情
                      </span>
                    )}
                  </div>
                  <p className="text-xs text-[#94a3b8] mt-2">
                    创建时间：{new Date(order.created_at).toLocaleString('zh-CN')}
                    {order.paid_at && (
                      <span className="ml-3">
                        支付时间：{new Date(order.paid_at).toLocaleString('zh-CN')}
                      </span>
                    )}
                  </p>
                </div>
              </Link>
            );
          })}

          {/* 分页 */}
          {total > 10 && (
            <div className="flex items-center justify-center gap-4 mt-6">
              <button
                onClick={() => setPage(p => Math.max(1, p - 1))}
                disabled={page === 1}
                className="px-4 py-2 text-sm rounded-lg bg-gray-100 dark:bg-gray-800 text-gray-600 dark:text-gray-400 hover:bg-gray-200 dark:hover:bg-gray-700 disabled:opacity-50"
              >
                上一页
              </button>
              <span className="text-sm text-[#64748b] dark:text-[#94a3b8]">
                第 {page} 页，共 {Math.ceil(total / 10)} 页
              </span>
              <button
                onClick={() => setPage(p => p + 1)}
                disabled={page * 10 >= total}
                className="px-4 py-2 text-sm rounded-lg bg-gray-100 dark:bg-gray-800 text-gray-600 dark:text-gray-400 hover:bg-gray-200 dark:hover:bg-gray-700 disabled:opacity-50"
              >
                下一页
              </button>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
