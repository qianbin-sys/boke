'use client';

import Link from 'next/link';
import { usePathname, useRouter } from 'next/navigation';
import { 
  LayoutDashboard, 
  FileText, 
  FolderTree, 
  Users, 
  Settings, 
  CreditCard,
  LogOut,
  Home,
  Crown,
  Tag,
  MessageSquare,
  Image,
  Sparkles,
  Clock,
  Cpu
} from 'lucide-react';
import { Button } from '@/components/ui/button';

interface AdminSidebarProps {
  user?: {
    username: string;
    role: string;
    display_name?: string;
  } | null;
  siteName?: string;
}

const menuItems = [
  { href: '/admin', label: '仪表盘', icon: LayoutDashboard },
  { href: '/admin/ai-write', label: 'AI 写作', icon: Sparkles },
  { href: '/admin/ai-tasks', label: 'AI 自动任务', icon: Clock },
  { href: '/admin/ai-models', label: 'AI 模型配置', icon: Cpu },
  { href: '/admin/posts', label: '文章管理', icon: FileText },
  { href: '/admin/categories', label: '分类管理', icon: FolderTree },
  { href: '/admin/tags', label: '标签管理', icon: Tag },
  { href: '/admin/media', label: '媒体库', icon: Image },
  { href: '/admin/comments', label: '评论管理', icon: MessageSquare },
  { href: '/admin/users', label: '用户管理', icon: Users },
  { href: '/admin/membership/plans', label: '会员套餐', icon: Crown },
  { href: '/admin/membership/users', label: '会员用户', icon: Users },
  { href: '/admin/payment', label: '支付配置', icon: CreditCard },
  { href: '/admin/settings', label: '网站设置', icon: Settings },
];

export function AdminSidebar({ user, siteName }: AdminSidebarProps) {
  const pathname = usePathname();
  const router = useRouter();

  const handleLogout = async () => {
    await fetch('/api/auth/logout', { 
      method: 'POST',
      credentials: 'include',
    });
    router.push('/admin/login');
  };

  if (!user) {
    return null;
  }

  return (
    <aside className="fixed left-0 top-0 z-40 h-screen w-64 bg-white dark:bg-gray-800 shadow-lg flex flex-col">
      {/* 网站名称 */}
      <div className="flex-shrink-0 p-4 border-b dark:border-gray-700">
        <Link href="/" className="text-lg font-bold text-gray-900 dark:text-white hover:text-blue-600 dark:hover:text-blue-400 transition-colors">
          {siteName || '我的博客'}
        </Link>
      </div>
      
      {/* 用户信息 */}
      <div className="flex-shrink-0 px-4 py-3 border-b dark:border-gray-700">
        <p className="text-sm text-gray-500 dark:text-gray-400">
          欢迎，<span className="font-medium text-gray-900 dark:text-white">{user.display_name || user.username}</span>
        </p>
      </div>
      
      {/* 导航菜单 - 可滚动区域 */}
      <nav className="flex-1 overflow-y-auto p-3 space-y-1">
        {menuItems.map((item) => {
          const Icon = item.icon;
          const isActive = pathname === item.href || 
            (item.href !== '/admin' && pathname.startsWith(item.href));
          
          return (
            <Link
              key={item.href}
              href={item.href}
              className={`flex items-center gap-3 px-3 py-2 rounded-lg transition-colors ${
                isActive
                  ? 'bg-blue-500 text-white'
                  : 'text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700'
              }`}
            >
              <Icon size={18} />
              <span className="font-medium">{item.label}</span>
            </Link>
          );
        })}
      </nav>
      
      {/* 底部操作区 */}
      <div className="flex-shrink-0 p-3 border-t dark:border-gray-700 bg-white dark:bg-gray-800">
        <Link
          href="/"
          className="flex items-center gap-3 px-3 py-2 rounded-lg text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700 mb-2"
        >
          <Home size={18} />
          <span className="font-medium">返回前台</span>
        </Link>
        <Button
          variant="outline"
          className="w-full flex items-center justify-center gap-2"
          onClick={handleLogout}
        >
          <LogOut size={18} />
          <span>退出登录</span>
        </Button>
      </div>
    </aside>
  );
}
