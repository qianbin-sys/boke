'use client';

import { useState, useEffect } from 'react';
import Link from 'next/link';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent } from '@/components/ui/card';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import { Badge } from '@/components/ui/badge';
import { Checkbox } from '@/components/ui/checkbox';
import { Plus, Search, Edit, Trash2, ChevronLeft, ChevronRight, CheckSquare, Square, XCircle, Loader2 } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

interface Post {
  id: string;
  title: string;
  slug: string;
  status: string;
  view_count: number;
  created_at: string;
  categories: { id: string; name: string } | null;
  users: { id: string; username: string; display_name?: string } | null;
}

interface Category {
  id: string;
  name: string;
}

export default function PostsPage() {
  const [posts, setPosts] = useState<Post[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [loading, setLoading] = useState(true);
  const [page, setPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [categoryFilter, setCategoryFilter] = useState('all');
  
  // 批量选择相关状态
  const [selectMode, setSelectMode] = useState(false);
  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set());
  const [batchDeleteOpen, setBatchDeleteOpen] = useState(false);
  const [batchDeleting, setBatchDeleting] = useState(false);
  
  const { toast } = useToast();

  useEffect(() => {
    fetchCategories();
  }, []);

  useEffect(() => {
    fetchPosts();
  }, [page, statusFilter, categoryFilter, search]);

  // 筛选条件变化时清空选择
  useEffect(() => {
    setSelectedIds(new Set());
    setSelectMode(false);
  }, [page, statusFilter, categoryFilter, search]);

  const fetchCategories = async () => {
    try {
      const response = await fetch('/api/categories');
      const data = await response.json();
      setCategories(data.categories || []);
    } catch (error) {
      console.error('Failed to fetch categories:', error);
    }
  };

  const fetchPosts = async () => {
    setLoading(true);
    try {
      const params = new URLSearchParams({
        page: page.toString(),
        limit: '10',
        ...(statusFilter !== 'all' && { status: statusFilter }),
        ...(categoryFilter !== 'all' && { category_id: categoryFilter }),
        ...(search && { search }),
      });

      const response = await fetch(`/api/posts?${params}`);
      const data = await response.json();
      
      setPosts(data.posts || []);
      setTotalPages(data.totalPages || 1);
    } catch (error) {
      console.error('Failed to fetch posts:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async (id: string) => {
    if (!confirm('确定要删除这篇文章吗？')) return;

    try {
      const response = await fetch(`/api/posts/${id}`, {
        method: 'DELETE',
      });

      if (response.ok) {
        fetchPosts();
        toast({ title: '删除成功' });
      } else {
        const data = await response.json();
        toast({ title: data.error || '删除失败', variant: 'destructive' });
      }
    } catch (error) {
      console.error('Failed to delete post:', error);
      toast({ title: '删除失败', variant: 'destructive' });
    }
  };

  // 批量删除
  const handleBatchDelete = async () => {
    if (selectedIds.size === 0) return;

    setBatchDeleting(true);
    try {
      const deletePromises = Array.from(selectedIds).map(id =>
        fetch(`/api/posts/${id}`, { method: 'DELETE' })
      );
      
      const results = await Promise.allSettled(deletePromises);
      const successCount = results.filter(r => r.status === 'fulfilled').length;
      const failCount = results.length - successCount;

      if (failCount === 0) {
        toast({
          title: '批量删除成功',
          description: `已删除 ${successCount} 篇文章`,
        });
      } else {
        toast({
          title: '批量删除完成',
          description: `成功 ${successCount} 篇，失败 ${failCount} 篇`,
          variant: 'destructive',
        });
      }
      
      setSelectedIds(new Set());
      setSelectMode(false);
      fetchPosts();
    } catch (error) {
      console.error('Batch delete error:', error);
      toast({ title: '批量删除失败', variant: 'destructive' });
    } finally {
      setBatchDeleting(false);
      setBatchDeleteOpen(false);
    }
  };

  // 切换选择模式
  const toggleSelectMode = () => {
    setSelectMode(!selectMode);
    setSelectedIds(new Set());
  };

  // 切换单个选择
  const toggleSelect = (id: string) => {
    const newSelected = new Set(selectedIds);
    if (newSelected.has(id)) {
      newSelected.delete(id);
    } else {
      newSelected.add(id);
    }
    setSelectedIds(newSelected);
  };

  // 全选/取消全选
  const toggleSelectAll = () => {
    if (selectedIds.size === posts.length) {
      setSelectedIds(new Set());
    } else {
      setSelectedIds(new Set(posts.map(p => p.id)));
    }
  };

  const getStatusBadge = (status: string) => {
    const variants: Record<string, { className: string; label: string }> = {
      published: { className: 'bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-400', label: '已发布' },
      draft: { className: 'bg-gray-100 text-gray-700 dark:bg-gray-700 dark:text-gray-300', label: '草稿' },
      private: { className: 'bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-400', label: '私密' },
    };
    const { className, label } = variants[status] || { className: 'bg-gray-100 text-gray-700', label: status };
    return <span className={`px-2 py-1 rounded text-xs font-medium ${className}`}>{label}</span>;
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('zh-CN', {
      year: 'numeric',
      month: '2-digit',
      day: '2-digit',
    });
  };

  return (
    <div className="p-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 mb-6">
        <div>
          <h1 className="text-2xl font-bold text-gray-900 dark:text-white">文章管理</h1>
          <p className="text-gray-500 dark:text-gray-400 mt-1">管理所有博客文章</p>
        </div>
        <div className="flex gap-2">
          {/* 批量操作按钮 */}
          {selectMode ? (
            <>
              <Button
                variant="outline"
                onClick={toggleSelectAll}
                className="gap-2"
              >
                {selectedIds.size === posts.length ? (
                  <>
                    <CheckSquare className="w-4 h-4" />
                    取消全选
                  </>
                ) : (
                  <>
                    <Square className="w-4 h-4" />
                    全选
                  </>
                )}
              </Button>
              <Button
                variant="destructive"
                onClick={() => setBatchDeleteOpen(true)}
                disabled={selectedIds.size === 0}
                className="gap-2"
              >
                <Trash2 className="w-4 h-4" />
                删除 ({selectedIds.size})
              </Button>
              <Button
                variant="ghost"
                onClick={toggleSelectMode}
                className="gap-2"
              >
                <XCircle className="w-4 h-4" />
                取消选择
              </Button>
            </>
          ) : (
            <>
              <Button
                variant="outline"
                onClick={toggleSelectMode}
                className="gap-2"
              >
                <CheckSquare className="w-4 h-4" />
                批量选择
              </Button>
              <Link href="/admin/posts/new">
                <Button>
                  <Plus className="mr-2 h-4 w-4" />
                  新建文章
                </Button>
              </Link>
            </>
          )}
        </div>
      </div>

      <Card>
        <CardContent className="p-0">
          {/* 筛选栏 */}
          <div className="p-4 border-b dark:border-gray-700 flex flex-col sm:flex-row gap-3">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" />
              <Input
                placeholder="搜索文章标题..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="pl-10"
              />
            </div>
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="w-full sm:w-[140px]">
                <SelectValue placeholder="状态" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">全部状态</SelectItem>
                <SelectItem value="published">已发布</SelectItem>
                <SelectItem value="draft">草稿</SelectItem>
                <SelectItem value="private">私密</SelectItem>
              </SelectContent>
            </Select>
            <Select value={categoryFilter} onValueChange={setCategoryFilter}>
              <SelectTrigger className="w-full sm:w-[140px]">
                <SelectValue placeholder="分类" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">全部分类</SelectItem>
                {categories.map((cat) => (
                  <SelectItem key={cat.id} value={cat.id}>
                    {cat.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* 表格 */}
          {loading ? (
            <div className="text-center py-12 text-gray-500">加载中...</div>
          ) : posts.length === 0 ? (
            <div className="text-center py-12 text-gray-500">
              <p>暂无文章</p>
              <Link href="/admin/posts/new" className="text-blue-500 hover:underline mt-2 inline-block">
                创建第一篇文章
              </Link>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow className="bg-gray-50 dark:bg-gray-800/50">
                    {selectMode && (
                      <TableHead className="w-12">
                        <Checkbox
                          checked={selectedIds.size === posts.length && posts.length > 0}
                          onCheckedChange={toggleSelectAll}
                        />
                      </TableHead>
                    )}
                    <TableHead className="font-medium">标题</TableHead>
                    <TableHead className="font-medium">分类</TableHead>
                    <TableHead className="font-medium">作者</TableHead>
                    <TableHead className="font-medium">状态</TableHead>
                    <TableHead className="font-medium">浏览</TableHead>
                    <TableHead className="font-medium">创建时间</TableHead>
                    <TableHead className="font-medium text-right">操作</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {posts.map((post) => (
                    <TableRow 
                      key={post.id} 
                      className={`hover:bg-gray-50 dark:hover:bg-gray-800/30 ${
                        selectedIds.has(post.id) ? 'bg-blue-50 dark:bg-blue-900/10' : ''
                      }`}
                    >
                      {selectMode && (
                        <TableCell>
                          <Checkbox
                            checked={selectedIds.has(post.id)}
                            onCheckedChange={() => toggleSelect(post.id)}
                          />
                        </TableCell>
                      )}
                      <TableCell className="font-medium max-w-[200px] truncate">{post.title}</TableCell>
                      <TableCell>{post.categories?.name || '未分类'}</TableCell>
                      <TableCell>{post.users?.display_name || post.users?.username}</TableCell>
                      <TableCell>{getStatusBadge(post.status)}</TableCell>
                      <TableCell>{post.view_count}</TableCell>
                      <TableCell className="text-gray-500">{formatDate(post.created_at)}</TableCell>
                      <TableCell className="text-right">
                        <div className="flex justify-end gap-2">
                          <Link href={`/admin/posts/${post.id}`}>
                            <Button variant="ghost" size="sm" className="h-8 w-8 p-0">
                              <Edit className="h-4 w-4" />
                            </Button>
                          </Link>
                          {!selectMode && (
                            <Button
                              variant="ghost"
                              size="sm"
                              className="h-8 w-8 p-0 text-red-500 hover:text-red-600 hover:bg-red-50"
                              onClick={() => handleDelete(post.id)}
                            >
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          )}
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}

          {/* 分页 */}
          {!loading && posts.length > 0 && (
            <div className="flex items-center justify-between p-4 border-t dark:border-gray-700">
              <p className="text-sm text-gray-500">
                第 {page} / {totalPages} 页
              </p>
              <div className="flex gap-2">
                <Button
                  variant="outline"
                  size="sm"
                  disabled={page === 1}
                  onClick={() => setPage(page - 1)}
                >
                  <ChevronLeft className="h-4 w-4" />
                  上一页
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  disabled={page === totalPages}
                  onClick={() => setPage(page + 1)}
                >
                  下一页
                  <ChevronRight className="h-4 w-4" />
                </Button>
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      {/* 批量删除确认对话框 */}
      <AlertDialog open={batchDeleteOpen} onOpenChange={setBatchDeleteOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>确认批量删除</AlertDialogTitle>
            <AlertDialogDescription>
              确定要删除选中的 {selectedIds.size} 篇文章吗？此操作不可撤销。
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={batchDeleting}>取消</AlertDialogCancel>
            <AlertDialogAction 
              onClick={handleBatchDelete} 
              className="bg-red-500 hover:bg-red-600"
              disabled={batchDeleting}
            >
              {batchDeleting ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  删除中...
                </>
              ) : (
                `删除 ${selectedIds.size} 篇文章`
              )}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
