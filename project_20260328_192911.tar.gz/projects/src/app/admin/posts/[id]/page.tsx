'use client';

import { useState, useEffect, useRef } from 'react';
import { useRouter, useParams } from 'next/navigation';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { ArrowLeft, Upload, X, Loader2, Hash, Plus, Image as ImageIcon, RefreshCw } from 'lucide-react';
import Link from 'next/link';
import { AISEOOptimizer } from '@/components/ai-seo-optimizer';
import { MediaPicker } from '@/components/media-picker';
import { generatePinyinSlug } from '@/lib/pinyin-slug';

interface Category {
  id: string;
  name: string;
}

interface Tag {
  id: string;
  name: string;
  slug: string;
}

interface PaymentMethod {
  id: string;
  payment_method: string;
  display_name: string;
  is_enabled: boolean;
}

export default function EditPostPage() {
  const router = useRouter();
  const params = useParams();
  const postId = params.id as string;
  const fileInputRef = useRef<HTMLInputElement>(null);
  
  const [categories, setCategories] = useState<Category[]>([]);
  const [tags, setTags] = useState<Tag[]>([]);
  const [paymentMethods, setPaymentMethods] = useState<PaymentMethod[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [error, setError] = useState('');
  const [mediaPickerOpen, setMediaPickerOpen] = useState(false);
  const [contentMediaPickerOpen, setContentMediaPickerOpen] = useState(false);
  
  const [formData, setFormData] = useState({
    title: '',
    slug: '',
    content: '',
    excerpt: '',
    category_id: '',
    status: 'draft',
    featured_image: '',
    // 付费相关
    is_paid: false,
    price: '',
    payment_methods: [] as string[],
    free_content: '',
    // 标签
    tag_ids: [] as string[],
    // SEO字段
    seo_title: '',
    seo_description: '',
    seo_keywords: '',
  });

  useEffect(() => {
    fetchCategories();
    fetchTags();
    fetchPaymentMethods();
    fetchPost();
  }, [postId]);

  const fetchCategories = async () => {
    try {
      const response = await fetch('/api/categories');
      const data = await response.json();
      setCategories(data.categories || []);
    } catch (error) {
      console.error('Failed to fetch categories:', error);
    }
  };

  const fetchTags = async () => {
    try {
      const response = await fetch('/api/tags');
      const data = await response.json();
      setTags(data.tags || []);
    } catch (error) {
      console.error('Failed to fetch tags:', error);
    }
  };

  const fetchPaymentMethods = async () => {
    try {
      const response = await fetch('/api/payment-configs');
      const data = await response.json();
      const enabled = (data.configs || []).filter((c: PaymentMethod) => c.is_enabled);
      setPaymentMethods(enabled);
    } catch (error) {
      console.error('Failed to fetch payment methods:', error);
    }
  };

  const fetchPost = async () => {
    try {
      const response = await fetch(`/api/posts/${postId}`);
      const data = await response.json();
      
      if (!response.ok) {
        setError(data.error || '加载文章失败');
        return;
      }
      
      setFormData({
        title: data.post.title || '',
        slug: data.post.slug || '',
        content: data.post.content || '',
        excerpt: data.post.excerpt || '',
        category_id: data.post.category_id || '',
        status: data.post.status || 'draft',
        featured_image: data.post.featured_image || '',
        is_paid: data.post.is_paid || false,
        price: data.post.price || '',
        payment_methods: data.post.payment_methods || [],
        free_content: data.post.free_content || '',
        tag_ids: (data.post.tags || []).map((t: Tag) => t.id),
        seo_title: data.post.seo_title || '',
        seo_description: data.post.seo_description || '',
        seo_keywords: data.post.seo_keywords || '',
      });
    } catch (error) {
      console.error('Failed to fetch post:', error);
      setError('加载文章失败');
    } finally {
      setLoading(false);
    }
  };

  const handleImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setUploading(true);
    setError('');

    try {
      const formDataToSend = new FormData();
      formDataToSend.append('file', file);

      const response = await fetch('/api/upload', {
        method: 'POST',
        body: formDataToSend,
      });

      const data = await response.json();

      if (!response.ok) {
        setError(data.error || '上传失败');
        return;
      }

      setFormData((prev) => ({ ...prev, featured_image: data.data.url }));
    } catch (error) {
      console.error('Upload error:', error);
      setError('上传失败，请稍后重试');
    } finally {
      setUploading(false);
    }
  };

  const handlePaymentMethodToggle = (method: string) => {
    setFormData((prev) => {
      const methods = prev.payment_methods.includes(method)
        ? prev.payment_methods.filter((m) => m !== method)
        : [...prev.payment_methods, method];
      return { ...prev, payment_methods: methods };
    });
  };

  const handleTagToggle = (tagId: string) => {
    setFormData((prev) => {
      const tagIds = prev.tag_ids.includes(tagId)
        ? prev.tag_ids.filter((id) => id !== tagId)
        : [...prev.tag_ids, tagId];
      return { ...prev, tag_ids: tagIds };
    });
  };

  // 处理特色图片选择
  const handleFeatureImageSelect = (file: { url: string; original_name: string }) => {
    setFormData((prev) => ({ ...prev, featured_image: file.url }));
  };

  // 处理内容中插入图片
  const handleContentImageSelect = (file: { url: string; original_name: string }) => {
    const imageMarkdown = `\n![${file.original_name}](${file.url})\n`;
    setFormData((prev) => ({ 
      ...prev, 
      content: prev.content + imageMarkdown 
    }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setSaving(true);

    try {
      const response = await fetch(`/api/posts/${postId}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ...formData,
          price: formData.is_paid ? parseFloat(formData.price) || 0 : 0,
        }),
      });

      const data = await response.json();

      if (!response.ok) {
        setError(data.error || '更新失败');
        return;
      }

      router.push('/admin/posts');
    } catch (error) {
      console.error('Failed to update post:', error);
      setError('网络错误，请稍后重试');
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center h-64">
        <div className="text-gray-500">加载中...</div>
      </div>
    );
  }

  return (
    <div className="p-6">
      <div className="max-w-5xl mx-auto">
        <div className="mb-6">
          <Link href="/admin/posts" className="inline-flex items-center text-sm text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-300 mb-2">
            <ArrowLeft className="h-4 w-4 mr-1" />
            返回文章列表
          </Link>
          <h1 className="text-2xl font-bold text-gray-900 dark:text-white">编辑文章</h1>
          <p className="text-gray-500 dark:text-gray-400 mt-1">修改文章内容和设置</p>
        </div>

        <form onSubmit={handleSubmit}>
          {error && (
            <Alert variant="destructive" className="mb-6">
              <AlertDescription>{error}</AlertDescription>
            </Alert>
          )}

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* 主内容区 */}
            <div className="lg:col-span-2 space-y-6">
              <Card>
                <CardContent className="p-6 space-y-5">
                  <div className="space-y-2">
                    <Label htmlFor="title">标题</Label>
                    <Input
                      id="title"
                      value={formData.title}
                      onChange={(e) =>
                        setFormData({ ...formData, title: e.target.value })
                      }
                      placeholder="请输入文章标题"
                      required
                    />
                  </div>

                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <Label htmlFor="slug">别名 (URL)</Label>
                      <Button
                        type="button"
                        variant="ghost"
                        size="sm"
                        onClick={() => setFormData({ ...formData, slug: generatePinyinSlug(formData.title) })}
                        className="text-[#0ea5e9]"
                      >
                        <RefreshCw className="w-4 h-4 mr-1" />
                        重新生成
                      </Button>
                    </div>
                    <Input
                      id="slug"
                      value={formData.slug}
                      onChange={(e) =>
                        setFormData({ ...formData, slug: e.target.value })
                      }
                      placeholder="article-url-slug"
                      required
                    />
                    <p className="text-xs text-gray-500">基于标题拼音首字母自动生成，点击"重新生成"可更新</p>
                  </div>

                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <Label htmlFor="content">内容</Label>
                      <Button
                        type="button"
                        variant="ghost"
                        size="sm"
                        onClick={() => setContentMediaPickerOpen(true)}
                        className="text-[#0ea5e9]"
                      >
                        <ImageIcon className="w-4 h-4 mr-1" />
                        插入图片
                      </Button>
                    </div>
                    <Textarea
                      id="content"
                      value={formData.content}
                      onChange={(e) =>
                        setFormData({ ...formData, content: e.target.value })
                      }
                      placeholder="请输入文章内容（支持 Markdown）"
                      rows={16}
                      required
                      className="font-mono"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="excerpt">摘要</Label>
                    <Textarea
                      id="excerpt"
                      value={formData.excerpt}
                      onChange={(e) =>
                        setFormData({ ...formData, excerpt: e.target.value })
                      }
                      placeholder="文章摘要（可选，不填则自动截取）"
                      rows={3}
                    />
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* 侧边栏设置 */}
            <div className="space-y-6">
              {/* 发布设置 */}
              <Card>
                <CardHeader className="bg-gray-50 dark:bg-gray-800/50 border-b dark:border-gray-700 py-4">
                  <CardTitle className="text-base">发布设置</CardTitle>
                </CardHeader>
                <CardContent className="p-4 space-y-4">
                  <div className="space-y-2">
                    <Label>状态</Label>
                    <Select
                      value={formData.status}
                      onValueChange={(value) =>
                        setFormData({ ...formData, status: value })
                      }
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="draft">草稿</SelectItem>
                        <SelectItem value="published">发布</SelectItem>
                        <SelectItem value="private">私密</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label>分类</Label>
                    <Select
                      value={formData.category_id || 'none'}
                      onValueChange={(value) =>
                        setFormData({ ...formData, category_id: value === 'none' ? '' : value })
                      }
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="选择分类" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="none">无分类</SelectItem>
                        {categories.map((cat) => (
                          <SelectItem key={cat.id} value={cat.id}>
                            {cat.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  {/* 标签选择 */}
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <Label>标签</Label>
                      <Link
                        href="/admin/tags"
                        className="text-xs text-[#0ea5e9] hover:underline flex items-center gap-1"
                      >
                        <Plus className="w-3 h-3" />
                        管理标签
                      </Link>
                    </div>
                    <div className="flex flex-wrap gap-2 p-3 border dark:border-gray-700 rounded-lg max-h-40 overflow-y-auto">
                      {tags.length === 0 ? (
                        <p className="text-sm text-gray-500">暂无标签，请先创建标签</p>
                      ) : (
                        tags.map((tag) => (
                          <button
                            key={tag.id}
                            type="button"
                            onClick={() => handleTagToggle(tag.id)}
                            className={`inline-flex items-center gap-1 px-2 py-1 rounded-full text-xs font-medium transition-colors ${
                              formData.tag_ids.includes(tag.id)
                                ? 'bg-[#0ea5e9] text-white'
                                : 'bg-gray-100 dark:bg-gray-700 text-gray-600 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-600'
                            }`}
                          >
                            <Hash className="w-3 h-3" />
                            {tag.name}
                          </button>
                        ))
                      )}
                    </div>
                    {formData.tag_ids.length > 0 && (
                      <p className="text-xs text-gray-500">已选择 {formData.tag_ids.length} 个标签</p>
                    )}
                  </div>
                </CardContent>
              </Card>

              {/* 特色图片 */}
              <Card>
                <CardHeader className="bg-gray-50 dark:bg-gray-800/50 border-b dark:border-gray-700 py-4">
                  <CardTitle className="text-base">特色图片</CardTitle>
                </CardHeader>
                <CardContent className="p-4 space-y-4">
                  {formData.featured_image ? (
                    <div className="relative group">
                      <img
                        src={formData.featured_image}
                        alt="特色图片"
                        className="w-full aspect-video object-cover rounded-lg"
                      />
                      <button
                        type="button"
                        onClick={() => setFormData({ ...formData, featured_image: '' })}
                        className="absolute top-2 right-2 p-1.5 bg-red-500 text-white rounded-lg opacity-0 group-hover:opacity-100 transition-opacity"
                      >
                        <X className="h-4 w-4" />
                      </button>
                    </div>
                  ) : (
                    <div className="space-y-3">
                      <div
                        onClick={() => fileInputRef.current?.click()}
                        className="border-2 border-dashed border-gray-200 dark:border-gray-700 rounded-lg p-6 text-center cursor-pointer hover:border-[#0ea5e9] transition-colors"
                      >
                        {uploading ? (
                          <Loader2 className="h-8 w-8 mx-auto text-gray-400 animate-spin" />
                        ) : (
                          <Upload className="h-8 w-8 mx-auto text-gray-400" />
                        )}
                        <p className="mt-2 text-sm text-gray-500">点击上传图片</p>
                        <p className="text-xs text-gray-400 mt-1">支持 JPG、PNG、GIF，最大 5MB</p>
                      </div>
                      <div className="flex items-center gap-2">
                        <div className="flex-1 h-px bg-gray-200 dark:bg-gray-700" />
                        <span className="text-xs text-gray-400">或</span>
                        <div className="flex-1 h-px bg-gray-200 dark:bg-gray-700" />
                      </div>
                      <Button
                        type="button"
                        variant="outline"
                        className="w-full"
                        onClick={() => setMediaPickerOpen(true)}
                      >
                        <ImageIcon className="w-4 h-4 mr-2" />
                        从媒体库选择
                      </Button>
                    </div>
                  )}
                  <input
                    ref={fileInputRef}
                    type="file"
                    accept="image/jpeg,image/png,image/gif,image/webp"
                    onChange={handleImageUpload}
                    className="hidden"
                  />
                  <div className="space-y-1">
                    <Label htmlFor="featured_image_url" className="text-xs text-gray-500">或输入图片URL</Label>
                    <Input
                      id="featured_image_url"
                      value={formData.featured_image}
                      onChange={(e) =>
                        setFormData({ ...formData, featured_image: e.target.value })
                      }
                      placeholder="https://example.com/image.jpg"
                    />
                  </div>
                </CardContent>
              </Card>

              {/* 付费设置 */}
              <Card>
                <CardHeader className="bg-gray-50 dark:bg-gray-800/50 border-b dark:border-gray-700 py-4">
                  <CardTitle className="text-base">付费阅读</CardTitle>
                </CardHeader>
                <CardContent className="p-4 space-y-4">
                  <div className="flex items-center justify-between">
                    <Label htmlFor="is_paid">开启付费阅读</Label>
                    <input
                      id="is_paid"
                      type="checkbox"
                      checked={formData.is_paid}
                      onChange={(e) =>
                        setFormData({ ...formData, is_paid: e.target.checked })
                      }
                      className="w-4 h-4 rounded border-gray-300"
                    />
                  </div>

                  {formData.is_paid && (
                    <>
                      <div className="space-y-2">
                        <Label htmlFor="price">价格 (元)</Label>
                        <Input
                          id="price"
                          type="number"
                          min="0"
                          step="0.01"
                          value={formData.price}
                          onChange={(e) =>
                            setFormData({ ...formData, price: e.target.value })
                          }
                          placeholder="9.99"
                        />
                      </div>

                      <div className="space-y-2">
                        <Label>支付方式</Label>
                        {paymentMethods.length === 0 ? (
                          <p className="text-sm text-gray-500">
                            暂无可用支付方式，请先在
                            <Link href="/admin/payment" className="text-[#0ea5e9]">支付配置</Link>
                            中启用
                          </p>
                        ) : (
                          <div className="space-y-2">
                            {paymentMethods.map((method) => (
                              <label
                                key={method.id}
                                className="flex items-center gap-2 p-2 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-800 cursor-pointer"
                              >
                                <input
                                  type="checkbox"
                                  checked={formData.payment_methods.includes(method.payment_method)}
                                  onChange={() => handlePaymentMethodToggle(method.payment_method)}
                                  className="w-4 h-4 rounded border-gray-300"
                                />
                                <span className="text-sm">{method.display_name}</span>
                              </label>
                            ))}
                          </div>
                        )}
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="free_content">免费预览内容</Label>
                        <Textarea
                          id="free_content"
                          value={formData.free_content}
                          onChange={(e) =>
                            setFormData({ ...formData, free_content: e.target.value })
                          }
                          placeholder="用户可免费预览的内容..."
                          rows={4}
                        />
                        <p className="text-xs text-gray-500">设置部分内容供用户免费预览</p>
                      </div>
                    </>
                  )}
                </CardContent>
              </Card>

              {/* SEO设置 */}
              <Card>
                <CardHeader className="bg-gray-50 dark:bg-gray-800/50 border-b dark:border-gray-700 py-4">
                  <CardTitle className="text-base">SEO设置</CardTitle>
                </CardHeader>
                <CardContent className="p-4 space-y-4">
                  {/* AI SEO优化器 */}
                  <AISEOOptimizer
                    title={formData.title}
                    content={formData.content}
                    excerpt={formData.excerpt}
                    category={categories.find(c => c.id === formData.category_id)?.name}
                    tags={tags.filter(t => formData.tag_ids.includes(t.id)).map(t => t.name)}
                    seoTitle={formData.seo_title}
                    seoDescription={formData.seo_description}
                    seoKeywords={formData.seo_keywords}
                    onApply={(data) => setFormData(prev => ({
                      ...prev,
                      seo_title: data.seo_title,
                      seo_description: data.seo_description,
                      seo_keywords: data.seo_keywords,
                    }))}
                  />

                  <div className="border-t dark:border-gray-700 pt-4">
                    <div className="space-y-2">
                      <Label htmlFor="seo_title">SEO标题</Label>
                      <Input
                        id="seo_title"
                        value={formData.seo_title}
                        onChange={(e) =>
                          setFormData({ ...formData, seo_title: e.target.value })
                        }
                        placeholder="留空则使用文章标题"
                        maxLength={100}
                      />
                      <p className="text-xs text-gray-500">{formData.seo_title.length}/100 字符</p>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="seo_description">SEO描述</Label>
                    <Textarea
                      id="seo_description"
                      value={formData.seo_description}
                      onChange={(e) =>
                        setFormData({ ...formData, seo_description: e.target.value })
                      }
                      placeholder="留空则使用文章摘要"
                      rows={3}
                      maxLength={160}
                    />
                    <p className="text-xs text-gray-500">{formData.seo_description.length}/160 字符（建议 120-160 字）</p>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="seo_keywords">SEO关键词</Label>
                    <Input
                      id="seo_keywords"
                      value={formData.seo_keywords}
                      onChange={(e) =>
                        setFormData({ ...formData, seo_keywords: e.target.value })
                      }
                      placeholder="关键词1, 关键词2, 关键词3"
                      maxLength={255}
                    />
                    <p className="text-xs text-gray-500">多个关键词用逗号分隔</p>
                  </div>
                </CardContent>
              </Card>

              <div className="flex flex-col gap-2">
                <Button type="submit" className="w-full" disabled={saving}>
                  {saving ? '保存中...' : '保存更改'}
                </Button>
                <Button
                  type="button"
                  variant="outline"
                  className="w-full"
                  onClick={() => router.back()}
                >
                  取消
                </Button>
              </div>
            </div>
          </div>
        </form>

        {/* 媒体库选择器 - 特色图片 */}
        <MediaPicker
          open={mediaPickerOpen}
          onClose={() => setMediaPickerOpen(false)}
          onSelect={handleFeatureImageSelect}
          acceptTypes={['image']}
        />

        {/* 媒体库选择器 - 内容插入 */}
        <MediaPicker
          open={contentMediaPickerOpen}
          onClose={() => setContentMediaPickerOpen(false)}
          onSelect={handleContentImageSelect}
          acceptTypes={['image']}
        />
      </div>
    </div>
  );
}
