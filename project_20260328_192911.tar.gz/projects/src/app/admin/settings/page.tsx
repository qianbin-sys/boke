'use client';

import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Save, CheckCircle2 } from 'lucide-react';

export default function SettingsPage() {
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState(false);
  
  const [formData, setFormData] = useState({
    site_name: '',
    site_description: '',
    site_url: '',
    posts_per_page: '10',
  });

  useEffect(() => {
    fetchSettings();
  }, []);

  const fetchSettings = async () => {
    try {
      const response = await fetch('/api/settings');
      const data = await response.json();
      
      if (data.settings) {
        setFormData({
          site_name: data.settings.site_name || '',
          site_description: data.settings.site_description || '',
          site_url: data.settings.site_url || '',
          posts_per_page: data.settings.posts_per_page || '10',
        });
      }
    } catch (error) {
      console.error('Failed to fetch settings:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setSuccess(false);
    setSaving(true);

    try {
      const response = await fetch('/api/settings', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(formData),
      });

      const data = await response.json();

      if (!response.ok) {
        setError(data.error || '保存失败');
        return;
      }

      setSuccess(true);
      setTimeout(() => setSuccess(false), 3000);
    } catch (error) {
      console.error('Failed to save settings:', error);
      setError('网络错误，请稍后重试');
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center h-64">
        <div className="text-gray-500">加载中...</div>
      </div>
    );
  }

  return (
    <div className="p-6">
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-gray-900 dark:text-white">网站设置</h1>
        <p className="text-gray-500 dark:text-gray-400 mt-1">配置网站基本信息</p>
      </div>

      <form onSubmit={handleSubmit}>
        {error && (
          <Alert variant="destructive" className="mb-6">
            <AlertDescription>{error}</AlertDescription>
          </Alert>
        )}
        
        {success && (
          <Alert className="mb-6 bg-green-50 dark:bg-green-900/20 border-green-200 dark:border-green-800">
            <CheckCircle2 className="h-4 w-4 text-green-600 dark:text-green-400" />
            <AlertDescription className="text-green-700 dark:text-green-300 ml-2">
              设置已保存
            </AlertDescription>
          </Alert>
        )}

        <Card>
          <CardHeader className="bg-gray-50 dark:bg-gray-800/50 border-b dark:border-gray-700">
            <CardTitle className="text-lg">基本设置</CardTitle>
          </CardHeader>
          <CardContent className="p-6 space-y-5">
            <div className="space-y-2">
              <Label htmlFor="site_name">网站名称</Label>
              <Input
                id="site_name"
                value={formData.site_name}
                onChange={(e) => setFormData({ ...formData, site_name: e.target.value })}
                placeholder="我的博客"
              />
              <p className="text-xs text-gray-500">显示在浏览器标签页和网站标题处</p>
            </div>

            <div className="space-y-2">
              <Label htmlFor="site_description">网站描述</Label>
              <Input
                id="site_description"
                value={formData.site_description}
                onChange={(e) => setFormData({ ...formData, site_description: e.target.value })}
                placeholder="一个基于 Next.js 的博客系统"
              />
              <p className="text-xs text-gray-500">简短的网站描述，用于 SEO</p>
            </div>

            <div className="space-y-2">
              <Label htmlFor="site_url">网站地址</Label>
              <Input
                id="site_url"
                value={formData.site_url}
                onChange={(e) => setFormData({ ...formData, site_url: e.target.value })}
                placeholder="https://example.com"
              />
              <p className="text-xs text-gray-500">网站的完整 URL，用于生成链接和回调地址</p>
            </div>

            <div className="space-y-2">
              <Label htmlFor="posts_per_page">每页文章数</Label>
              <Input
                id="posts_per_page"
                type="number"
                value={formData.posts_per_page}
                onChange={(e) => setFormData({ ...formData, posts_per_page: e.target.value })}
                min="1"
                max="100"
              />
              <p className="text-xs text-gray-500">首页和分类页每页显示的文章数量</p>
            </div>
          </CardContent>
        </Card>

        <div className="mt-6">
          <Button type="submit" disabled={saving}>
            <Save className="mr-2 h-4 w-4" />
            {saving ? '保存中...' : '保存设置'}
          </Button>
        </div>
      </form>
    </div>
  );
}
