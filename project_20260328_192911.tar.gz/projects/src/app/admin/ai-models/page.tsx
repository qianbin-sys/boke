'use client';

import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Textarea } from '@/components/ui/textarea';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  Plus, 
  Pencil, 
  Trash2, 
  Star, 
  TestTube, 
  Check, 
  X, 
  Loader2,
  Sparkles,
  Image as ImageIcon,
  AlertCircle
} from 'lucide-react';
import { toast } from 'sonner';

interface Model {
  id: string;
  name: string;
  provider: string;
  model_type: 'llm' | 'image';
  model_id: string;
  api_endpoint: string | null;
  api_key_encrypted: string | null;
  config: Record<string, unknown>;
  is_enabled: boolean;
  is_default: boolean;
  priority: number;
  created_at: string;
  updated_at: string;
}

interface ModelProvider {
  name: string;
  models: {
    llm: Array<{ id: string; name: string }>;
    image: Array<{ id: string; name: string }>;
  };
  defaultEndpoint: string;
}

interface ModelFormData {
  name: string;
  provider: string;
  model_type: 'llm' | 'image';
  model_id: string;
  api_endpoint: string;
  api_key: string;
  config: string;
  is_enabled: boolean;
  is_default: boolean;
  priority: number;
}

const initialFormData: ModelFormData = {
  name: '',
  provider: 'doubao',
  model_type: 'llm',
  model_id: '',
  api_endpoint: '',
  api_key: '',
  config: '{}',
  is_enabled: true,
  is_default: false,
  priority: 0,
};

export default function AIModelsPage() {
  const [models, setModels] = useState<Model[]>([]);
  const [providers, setProviders] = useState<Record<string, ModelProvider>>({});
  const [loading, setLoading] = useState(true);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [editingModel, setEditingModel] = useState<Model | null>(null);
  const [deletingModel, setDeletingModel] = useState<Model | null>(null);
  const [formData, setFormData] = useState<ModelFormData>(initialFormData);
  const [testingModel, setTestingModel] = useState<string | null>(null);
  const [testResult, setTestResult] = useState<{ success: boolean; message: string; response?: string } | null>(null);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    fetchModels();
  }, []);

  const fetchModels = async () => {
    setLoading(true);
    try {
      const res = await fetch('/api/ai-models');
      const data = await res.json();
      
      if (data.models) {
        setModels(data.models);
      }
      if (data.providers) {
        setProviders(data.providers);
      }
    } catch (error) {
      console.error('Fetch models error:', error);
      toast.error('获取模型列表失败');
    } finally {
      setLoading(false);
    }
  };

  const handleOpenDialog = (model?: Model) => {
    if (model) {
      setEditingModel(model);
      setFormData({
        name: model.name,
        provider: model.provider,
        model_type: model.model_type,
        model_id: model.model_id,
        api_endpoint: model.api_endpoint || '',
        api_key: '', // 不回显密钥
        config: JSON.stringify(model.config || {}, null, 2),
        is_enabled: model.is_enabled,
        is_default: model.is_default,
        priority: model.priority,
      });
    } else {
      setEditingModel(null);
      setFormData(initialFormData);
    }
    setTestResult(null);
    setDialogOpen(true);
  };

  const handleCloseDialog = () => {
    setDialogOpen(false);
    setEditingModel(null);
    setFormData(initialFormData);
    setTestResult(null);
  };

  const handleSave = async () => {
    // 验证必填字段
    if (!formData.name.trim()) {
      toast.error('请输入模型名称');
      return;
    }
    if (!formData.model_id.trim()) {
      toast.error('请选择或输入模型ID');
      return;
    }

    // 验证JSON配置
    if (formData.config.trim()) {
      try {
        JSON.parse(formData.config);
      } catch {
        toast.error('扩展配置JSON格式错误');
        return;
      }
    }

    setSaving(true);
    try {
      const body: Record<string, unknown> = {
        name: formData.name,
        provider: formData.provider,
        model_type: formData.model_type,
        model_id: formData.model_id,
        api_endpoint: formData.api_endpoint || null,
        api_key: formData.api_key || null,
        config: formData.config.trim() ? JSON.parse(formData.config) : {},
        is_enabled: formData.is_enabled,
        is_default: formData.is_default,
        priority: formData.priority,
      };

      if (editingModel) {
        body.id = editingModel.id;
      }

      const res = await fetch('/api/ai-models', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body),
      });

      const data = await res.json();
      
      if (data.model) {
        toast.success(editingModel ? '模型已更新' : '模型已创建');
        handleCloseDialog();
        fetchModels();
      } else {
        toast.error(data.error || '保存失败');
      }
    } catch (error) {
      console.error('Save model error:', error);
      toast.error('保存失败');
    } finally {
      setSaving(false);
    }
  };

  const handleSetDefault = async (model: Model) => {
    try {
      const res = await fetch(`/api/ai-models/${model.id}/action`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'set_default' }),
      });

      const data = await res.json();
      
      if (data.success) {
        toast.success('已设为默认模型');
        fetchModels();
      } else {
        toast.error(data.error || '设置失败');
      }
    } catch (error) {
      console.error('Set default error:', error);
      toast.error('设置失败');
    }
  };

  const handleTest = async () => {
    if (!editingModel) {
      toast.error('请先保存模型后再测试');
      return;
    }

    setTestingModel(editingModel.id);
    setTestResult(null);
    try {
      const res = await fetch(`/api/ai-models/${editingModel.id}/action`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'test' }),
      });

      const data = await res.json();
      setTestResult({
        success: data.success,
        message: data.message || data.error || '测试完成',
        response: data.response || data.imageUrl,
      });
    } catch (error) {
      console.error('Test model error:', error);
      setTestResult({
        success: false,
        message: '测试失败',
      });
    } finally {
      setTestingModel(null);
    }
  };

  const handleDelete = async () => {
    if (!deletingModel) return;

    try {
      const res = await fetch('/api/ai-models', {
        method: 'DELETE',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ids: [deletingModel.id] }),
      });

      const data = await res.json();
      
      if (data.success) {
        toast.success('模型已删除');
        setDeleteDialogOpen(false);
        setDeletingModel(null);
        fetchModels();
      } else {
        toast.error(data.error || '删除失败');
      }
    } catch (error) {
      console.error('Delete model error:', error);
      toast.error('删除失败');
    }
  };

  const getProviderName = (providerKey: string) => {
    return providers[providerKey]?.name || providerKey;
  };

  const llmModels = models.filter(m => m.model_type === 'llm');
  const imageModels = models.filter(m => m.model_type === 'image');

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold">AI 模型配置</h1>
          <p className="text-gray-500 mt-1">管理大语言模型和图片生成模型的配置</p>
        </div>
        <Button onClick={() => handleOpenDialog()}>
          <Plus className="w-4 h-4 mr-2" />
          添加模型
        </Button>
      </div>

      {loading ? (
        <div className="flex justify-center py-12">
          <Loader2 className="w-8 h-8 animate-spin text-gray-400" />
        </div>
      ) : (
        <Tabs defaultValue="llm" className="space-y-4">
          <TabsList>
            <TabsTrigger value="llm" className="flex items-center gap-2">
              <Sparkles className="w-4 h-4" />
              大语言模型 ({llmModels.length})
            </TabsTrigger>
            <TabsTrigger value="image" className="flex items-center gap-2">
              <ImageIcon className="w-4 h-4" />
              图片生成模型 ({imageModels.length})
            </TabsTrigger>
          </TabsList>

          <TabsContent value="llm">
            {llmModels.length === 0 ? (
              <Card>
                <CardContent className="flex flex-col items-center justify-center py-12 text-gray-500">
                  <Sparkles className="w-12 h-12 mb-4 opacity-50" />
                  <p>暂无大语言模型配置</p>
                  <p className="text-sm mt-1">点击"添加模型"开始配置</p>
                </CardContent>
              </Card>
            ) : (
              <div className="grid gap-4">
                {llmModels.map((model) => (
                  <Card key={model.id} className={!model.is_enabled ? 'opacity-60' : ''}>
                    <CardHeader className="pb-3">
                      <div className="flex items-start justify-between">
                        <div>
                          <CardTitle className="flex items-center gap-2">
                            {model.name}
                            {model.is_default && (
                              <Badge variant="default" className="bg-blue-500">
                                <Star className="w-3 h-3 mr-1" />
                                默认
                              </Badge>
                            )}
                            {!model.is_enabled && (
                              <Badge variant="secondary">已禁用</Badge>
                            )}
                          </CardTitle>
                          <CardDescription className="mt-1">
                            {getProviderName(model.provider)} · {model.model_id}
                          </CardDescription>
                        </div>
                        <div className="flex items-center gap-2">
                          {!model.is_default && model.is_enabled && (
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => handleSetDefault(model)}
                            >
                              <Star className="w-4 h-4 mr-1" />
                              设为默认
                            </Button>
                          )}
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => handleOpenDialog(model)}
                          >
                            <Pencil className="w-4 h-4" />
                          </Button>
                          <Button
                            variant="outline"
                            size="sm"
                            className="text-red-600 hover:text-red-700"
                            onClick={() => {
                              setDeletingModel(model);
                              setDeleteDialogOpen(true);
                            }}
                          >
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        </div>
                      </div>
                    </CardHeader>
                    {model.api_endpoint && (
                      <CardContent className="pt-0">
                        <p className="text-sm text-gray-500">
                          API端点: {model.api_endpoint}
                        </p>
                      </CardContent>
                    )}
                  </Card>
                ))}
              </div>
            )}
          </TabsContent>

          <TabsContent value="image">
            {imageModels.length === 0 ? (
              <Card>
                <CardContent className="flex flex-col items-center justify-center py-12 text-gray-500">
                  <ImageIcon className="w-12 h-12 mb-4 opacity-50" />
                  <p>暂无图片生成模型配置</p>
                  <p className="text-sm mt-1">点击"添加模型"开始配置</p>
                </CardContent>
              </Card>
            ) : (
              <div className="grid gap-4">
                {imageModels.map((model) => (
                  <Card key={model.id} className={!model.is_enabled ? 'opacity-60' : ''}>
                    <CardHeader className="pb-3">
                      <div className="flex items-start justify-between">
                        <div>
                          <CardTitle className="flex items-center gap-2">
                            {model.name}
                            {model.is_default && (
                              <Badge variant="default" className="bg-blue-500">
                                <Star className="w-3 h-3 mr-1" />
                                默认
                              </Badge>
                            )}
                            {!model.is_enabled && (
                              <Badge variant="secondary">已禁用</Badge>
                            )}
                          </CardTitle>
                          <CardDescription className="mt-1">
                            {getProviderName(model.provider)} · {model.model_id}
                          </CardDescription>
                        </div>
                        <div className="flex items-center gap-2">
                          {!model.is_default && model.is_enabled && (
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => handleSetDefault(model)}
                            >
                              <Star className="w-4 h-4 mr-1" />
                              设为默认
                            </Button>
                          )}
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => handleOpenDialog(model)}
                          >
                            <Pencil className="w-4 h-4" />
                          </Button>
                          <Button
                            variant="outline"
                            size="sm"
                            className="text-red-600 hover:text-red-700"
                            onClick={() => {
                              setDeletingModel(model);
                              setDeleteDialogOpen(true);
                            }}
                          >
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        </div>
                      </div>
                    </CardHeader>
                  </Card>
                ))}
              </div>
            )}
          </TabsContent>
        </Tabs>
      )}

      {/* 添加/编辑模型对话框 */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>{editingModel ? '编辑模型' : '添加模型'}</DialogTitle>
            <DialogDescription>
              配置AI模型的参数。豆包模型使用SDK默认配置，无需填写密钥。
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-4 py-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="name">模型名称 *</Label>
                <Input
                  id="name"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  placeholder="如：豆包Pro-32K"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="model_type">模型类型 *</Label>
                <Select
                  value={formData.model_type}
                  onValueChange={(value: 'llm' | 'image') => 
                    setFormData({ ...formData, model_type: value, model_id: '' })
                  }
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="llm">大语言模型</SelectItem>
                    <SelectItem value="image">图片生成模型</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="provider">提供商 *</Label>
                <Select
                  value={formData.provider}
                  onValueChange={(value) => 
                    setFormData({ ...formData, provider: value, model_id: '' })
                  }
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {Object.entries(providers).map(([key, provider]) => (
                      <SelectItem key={key} value={key}>
                        {provider.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="model_id">模型ID *</Label>
                {providers[formData.provider]?.models[formData.model_type]?.length ? (
                  <Select
                    value={formData.model_id}
                    onValueChange={(value) => setFormData({ ...formData, model_id: value })}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="选择模型" />
                    </SelectTrigger>
                    <SelectContent>
                      {providers[formData.provider].models[formData.model_type].map((model) => (
                        <SelectItem key={model.id} value={model.id}>
                          {model.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                ) : (
                  <Input
                    id="model_id"
                    value={formData.model_id}
                    onChange={(e) => setFormData({ ...formData, model_id: e.target.value })}
                    placeholder="输入模型ID"
                  />
                )}
              </div>
            </div>

            {formData.provider !== 'doubao' && (
              <>
                <div className="space-y-2">
                  <Label htmlFor="api_endpoint">API端点</Label>
                  <Input
                    id="api_endpoint"
                    value={formData.api_endpoint}
                    onChange={(e) => setFormData({ ...formData, api_endpoint: e.target.value })}
                    placeholder={providers[formData.provider]?.defaultEndpoint || 'https://api.example.com/v1'}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="api_key">API密钥</Label>
                  <Input
                    id="api_key"
                    type="password"
                    value={formData.api_key}
                    onChange={(e) => setFormData({ ...formData, api_key: e.target.value })}
                    placeholder="输入API密钥"
                  />
                </div>
              </>
            )}

            <div className="space-y-2">
              <Label htmlFor="config">扩展配置 (JSON)</Label>
              <Textarea
                id="config"
                value={formData.config}
                onChange={(e) => setFormData({ ...formData, config: e.target.value })}
                placeholder='{"temperature": 0.7}'
                rows={3}
                className="font-mono text-sm"
              />
            </div>

            <div className="grid grid-cols-3 gap-4">
              <div className="flex items-center space-x-2">
                <Switch
                  id="is_enabled"
                  checked={formData.is_enabled}
                  onCheckedChange={(checked) => setFormData({ ...formData, is_enabled: checked })}
                />
                <Label htmlFor="is_enabled">启用</Label>
              </div>

              <div className="flex items-center space-x-2">
                <Switch
                  id="is_default"
                  checked={formData.is_default}
                  onCheckedChange={(checked) => setFormData({ ...formData, is_default: checked })}
                />
                <Label htmlFor="is_default">默认</Label>
              </div>

              <div className="space-y-2">
                <Label htmlFor="priority">优先级</Label>
                <Input
                  id="priority"
                  type="number"
                  value={formData.priority}
                  onChange={(e) => setFormData({ ...formData, priority: parseInt(e.target.value) || 0 })}
                />
              </div>
            </div>

            {/* 测试结果 */}
            {testResult && (
              <div className={`p-4 rounded-lg ${testResult.success ? 'bg-green-50' : 'bg-red-50'}`}>
                <div className="flex items-start gap-2">
                  {testResult.success ? (
                    <Check className="w-5 h-5 text-green-600 mt-0.5" />
                  ) : (
                    <AlertCircle className="w-5 h-5 text-red-600 mt-0.5" />
                  )}
                  <div>
                    <p className={testResult.success ? 'text-green-800' : 'text-red-800'}>
                      {testResult.message}
                    </p>
                    {testResult.response && (
                      <p className="text-sm text-gray-600 mt-1 line-clamp-3">
                        响应: {testResult.response}
                      </p>
                    )}
                  </div>
                </div>
              </div>
            )}
          </div>

          <DialogFooter>
            {editingModel && (
              <Button
                variant="outline"
                onClick={handleTest}
                disabled={testingModel !== null}
              >
                {testingModel ? (
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                ) : (
                  <TestTube className="w-4 h-4 mr-2" />
                )}
                测试
              </Button>
            )}
            <Button variant="outline" onClick={handleCloseDialog}>
              取消
            </Button>
            <Button onClick={handleSave} disabled={saving}>
              {saving && <Loader2 className="w-4 h-4 mr-2 animate-spin" />}
              保存
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* 删除确认对话框 */}
      <AlertDialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>确认删除</AlertDialogTitle>
            <AlertDialogDescription>
              确定要删除模型 "{deletingModel?.name}" 吗？此操作不可撤销。
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>取消</AlertDialogCancel>
            <AlertDialogAction
              className="bg-red-600 hover:bg-red-700"
              onClick={handleDelete}
            >
              删除
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
