'use client';

import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Switch } from '@/components/ui/switch';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Save, CreditCard, CheckCircle2 } from 'lucide-react';

interface PaymentConfig {
  id: string;
  payment_method: string;
  display_name: string;
  is_enabled: boolean;
  config: Record<string, string>;
  description: string;
}

const configFields: Record<string, { label: string; field: string; type: string; placeholder: string; help?: string }[]> = {
  alipay: [
    { label: '应用ID (AppId)', field: 'app_id', type: 'text', placeholder: '例如：2021004175670437', help: '支付宝开放平台应用ID' },
    { label: '应用私钥', field: 'private_key', type: 'textarea', placeholder: 'MIIEwAIBADANBgkqhkiG9w0BAQEFAASCBKowggSmAgEAAoIBAQCUTqtyqba9M24e6/R/gmGD7Q/SZZo2xVt21PvX5pLsExSsb+V+YPGFhi9iJw2z2jHI2afTU1uZ70V6ClrEKTb5hdNH8jzCw6XnSsd0BSRDk8MtpyGTNwuyh3++QzSbW3pn/8UMCUPxhhUHqJa9nQU/VGKhdEdnoazG1M3rRGiRz6J0dsrZlAxf00arNI8t5sv3KnvbxI64HYkmqvdVjgtBb+/DIhjB2WokSwymLaekPbenL96RSJZBtRdUvpVGz+3n6kY9/oM85KQbPk3uNRBws++mqSNv8Cn1wXTN7CCn9xx00+3ke/B6qlWl2tzEbWUyxiM6IdqNnYYLCmkMIcwrAgMBAAECggEBAJG3Wi0nIy1ywtgO7gP6juWYntsSiRsXfm6bhXb0TZc2iDGFH++0QJn45cWCqav0zsWRVZwFYxM0TQdD9TqXZDR2kMk38QtMQE2o45/TDXZ4UGUiuZJzm0Kmb5T5Y07h6rsUSv8we1lrbG5B7xoOlYFL4DzSivX/nEsf+9MVO8lGwbUWrLP7LB2A+5ltx2KLa87PkTOrFKrggCnTiZwkO5HxylYq5UiTu0SaoI1evOIP+lBD1fIS0nFxHYN8DmB/YUQnwcoRg4iM9dQ8GGnYv3DP9FAQWv0bXdjNbPIXjMNMAJ1eGUT9sBEabrOQ3aEK2sXN6YMtqeUCnrkC/u3PlEECgYEAzwwjGwm96T60ex7VY7jGG1pkRYpgJZRX33oPD0G5GVkvnvoWX50svjMMUL1TMCpo8RNM1ftSWXJlgWslMgG6jd+28vJhoV4pbgWgepdcpl5UXI69AVkHzQUQArczLlLUfwHmvMH2vi4jsT6n7s9xNJxGJRUI7B7EYH5vFonSYQ0CgYEAt18ygb9Uf7YrxGoUjTGP83VCQJwmMsrzk9CZB8ncjCtvLe1QkVdWDQKuw2JBsojze2vJsSE711WUCNaSy/RWypjg1LQUam7vH7BXU6ZKRZXDU7zILmBaNsHlCuolP3Lm3ox4oZ4WbkGroeYCCkmuMDQfsHjoR/Q4pJCTVuUaZBcCgYEAwPHNkTfN25uMsyOztd+N9hWRVeCy4rJQBTkI6a3UoZOkNiFWUjn1ZTXLJz6XVE5hRy82Lj6rqiFaCHXhzq0fvXCaW+KWKrvGHfpuZ2/AbmV/dlWqOqROCbfLCMzSjDuyPL132bVjjC0RI+6ArqJwG5f6Ijps+yVc2ZNZUIaVH80CgYEAiROJ7wH3Ca1FlIN0L4QwRt+OEjxoNaoPYZ0a+H6G9uV1LBDuHGf8NKefuwEVeX/0+3s8/8OHN1aK3fyBKiPSSYr07yxa4qFg8gBhl2+Er/XfWRaTUk/GwI47SOh1xbOAMDcz6iUCQZOn2NPXDJe9td0RH1uS0E8ZlLNa4SdMjisCgYEAn1yOIVw8PbMs642Oeusv9IV02Ub5/wo9w6QYfIedcle39rVhAmzd1b7e2DUHpXVgxR0jKGPHrEjaCwSKYOFQ90rtqcYzrUdfva1IPxgQo8hsLO5jPCzP7gF/ABbwsbCPfHqSymMsMdxduKBpGPuZfbx64eKA0Nf4t3UYRcjmAac=', help: '应用私钥内容，PKCS1格式' },
    { label: '支付宝公钥', field: 'public_key', type: 'textarea', placeholder: 'MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAlE6rcqm2vTNuHuv0f4Jhg+0P0mWaNsVbdtT71+aS7BMUrG/lfmDxhYYvYicNs9oxyNmn01Nbme9FegpaxCk2+YXTR/I8wsOl50rHdAUkQ5PDLachkzcLsod/vkM0m1t6Z//FDAlD8YYVB6iWvZ0FP1RioXRHZ6GsxtTN60Rokc+idHbK2ZQMX9NGqzSPLebL9yp728SOuB2JJqr3VY4LQW/vwyIYwdlqJEsMpi2npD23py/ekUiWQbUXVL6VRs/t5+pGPf6DPOSkGz5N7jUQcLPvpqkjb/Ap9cF0zewgp/ccdNPt5HvweqpVpdrcxG1lMsYjOiHajZ2GCwppDCHMKwIDAQAB', help: '支付宝公钥，用于验签' },
    { label: '回调地址', field: 'notify_url', type: 'text', placeholder: 'https://nidepoter.cn/notify.php', help: '支付成功后的异步通知地址' },
    { label: '应用授权令牌', field: 'app_auth_token', type: 'text', placeholder: '可选，第三方应用授权令牌', help: '可选，如使用第三方代运营模式需填写' },
    { label: '运行模式', field: 'mode', type: 'select', placeholder: 'sandbox/live' },
  ],
  wechat: [
    { label: '应用ID', field: 'app_id', type: 'text', placeholder: '微信应用ID' },
    { label: '商户号', field: 'mch_id', type: 'text', placeholder: '微信商户号' },
    { label: 'API密钥', field: 'api_key', type: 'text', placeholder: 'API密钥' },
    { label: '回调地址', field: 'notify_url', type: 'text', placeholder: 'https://example.com/api/payment/wechat/notify' },
  ],
  paypal: [
    { label: 'Client ID', field: 'client_id', type: 'text', placeholder: 'PayPal Client ID' },
    { label: 'Client Secret', field: 'client_secret', type: 'text', placeholder: 'PayPal Client Secret' },
    { label: '模式', field: 'mode', type: 'select', placeholder: 'sandbox/live' },
  ],
};

export default function PaymentPage() {
  const [configs, setConfigs] = useState<PaymentConfig[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState<string | null>(null);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [successes, setSuccesses] = useState<Record<string, boolean>>({});

  useEffect(() => {
    fetchConfigs();
  }, []);

  const fetchConfigs = async () => {
    try {
      const response = await fetch('/api/payment-configs');
      const data = await response.json();
      setConfigs(data.configs || []);
    } catch (error) {
      console.error('Failed to fetch payment configs:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleToggle = async (id: string, enabled: boolean) => {
    const config = configs.find((c) => c.id === id);
    if (!config) return;
    await saveConfig(id, { ...config, is_enabled: enabled });
  };

  const handleConfigChange = (id: string, field: string, value: string) => {
    setConfigs((prev) =>
      prev.map((c) => {
        if (c.id === id) {
          return {
            ...c,
            config: { ...c.config, [field]: value },
          };
        }
        return c;
      })
    );
  };

  const saveConfig = async (id: string, config: PaymentConfig) => {
    setSaving(id);
    setErrors((prev) => ({ ...prev, [id]: '' }));
    setSuccesses((prev) => ({ ...prev, [id]: false }));

    try {
      const response = await fetch('/api/payment-configs', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          id: config.id,
          is_enabled: config.is_enabled,
          config: config.config,
          description: config.description,
        }),
      });

      const data = await response.json();

      if (!response.ok) {
        setErrors((prev) => ({ ...prev, [id]: data.error || '保存失败' }));
        return;
      }

      setSuccesses((prev) => ({ ...prev, [id]: true }));
      setConfigs((prev) =>
        prev.map((c) => (c.id === id ? config : c))
      );
      
      // 3秒后隐藏成功提示
      setTimeout(() => {
        setSuccesses((prev) => ({ ...prev, [id]: false }));
      }, 3000);
    } catch (error) {
      console.error('Failed to save config:', error);
      setErrors((prev) => ({ ...prev, [id]: '网络错误，请稍后重试' }));
    } finally {
      setSaving(null);
    }
  };

  const handleSave = (config: PaymentConfig) => {
    saveConfig(config.id, config);
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center h-64">
        <div className="text-gray-500">加载中...</div>
      </div>
    );
  }

  return (
    <div className="p-6">
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-gray-900 dark:text-white">支付配置</h1>
        <p className="text-gray-500 dark:text-gray-400 mt-1">配置网站的支付方式，支持支付宝、微信支付等</p>
      </div>

      <div className="space-y-6">
        {configs.map((config) => {
          const fields = configFields[config.payment_method] || [];
          
          return (
            <Card key={config.id} className="overflow-hidden">
              <CardHeader className="bg-gray-50 dark:bg-gray-800/50 border-b dark:border-gray-700">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className={`p-2 rounded-lg ${config.is_enabled ? 'bg-green-100 dark:bg-green-900/30' : 'bg-gray-100 dark:bg-gray-700'}`}>
                      <CreditCard className={`h-5 w-5 ${config.is_enabled ? 'text-green-600 dark:text-green-400' : 'text-gray-500'}`} />
                    </div>
                    <div>
                      <CardTitle className="text-lg">{config.display_name}</CardTitle>
                      <CardDescription className="text-sm">
                        {config.description}
                      </CardDescription>
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    <span className={`text-sm font-medium ${config.is_enabled ? 'text-green-600 dark:text-green-400' : 'text-gray-500'}`}>
                      {config.is_enabled ? '已启用' : '已禁用'}
                    </span>
                    <Switch
                      checked={config.is_enabled}
                      onCheckedChange={(checked) => handleToggle(config.id, checked)}
                    />
                  </div>
                </div>
              </CardHeader>
              <CardContent className="p-6">
                {errors[config.id] && (
                  <Alert variant="destructive" className="mb-4">
                    <AlertDescription>{errors[config.id]}</AlertDescription>
                  </Alert>
                )}
                
                {successes[config.id] && (
                  <Alert className="mb-4 bg-green-50 dark:bg-green-900/20 border-green-200 dark:border-green-800">
                    <CheckCircle2 className="h-4 w-4 text-green-600 dark:text-green-400" />
                    <AlertDescription className="text-green-700 dark:text-green-300 ml-2">
                      配置已保存
                    </AlertDescription>
                  </Alert>
                )}

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
                  {fields.map((field) => (
                    <div key={field.field} className="space-y-2">
                      <Label htmlFor={`${config.id}-${field.field}`} className="text-sm font-medium">
                        {field.label}
                      </Label>
                      {field.type === 'textarea' ? (
                        <Textarea
                          id={`${config.id}-${field.field}`}
                          value={config.config[field.field] || ''}
                          onChange={(e) =>
                            handleConfigChange(config.id, field.field, e.target.value)
                          }
                          placeholder={field.placeholder}
                          rows={3}
                          className="resize-none font-mono text-xs"
                        />
                      ) : field.type === 'select' ? (
                        <select
                          id={`${config.id}-${field.field}`}
                          value={config.config[field.field] || ''}
                          onChange={(e) =>
                            handleConfigChange(config.id, field.field, e.target.value)
                          }
                          className="w-full h-10 px-3 py-2 text-sm rounded-md border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800 focus:outline-none focus:ring-2 focus:ring-blue-500"
                        >
                          <option value="">请选择</option>
                          <option value="sandbox">沙箱模式（测试环境）</option>
                          <option value="live">生产模式（正式环境）</option>
                        </select>
                      ) : (
                        <Input
                          id={`${config.id}-${field.field}`}
                          type={field.type === 'password' ? 'password' : 'text'}
                          value={config.config[field.field] || ''}
                          onChange={(e) =>
                            handleConfigChange(config.id, field.field, e.target.value)
                          }
                          placeholder={field.placeholder}
                          className={field.field.includes('key') || field.field.includes('token') ? 'font-mono text-xs' : ''}
                        />
                      )}
                      {field.help && (
                        <p className="text-xs text-gray-500 dark:text-gray-400">{field.help}</p>
                      )}
                    </div>
                  ))}
                </div>

                <div className="flex justify-end">
                  <Button
                    onClick={() => handleSave(config)}
                    disabled={saving === config.id}
                  >
                    <Save className="mr-2 h-4 w-4" />
                    {saving === config.id ? '保存中...' : '保存配置'}
                  </Button>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      <Card className="mt-6">
        <CardHeader className="bg-gray-50 dark:bg-gray-800/50 border-b dark:border-gray-700">
          <CardTitle className="text-lg">接口说明</CardTitle>
        </CardHeader>
        <CardContent className="p-6">
          <div className="space-y-4 text-sm text-gray-600 dark:text-gray-400">
            <div>
              <h4 className="font-medium text-gray-900 dark:text-white mb-2">支付宝配置步骤</h4>
              <ol className="list-decimal list-inside space-y-2">
                <li>登录 <a href="https://open.alipay.com" target="_blank" className="text-blue-500 hover:underline">支付宝开放平台</a> 创建应用</li>
                <li>添加 <strong>当面付</strong> 功能（alipay.trade.precreate）</li>
                <li>在应用详情页获取 <strong>AppId</strong></li>
                <li>使用 <a href="https://opendocs.alipay.com/common/02kipk" target="_blank" className="text-blue-500 hover:underline">支付宝密钥生成工具</a> 生成应用私钥和公钥</li>
                <li>将应用公钥上传到支付宝开放平台，获取 <strong>支付宝公钥</strong></li>
                <li>配置回调地址（需要公网可访问）</li>
                <li><strong>测试环境</strong>选择"沙箱模式"，<strong>正式环境</strong>选择"生产模式"</li>
              </ol>
            </div>
            <div>
              <h4 className="font-medium text-gray-900 dark:text-white mb-2">网关地址</h4>
              <ul className="list-disc list-inside space-y-1">
                <li><strong>正式环境</strong>：<code className="bg-gray-100 dark:bg-gray-700 px-1.5 py-0.5 rounded text-xs">https://openapi.alipay.com/gateway.do</code></li>
                <li><strong>沙箱环境</strong>：<code className="bg-gray-100 dark:bg-gray-700 px-1.5 py-0.5 rounded text-xs">https://openapi-sandbox.dl.alipaydev.com/gateway.do</code></li>
              </ul>
            </div>
            <div>
              <h4 className="font-medium text-gray-900 dark:text-white mb-2">回调地址配置</h4>
              <p className="mb-2">回调地址需要配置为您的服务器公网地址：</p>
              <ul className="list-disc list-inside space-y-1">
                <li>支付宝：<code className="bg-gray-100 dark:bg-gray-700 px-1.5 py-0.5 rounded text-xs">/api/payment/alipay/notify</code></li>
              </ul>
            </div>
            <div className="p-3 bg-amber-50 dark:bg-amber-900/20 border border-amber-200 dark:border-amber-800 rounded-lg">
              <p className="text-amber-700 dark:text-amber-300">
                <strong>⚠️ 安全提示：</strong>请妥善保管应用私钥，切勿泄露。正式上线前请确保使用生产模式。
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
