'use client';

import { useState, useRef, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Textarea } from '@/components/ui/textarea';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import { Checkbox } from '@/components/ui/checkbox';
import { 
  Sparkles, 
  Save, 
  FileText, 
  Trash2, 
  RefreshCw, 
  Send,
  Copy,
  Check,
  Loader2,
  ArrowRight,
  CheckSquare,
  Square,
  XCircle,
  ImageIcon,
} from 'lucide-react';
import Link from 'next/link';
import { useToast } from '@/hooks/use-toast';

interface LocalArticle {
  filename: string;
  title: string;
  size: number;
  createdAt: string;
  modifiedAt: string;
}

export default function AIWritePage() {
  const [prompt, setPrompt] = useState('');
  const [style, setStyle] = useState('professional');
  const [length, setLength] = useState('1500');
  const [generatedContent, setGeneratedContent] = useState('');
  const [generatedTitle, setGeneratedTitle] = useState('');
  const [coverImage, setCoverImage] = useState<string | null>(null);
  const [coverMediaId, setCoverMediaId] = useState<string | null>(null);
  const [isGenerating, setIsGenerating] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [localArticles, setLocalArticles] = useState<LocalArticle[]>([]);
  const [loadingArticles, setLoadingArticles] = useState(true);
  const [copied, setCopied] = useState(false);
  const outputRef = useRef<HTMLDivElement>(null);
  const { toast } = useToast();
  
  // 批量选择相关状态
  const [selectMode, setSelectMode] = useState(false);
  const [selectedFilenames, setSelectedFilenames] = useState<Set<string>>(new Set());
  const [batchDeleteOpen, setBatchDeleteOpen] = useState(false);
  const [batchDeleting, setBatchDeleting] = useState(false);

  useEffect(() => {
    fetchLocalArticles();
  }, []);

  const fetchLocalArticles = async () => {
    setLoadingArticles(true);
    try {
      const response = await fetch('/api/local-articles');
      const data = await response.json();
      setLocalArticles(data.articles || []);
    } catch (error) {
      console.error('Failed to fetch articles:', error);
    } finally {
      setLoadingArticles(false);
    }
  };

  const handleGenerate = async () => {
    if (!prompt.trim()) {
      toast({
        title: '请输入写作要求',
        variant: 'destructive',
      });
      return;
    }

    setIsGenerating(true);
    setGeneratedContent('');
    setGeneratedTitle('');
    setCoverImage(null);
    setCoverMediaId(null);

    try {
      const response = await fetch('/api/ai-write', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          prompt: prompt.trim(),
          style,
          length: parseInt(length),
        }),
      });

      if (!response.ok) {
        throw new Error('请求失败');
      }

      const reader = response.body?.getReader();
      const decoder = new TextDecoder();

      if (!reader) {
        throw new Error('无法读取响应');
      }

      let fullContent = '';

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;

        const chunk = decoder.decode(value);
        const lines = chunk.split('\n');

        for (const line of lines) {
          if (line.startsWith('data: ')) {
            try {
              const data = JSON.parse(line.slice(6));
              
              if (data.error) {
                throw new Error(data.error);
              }
              
              if (data.done) {
                setIsGenerating(false);
              } else if (data.content) {
                fullContent += data.content;
                setGeneratedContent(fullContent);
                
                // 提取标题（第一行 # 开头的内容）
                const titleMatch = fullContent.match(/^#\s+(.+)$/m);
                if (titleMatch) {
                  setGeneratedTitle(titleMatch[1].trim());
                } else {
                  // 如果没有标题格式，使用第一行作为标题
                  const firstLine = fullContent.split('\n')[0];
                  setGeneratedTitle(firstLine.replace(/^#+\s*/, '').substring(0, 100));
                }

                // 滚动到底部
                if (outputRef.current) {
                  outputRef.current.scrollTop = outputRef.current.scrollHeight;
                }
              } else if (data.coverImage) {
                // 收到封面图
                setCoverImage(data.coverImage);
                setCoverMediaId(data.mediaId);
                toast({
                  title: '封面图生成成功',
                  description: '已自动保存到媒体库',
                });
              }
            } catch {
              // 忽略解析错误
            }
          }
        }
      }
    } catch (error) {
      console.error('Generate error:', error);
      toast({
        title: '生成失败',
        description: error instanceof Error ? error.message : '请稍后重试',
        variant: 'destructive',
      });
      setIsGenerating(false);
    }
  };

  const handleSave = async () => {
    if (!generatedContent.trim()) {
      toast({
        title: '没有内容可保存',
        variant: 'destructive',
      });
      return;
    }

    setIsSaving(true);
    try {
      const response = await fetch('/api/local-articles', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          title: generatedTitle || '无标题文章',
          content: generatedContent,
        }),
      });

      if (response.ok) {
        toast({
          title: '保存成功',
          description: '文章已保存到本地',
        });
        fetchLocalArticles();
      } else {
        throw new Error('保存失败');
      }
    } catch (error) {
      console.error('Save error:', error);
      toast({
        title: '保存失败',
        variant: 'destructive',
      });
    } finally {
      setIsSaving(false);
    }
  };

  const handleDeleteArticle = async (filename: string) => {
    if (!confirm('确定要删除这篇文章吗？')) return;

    try {
      const response = await fetch(`/api/local-articles/${encodeURIComponent(filename)}`, {
        method: 'DELETE',
      });

      if (response.ok) {
        toast({
          title: '删除成功',
        });
        fetchLocalArticles();
      }
    } catch (error) {
      console.error('Delete error:', error);
      toast({
        title: '删除失败',
        variant: 'destructive',
      });
    }
  };

  // 批量删除
  const handleBatchDelete = async () => {
    if (selectedFilenames.size === 0) return;

    setBatchDeleting(true);
    try {
      const response = await fetch('/api/local-articles', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          filenames: Array.from(selectedFilenames),
        }),
      });

      if (response.ok) {
        const data = await response.json();
        toast({
          title: '批量删除成功',
          description: `已删除 ${data.deleted} 篇文章`,
        });
        setSelectedFilenames(new Set());
        setSelectMode(false);
        fetchLocalArticles();
      } else {
        throw new Error('删除失败');
      }
    } catch (error) {
      console.error('Batch delete error:', error);
      toast({
        title: '批量删除失败',
        variant: 'destructive',
      });
    } finally {
      setBatchDeleting(false);
      setBatchDeleteOpen(false);
    }
  };

  // 切换选择模式
  const toggleSelectMode = () => {
    setSelectMode(!selectMode);
    setSelectedFilenames(new Set());
  };

  // 切换单个选择
  const toggleSelect = (filename: string) => {
    const newSelected = new Set(selectedFilenames);
    if (newSelected.has(filename)) {
      newSelected.delete(filename);
    } else {
      newSelected.add(filename);
    }
    setSelectedFilenames(newSelected);
  };

  // 全选/取消全选
  const toggleSelectAll = () => {
    if (selectedFilenames.size === localArticles.length) {
      setSelectedFilenames(new Set());
    } else {
      setSelectedFilenames(new Set(localArticles.map(a => a.filename)));
    }
  };

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(generatedContent);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
      toast({
        title: '已复制到剪贴板',
      });
    } catch {
      toast({
        title: '复制失败',
        variant: 'destructive',
      });
    }
  };

  // 发布文章：先保存，然后跳转到发布页面
  const handlePublish = async () => {
    if (!generatedContent.trim()) {
      toast({
        title: '没有内容可发布',
        variant: 'destructive',
      });
      return;
    }

    setIsSaving(true);
    try {
      const response = await fetch('/api/local-articles', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          title: generatedTitle || '无标题文章',
          content: generatedContent,
          coverImage,
          mediaId: coverMediaId,
        }),
      });

      if (response.ok) {
        const data = await response.json();
        toast({
          title: '保存成功，正在跳转发布页面...',
        });
        // 跳转到发布页面，通过文件名加载内容，并传递封面图
        const params = new URLSearchParams({ file: data.filename });
        if (coverImage) params.set('cover', coverImage);
        if (coverMediaId) params.set('mediaId', coverMediaId);
        window.location.href = `/admin/posts/new?${params.toString()}`;
      } else {
        throw new Error('保存失败');
      }
    } catch (error) {
      console.error('Publish error:', error);
      toast({
        title: '发布失败',
        description: '请先保存文章，然后从本地文章列表发布',
        variant: 'destructive',
      });
    } finally {
      setIsSaving(false);
    }
  };

  const formatSize = (bytes: number) => {
    if (bytes < 1024) return bytes + ' B';
    if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' KB';
    return (bytes / (1024 * 1024)).toFixed(1) + ' MB';
  };

  return (
    <div className="p-6">
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-gray-900 dark:text-white flex items-center gap-2">
          <Sparkles className="w-6 h-6 text-[#0ea5e9]" />
          AI 智能写作
        </h1>
        <p className="text-gray-500 dark:text-gray-400 mt-1">
          使用AI自动生成文章，支持多种风格和长度
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* 左侧：输入和生成 */}
        <div className="space-y-6">
          {/* 写作设置 */}
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-lg">写作设置</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="prompt">写作要求 / 主题</Label>
                <Textarea
                  id="prompt"
                  value={prompt}
                  onChange={(e) => setPrompt(e.target.value)}
                  placeholder="例如：写一篇关于人工智能发展趋势的文章，重点讨论大语言模型的应用前景"
                  rows={4}
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>写作风格</Label>
                  <Select value={style} onValueChange={setStyle}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="professional">专业严谨</SelectItem>
                      <SelectItem value="casual">轻松活泼</SelectItem>
                      <SelectItem value="academic">学术研究</SelectItem>
                      <SelectItem value="storytelling">故事叙述</SelectItem>
                      <SelectItem value="tutorial">教程指南</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label>文章长度</Label>
                  <Select value={length} onValueChange={setLength}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="500">短文 (~500字)</SelectItem>
                      <SelectItem value="1000">中等 (~1000字)</SelectItem>
                      <SelectItem value="1500">标准 (~1500字)</SelectItem>
                      <SelectItem value="2000">长文 (~2000字)</SelectItem>
                      <SelectItem value="3000">深度 (~3000字)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <Button
                onClick={handleGenerate}
                disabled={isGenerating || !prompt.trim()}
                className="w-full"
                size="lg"
              >
                {isGenerating ? (
                  <>
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    正在生成...
                  </>
                ) : (
                  <>
                    <Sparkles className="w-4 h-4 mr-2" />
                    开始写作
                  </>
                )}
              </Button>
            </CardContent>
          </Card>

          {/* 本地文章列表 */}
          <Card>
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between">
                <CardTitle className="text-lg flex items-center gap-2">
                  <FileText className="w-5 h-5 text-[#0ea5e9]" />
                  本地文章
                </CardTitle>
                <div className="flex items-center gap-2">
                  {selectMode ? (
                    <>
                      <Button variant="outline" size="sm" onClick={toggleSelectAll}>
                        {selectedFilenames.size === localArticles.length ? (
                          <>
                            <CheckSquare className="w-4 h-4 mr-1" />
                            取消全选
                          </>
                        ) : (
                          <>
                            <Square className="w-4 h-4 mr-1" />
                            全选
                          </>
                        )}
                      </Button>
                      <Button
                        variant="destructive"
                        size="sm"
                        onClick={() => setBatchDeleteOpen(true)}
                        disabled={selectedFilenames.size === 0}
                      >
                        <Trash2 className="w-4 h-4 mr-1" />
                        删除 ({selectedFilenames.size})
                      </Button>
                      <Button variant="ghost" size="sm" onClick={toggleSelectMode}>
                        <XCircle className="w-4 h-4 mr-1" />
                        取消
                      </Button>
                    </>
                  ) : (
                    <>
                      <Button variant="outline" size="sm" onClick={toggleSelectMode}>
                        <CheckSquare className="w-4 h-4 mr-1" />
                        批量选择
                      </Button>
                      <Button variant="ghost" size="sm" onClick={fetchLocalArticles}>
                        <RefreshCw className="w-4 h-4" />
                      </Button>
                    </>
                  )}
                </div>
              </div>
            </CardHeader>
            <CardContent>
              {loadingArticles ? (
                <div className="text-center py-8 text-gray-500">
                  <Loader2 className="w-6 h-6 animate-spin mx-auto" />
                </div>
              ) : localArticles.length === 0 ? (
                <div className="text-center py-8 text-gray-500">
                  <FileText className="w-12 h-12 mx-auto mb-2 text-gray-300" />
                  <p>暂无本地文章</p>
                  <p className="text-sm">生成的文章可以保存到这里</p>
                </div>
              ) : (
                <div className="space-y-2 max-h-80 overflow-y-auto">
                  {localArticles.map((article) => {
                    const isSelected = selectedFilenames.has(article.filename);
                    return (
                      <div
                        key={article.filename}
                        className={`flex items-center gap-2 p-3 rounded-lg transition-colors ${
                          isSelected 
                            ? 'bg-blue-50 dark:bg-blue-900/20' 
                            : 'hover:bg-gray-50 dark:hover:bg-gray-800'
                        }`}
                      >
                        {selectMode && (
                          <Checkbox
                            checked={isSelected}
                            onCheckedChange={() => toggleSelect(article.filename)}
                          />
                        )}
                        <div className="min-w-0 flex-1">
                          <p className="font-medium truncate">{article.title}</p>
                          <p className="text-xs text-gray-500 mt-1">
                            {formatSize(article.size)} · {new Date(article.createdAt).toLocaleDateString('zh-CN')}
                          </p>
                        </div>
                        {!selectMode && (
                          <div className="flex items-center gap-1">
                            <Link
                              href={`/admin/posts/new?file=${encodeURIComponent(article.filename)}`}
                              className="p-1.5 text-[#0ea5e9] hover:bg-[#0ea5e9]/10 rounded"
                              title="发布文章"
                            >
                              <ArrowRight className="w-4 h-4" />
                            </Link>
                            <button
                              onClick={() => handleDeleteArticle(article.filename)}
                              className="p-1.5 text-red-500 hover:bg-red-50 rounded"
                              title="删除"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        {/* 右侧：生成结果 */}
        <Card className="lg:row-span-2">
          <CardHeader className="pb-3">
            <div className="flex items-center justify-between">
              <CardTitle className="text-lg">生成结果</CardTitle>
              {generatedContent && (
                <div className="flex gap-2">
                  <Button variant="outline" size="sm" onClick={handleCopy}>
                    {copied ? (
                      <Check className="w-4 h-4 mr-1" />
                    ) : (
                      <Copy className="w-4 h-4 mr-1" />
                    )}
                    复制
                  </Button>
                  <Button variant="outline" size="sm" onClick={handleSave} disabled={isSaving}>
                    {isSaving ? (
                      <Loader2 className="w-4 h-4 mr-1 animate-spin" />
                    ) : (
                      <Save className="w-4 h-4 mr-1" />
                    )}
                    保存
                  </Button>
                  <Button 
                    variant="outline" 
                    size="sm" 
                    onClick={handlePublish}
                    disabled={isSaving || !generatedContent.trim()}
                  >
                    {isSaving ? (
                      <Loader2 className="w-4 h-4 mr-1 animate-spin" />
                    ) : (
                      <Send className="w-4 h-4 mr-1" />
                    )}
                    发布
                  </Button>
                </div>
              )}
            </div>
          </CardHeader>
          <CardContent>
            <div
              ref={outputRef}
              className="min-h-[500px] max-h-[calc(100vh-300px)] overflow-y-auto p-4 bg-gray-50 dark:bg-gray-900 rounded-lg"
            >
              {isGenerating && !generatedContent ? (
                <div className="flex items-center justify-center h-full">
                  <div className="text-center">
                    <Loader2 className="w-8 h-8 animate-spin mx-auto mb-4 text-[#0ea5e9]" />
                    <p className="text-gray-500">AI 正在创作中...</p>
                    <p className="text-sm text-gray-400 mt-1">请稍候，这可能需要几十秒</p>
                  </div>
                </div>
              ) : generatedContent ? (
                <div className="space-y-4">
                  {/* 封面图显示 */}
                  {coverImage && (
                    <div className="relative group">
                      <img 
                        src={coverImage} 
                        alt="文章封面" 
                        className="w-full h-48 object-cover rounded-lg border"
                      />
                      <div className="absolute top-2 right-2 bg-black/50 text-white text-xs px-2 py-1 rounded">
                        AI 生成封面
                      </div>
                    </div>
                  )}
                  {/* 正在生成封面图提示 */}
                  {isGenerating && generatedContent && !coverImage && (
                    <div className="flex items-center gap-2 text-sm text-gray-500 bg-blue-50 dark:bg-blue-900/20 p-3 rounded-lg">
                      <Loader2 className="w-4 h-4 animate-spin text-[#0ea5e9]" />
                      <span>正在生成文章封面图...</span>
                    </div>
                  )}
                  <div className="prose prose-sm dark:prose-invert max-w-none whitespace-pre-wrap">
                    {generatedContent}
                  </div>
                </div>
              ) : (
                <div className="flex items-center justify-center h-full">
                  <div className="text-center text-gray-400">
                    <Sparkles className="w-12 h-12 mx-auto mb-4" />
                    <p>输入写作要求，开始生成文章</p>
                  </div>
                </div>
              )}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* 批量删除确认对话框 */}
      <AlertDialog open={batchDeleteOpen} onOpenChange={setBatchDeleteOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>确认批量删除</AlertDialogTitle>
            <AlertDialogDescription>
              确定要删除选中的 {selectedFilenames.size} 篇文章吗？此操作不可撤销。
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={batchDeleting}>取消</AlertDialogCancel>
            <AlertDialogAction 
              onClick={handleBatchDelete} 
              className="bg-red-500 hover:bg-red-600"
              disabled={batchDeleting}
            >
              {batchDeleting ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  删除中...
                </>
              ) : (
                `删除 ${selectedFilenames.size} 篇文章`
              )}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
