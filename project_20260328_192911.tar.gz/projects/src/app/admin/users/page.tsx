'use client';

import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent } from '@/components/ui/card';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Plus, Edit, Trash2, Search, ChevronLeft, ChevronRight, Crown, Receipt, Eye } from 'lucide-react';
import { Alert, AlertDescription } from '@/components/ui/alert';

interface User {
  id: string;
  username: string;
  email: string;
  display_name: string;
  role: string;
  is_active: boolean;
  created_at: string;
  membership?: {
    status: string;
    expired_at: string | null;
    membership_plans: {
      id: string;
      name: string;
    };
  } | null;
  orderStats?: {
    total: number;
    paid: number;
  };
}

export default function UsersPage() {
  const [users, setUsers] = useState<User[]>([]);
  const [loading, setLoading] = useState(true);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingUser, setEditingUser] = useState<User | null>(null);
  const [error, setError] = useState('');
  const [page, setPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [search, setSearch] = useState('');
  const [userOrdersDialog, setUserOrdersDialog] = useState<{ open: boolean; user: User | null; orders: any[] }>({
    open: false,
    user: null,
    orders: [],
  });
  
  const [formData, setFormData] = useState({
    username: '',
    email: '',
    password: '',
    display_name: '',
    role: 'subscriber',
    is_active: true,
  });

  useEffect(() => {
    fetchUsers();
  }, [page, search]);

  const fetchUsers = async () => {
    setLoading(true);
    try {
      const params = new URLSearchParams({
        page: page.toString(),
        limit: '10',
        ...(search && { search }),
      });

      const response = await fetch(`/api/users?${params}`);
      const data = await response.json();
      
      setUsers(data.users || []);
      setTotalPages(data.totalPages || 1);
    } catch (error) {
      console.error('Failed to fetch users:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleOpenDialog = (user?: User) => {
    if (user) {
      setEditingUser(user);
      setFormData({
        username: user.username,
        email: user.email,
        password: '',
        display_name: user.display_name || '',
        role: user.role,
        is_active: user.is_active,
      });
    } else {
      setEditingUser(null);
      setFormData({
        username: '',
        email: '',
        password: '',
        display_name: '',
        role: 'subscriber',
        is_active: true,
      });
    }
    setError('');
    setDialogOpen(true);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    try {
      const url = editingUser
        ? `/api/users/${editingUser.id}`
        : '/api/users';
      const method = editingUser ? 'PUT' : 'POST';

      const body = { ...formData };
      if (editingUser && !body.password) {
        delete (body as Partial<typeof body>).password;
      }

      const response = await fetch(url, {
        method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body),
      });

      const data = await response.json();

      if (!response.ok) {
        setError(data.error || '操作失败');
        return;
      }

      setDialogOpen(false);
      fetchUsers();
    } catch (error) {
      console.error('Failed to save user:', error);
      setError('网络错误，请稍后重试');
    }
  };

  const handleDelete = async (user: User) => {
    // 检查用户是否有订单
    if (user.orderStats && user.orderStats.total > 0) {
      alert(`无法删除用户 "${user.username}"：该用户有 ${user.orderStats.total} 条订单记录。\n\n请先在订单管理中删除该用户的订单，或选择禁用该用户账户。`);
      return;
    }
    
    if (!confirm(`确定要删除用户 "${user.username}" 吗？此操作不可恢复。`)) return;

    try {
      const response = await fetch(`/api/users/${user.id}`, {
        method: 'DELETE',
      });

      const data = await response.json();

      if (!response.ok) {
        alert(data.error || '删除失败');
        return;
      }

      fetchUsers();
    } catch (error) {
      console.error('Failed to delete user:', error);
      alert('删除失败');
    }
  };

  const handleViewOrders = async (user: User) => {
    try {
      const response = await fetch(`/api/orders?userId=${user.id}`);
      const data = await response.json();
      setUserOrdersDialog({
        open: true,
        user,
        orders: data.orders || [],
      });
    } catch (error) {
      console.error('Failed to fetch orders:', error);
    }
  };

  const getRoleBadge = (role: string) => {
    const styles: Record<string, string> = {
      admin: 'bg-blue-100 text-blue-700 dark:bg-blue-900/30 dark:text-blue-400',
      editor: 'bg-purple-100 text-purple-700 dark:bg-purple-900/30 dark:text-purple-400',
      author: 'bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-400',
      subscriber: 'bg-gray-100 text-gray-700 dark:bg-gray-700 dark:text-gray-300',
    };
    const labels: Record<string, string> = {
      admin: '管理员',
      editor: '编辑',
      author: '作者',
      subscriber: '订阅者',
    };
    return (
      <span className={`px-2 py-1 rounded text-xs font-medium ${styles[role] || styles.subscriber}`}>
        {labels[role] || role}
      </span>
    );
  };

  const getMembershipBadge = (membership: User['membership']) => {
    if (!membership) {
      return <span className="text-gray-400 text-xs">非会员</span>;
    }

    const isExpired = membership.expired_at && new Date(membership.expired_at) < new Date();
    
    if (isExpired) {
      return <span className="text-gray-400 text-xs">已过期</span>;
    }

    return (
      <span className="inline-flex items-center gap-1 px-2 py-1 rounded text-xs font-medium bg-amber-100 text-amber-700 dark:bg-amber-900/30 dark:text-amber-400">
        <Crown className="w-3 h-3" />
        {membership.membership_plans?.name || '会员'}
      </span>
    );
  };

  return (
    <div className="p-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 mb-6">
        <div>
          <h1 className="text-2xl font-bold text-gray-900 dark:text-white">用户管理</h1>
          <p className="text-gray-500 dark:text-gray-400 mt-1">管理系统用户和权限</p>
        </div>
        <Button onClick={() => handleOpenDialog()}>
          <Plus className="mr-2 h-4 w-4" />
          新建用户
        </Button>
      </div>

      <Card>
        <CardContent className="p-0">
          {/* 搜索栏 */}
          <div className="p-4 border-b dark:border-gray-700">
            <div className="relative max-w-sm">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" />
              <Input
                placeholder="搜索用户名或邮箱..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="pl-10"
              />
            </div>
          </div>

          {loading ? (
            <div className="text-center py-12 text-gray-500">加载中...</div>
          ) : users.length === 0 ? (
            <div className="text-center py-12 text-gray-500">
              <p>暂无用户</p>
              <button onClick={() => handleOpenDialog()} className="text-blue-500 hover:underline mt-2">
                创建第一个用户
              </button>
            </div>
          ) : (
            <>
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow className="bg-gray-50 dark:bg-gray-800/50">
                      <TableHead className="font-medium">用户名</TableHead>
                      <TableHead className="font-medium">邮箱</TableHead>
                      <TableHead className="font-medium">会员状态</TableHead>
                      <TableHead className="font-medium">会员到期</TableHead>
                      <TableHead className="font-medium">角色</TableHead>
                      <TableHead className="font-medium">订单</TableHead>
                      <TableHead className="font-medium">状态</TableHead>
                      <TableHead className="font-medium text-right">操作</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {users.map((user) => (
                      <TableRow key={user.id} className="hover:bg-gray-50 dark:hover:bg-gray-800/30">
                        <TableCell className="font-medium">
                          <div className="flex items-center gap-2">
                            <div className="w-8 h-8 bg-gradient-to-br from-[#0ea5e9] to-[#06b6d4] rounded-full flex items-center justify-center">
                              <span className="text-white text-xs font-bold">
                                {(user.display_name || user.username || 'U')[0].toUpperCase()}
                              </span>
                            </div>
                            <div>
                              <p className="font-medium">{user.username}</p>
                              {user.display_name && (
                                <p className="text-xs text-gray-400">{user.display_name}</p>
                              )}
                            </div>
                          </div>
                        </TableCell>
                        <TableCell className="text-gray-500">{user.email}</TableCell>
                        <TableCell>{getMembershipBadge(user.membership)}</TableCell>
                        <TableCell className="text-gray-500 text-sm">
                          {user.membership?.expired_at 
                            ? new Date(user.membership.expired_at).toLocaleDateString('zh-CN')
                            : user.membership ? '永久' : '-'}
                        </TableCell>
                        <TableCell>{getRoleBadge(user.role)}</TableCell>
                        <TableCell>
                          <button
                            onClick={() => handleViewOrders(user)}
                            className="inline-flex items-center gap-1 text-xs text-blue-600 hover:text-blue-800 dark:text-blue-400"
                          >
                            <Receipt className="w-3 h-3" />
                            {user.orderStats?.paid || 0}/{user.orderStats?.total || 0}
                          </button>
                        </TableCell>
                        <TableCell>
                          <span className={`px-2 py-1 rounded text-xs font-medium ${
                            user.is_active 
                              ? 'bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-400' 
                              : 'bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-400'
                          }`}>
                            {user.is_active ? '激活' : '禁用'}
                          </span>
                        </TableCell>
                        <TableCell className="text-right">
                          <div className="flex justify-end gap-2">
                            <Button
                              variant="ghost"
                              size="sm"
                              className="h-8 w-8 p-0"
                              onClick={() => handleViewOrders(user)}
                              title="查看订单"
                            >
                              <Eye className="h-4 w-4" />
                            </Button>
                            <Button
                              variant="ghost"
                              size="sm"
                              className="h-8 w-8 p-0"
                              onClick={() => handleOpenDialog(user)}
                            >
                              <Edit className="h-4 w-4" />
                            </Button>
                            <Button
                              variant="ghost"
                              size="sm"
                              className="h-8 w-8 p-0 text-red-500 hover:text-red-600 hover:bg-red-50"
                              onClick={() => handleDelete(user)}
                            >
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>

              {/* 分页 */}
              <div className="flex items-center justify-between p-4 border-t dark:border-gray-700">
                <p className="text-sm text-gray-500">
                  第 {page} / {totalPages} 页
                </p>
                <div className="flex gap-2">
                  <Button
                    variant="outline"
                    size="sm"
                    disabled={page === 1}
                    onClick={() => setPage(page - 1)}
                  >
                    <ChevronLeft className="h-4 w-4" />
                    上一页
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    disabled={page === totalPages}
                    onClick={() => setPage(page + 1)}
                  >
                    下一页
                    <ChevronRight className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            </>
          )}
        </CardContent>
      </Card>

      {/* 编辑用户对话框 */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="sm:max-w-[425px]">
          <DialogHeader>
            <DialogTitle>
              {editingUser ? '编辑用户' : '新建用户'}
            </DialogTitle>
          </DialogHeader>
          <form onSubmit={handleSubmit} className="space-y-4 mt-4">
            {error && (
              <Alert variant="destructive">
                <AlertDescription>{error}</AlertDescription>
              </Alert>
            )}
            
            <div className="space-y-2">
              <Label htmlFor="username">用户名</Label>
              <Input
                id="username"
                value={formData.username}
                onChange={(e) => setFormData({ ...formData, username: e.target.value })}
                placeholder="用户名"
                required
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="email">邮箱</Label>
              <Input
                id="email"
                type="email"
                value={formData.email}
                onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                placeholder="user@example.com"
                required
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="password">
                密码 {editingUser && <span className="text-gray-400 text-sm">(留空则不修改)</span>}
              </Label>
              <Input
                id="password"
                type="password"
                value={formData.password}
                onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                placeholder="••••••••"
                required={!editingUser}
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="display_name">显示名称</Label>
              <Input
                id="display_name"
                value={formData.display_name}
                onChange={(e) => setFormData({ ...formData, display_name: e.target.value })}
                placeholder="昵称"
              />
            </div>
            
            <div className="space-y-2">
              <Label>角色</Label>
              <Select
                value={formData.role}
                onValueChange={(value) => setFormData({ ...formData, role: value })}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="admin">管理员</SelectItem>
                  <SelectItem value="editor">编辑</SelectItem>
                  <SelectItem value="author">作者</SelectItem>
                  <SelectItem value="subscriber">订阅者</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            <div className="flex justify-end gap-2 pt-4">
              <Button
                type="button"
                variant="outline"
                onClick={() => setDialogOpen(false)}
              >
                取消
              </Button>
              <Button type="submit">保存</Button>
            </div>
          </form>
        </DialogContent>
      </Dialog>

      {/* 用户订单对话框 */}
      <Dialog open={userOrdersDialog.open} onOpenChange={(open) => setUserOrdersDialog({ ...userOrdersDialog, open })}>
        <DialogContent className="sm:max-w-[600px]">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Receipt className="w-5 h-5" />
              {userOrdersDialog.user?.username} 的订单记录
            </DialogTitle>
          </DialogHeader>
          <div className="mt-4 max-h-[400px] overflow-y-auto">
            {userOrdersDialog.orders.length === 0 ? (
              <p className="text-center text-gray-500 py-8">暂无订单记录</p>
            ) : (
              <div className="space-y-3">
                {userOrdersDialog.orders.map((order: any) => (
                  <div
                    key={order.id}
                    className="p-3 border dark:border-gray-700 rounded-lg"
                  >
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-sm font-mono text-gray-500">{order.order_no}</span>
                      <span className={`px-2 py-0.5 rounded text-xs ${
                        order.payment_status === 'paid'
                          ? 'bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-400'
                          : 'bg-amber-100 text-amber-700 dark:bg-amber-900/30 dark:text-amber-400'
                      }`}>
                        {order.payment_status === 'paid' ? '已支付' : '待支付'}
                      </span>
                    </div>
                    <div className="flex items-center justify-between">
                      <div className="text-sm">
                        {order.membership_plans?.name && (
                          <span className="flex items-center gap-1">
                            <Crown className="w-3 h-3 text-amber-500" />
                            {order.membership_plans.name}
                          </span>
                        )}
                        {order.metadata?.post_title && (
                          <span>文章: {order.metadata.post_title}</span>
                        )}
                      </div>
                      <span className="font-medium">¥{order.amount}</span>
                    </div>
                    <p className="text-xs text-gray-400 mt-1">
                      {new Date(order.created_at).toLocaleString('zh-CN')}
                    </p>
                  </div>
                ))}
              </div>
            )}
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
