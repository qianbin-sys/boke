'use client';

import { useState, useEffect, useCallback } from 'react';
import { 
  Image, 
  Video, 
  FileText, 
  Trash2, 
  Upload, 
  X, 
  Copy, 
  Check,
  RefreshCw,
  CheckSquare,
  Square,
  XCircle,
  Loader2,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import { useToast } from '@/hooks/use-toast';

interface MediaFile {
  id: string;
  filename: string;
  original_name: string;
  mime_type: string;
  size: number;
  storage_key: string;
  url: string;
  created_at: string;
}

export default function MediaPage() {
  const [files, setFiles] = useState<MediaFile[]>([]);
  const [loading, setLoading] = useState(true);
  const [uploading, setUploading] = useState(false);
  const [page, setPage] = useState(1);
  const [total, setTotal] = useState(0);
  const [type, setType] = useState<string>('image');
  const [deleteId, setDeleteId] = useState<string | null>(null);
  const [selectedFile, setSelectedFile] = useState<MediaFile | null>(null);
  const [copiedUrl, setCopiedUrl] = useState<string | null>(null);
  
  // 批量选择相关状态
  const [selectMode, setSelectMode] = useState(false);
  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set());
  const [batchDeleteOpen, setBatchDeleteOpen] = useState(false);
  const [batchDeleting, setBatchDeleting] = useState(false);
  
  const { toast } = useToast();

  const fetchFiles = useCallback(async () => {
    setLoading(true);
    try {
      const params = new URLSearchParams({
        page: page.toString(),
        limit: '30',
      });
      if (type !== 'all') {
        params.set('type', type);
      }

      const response = await fetch(`/api/media?${params}`);
      const data = await response.json();
      setFiles(data.files || []);
      setTotal(data.total || 0);
    } catch (error) {
      console.error('Failed to fetch files:', error);
    } finally {
      setLoading(false);
    }
  }, [page, type]);

  useEffect(() => {
    fetchFiles();
  }, [fetchFiles]);

  // 切换类型时清空选择
  useEffect(() => {
    setSelectedIds(new Set());
    setSelectMode(false);
  }, [type, page]);

  const handleUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setUploading(true);
    try {
      const formData = new FormData();
      formData.append('file', file);

      const response = await fetch('/api/upload', {
        method: 'POST',
        body: formData,
      });

      if (response.ok) {
        fetchFiles();
        toast({
          title: '上传成功',
          description: file.name,
        });
      } else {
        const data = await response.json();
        toast({
          title: '上传失败',
          description: data.error,
          variant: 'destructive',
        });
      }
    } catch (error) {
      console.error('Upload error:', error);
      toast({
        title: '上传失败',
        variant: 'destructive',
      });
    } finally {
      setUploading(false);
      e.target.value = '';
    }
  };

  const handleDelete = async () => {
    if (!deleteId) return;

    try {
      const response = await fetch(`/api/media/${deleteId}`, {
        method: 'DELETE',
      });

      if (response.ok) {
        fetchFiles();
        toast({
          title: '删除成功',
        });
      }
    } catch (error) {
      console.error('Delete error:', error);
      toast({
        title: '删除失败',
        variant: 'destructive',
      });
    } finally {
      setDeleteId(null);
    }
  };

  // 批量删除
  const handleBatchDelete = async () => {
    if (selectedIds.size === 0) return;

    setBatchDeleting(true);
    try {
      const deletePromises = Array.from(selectedIds).map(id =>
        fetch(`/api/media/${id}`, { method: 'DELETE' })
      );
      
      const results = await Promise.allSettled(deletePromises);
      const successCount = results.filter(r => r.status === 'fulfilled').length;
      const failCount = results.length - successCount;

      if (failCount === 0) {
        toast({
          title: '批量删除成功',
          description: `已删除 ${successCount} 个文件`,
        });
      } else {
        toast({
          title: '批量删除完成',
          description: `成功 ${successCount} 个，失败 ${failCount} 个`,
          variant: 'destructive',
        });
      }
      
      setSelectedIds(new Set());
      setSelectMode(false);
      fetchFiles();
    } catch (error) {
      console.error('Batch delete error:', error);
      toast({
        title: '批量删除失败',
        variant: 'destructive',
      });
    } finally {
      setBatchDeleting(false);
      setBatchDeleteOpen(false);
    }
  };

  // 切换选择模式
  const toggleSelectMode = () => {
    setSelectMode(!selectMode);
    setSelectedIds(new Set());
  };

  // 切换单个选择
  const toggleSelect = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    const newSelected = new Set(selectedIds);
    if (newSelected.has(id)) {
      newSelected.delete(id);
    } else {
      newSelected.add(id);
    }
    setSelectedIds(newSelected);
  };

  // 全选/取消全选
  const toggleSelectAll = () => {
    if (selectedIds.size === files.length) {
      setSelectedIds(new Set());
    } else {
      setSelectedIds(new Set(files.map(f => f.id)));
    }
  };

  const copyUrl = async (url: string) => {
    try {
      await navigator.clipboard.writeText(url);
      setCopiedUrl(url);
      setTimeout(() => setCopiedUrl(null), 2000);
      toast({
        title: '已复制',
        description: '图片链接已复制到剪贴板',
      });
    } catch (error) {
      console.error('Copy error:', error);
    }
  };

  const formatSize = (bytes: number) => {
    if (bytes < 1024) return bytes + ' B';
    if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' KB';
    return (bytes / (1024 * 1024)).toFixed(1) + ' MB';
  };

  const getFileIcon = (mimeType: string) => {
    if (mimeType.startsWith('image/')) return Image;
    if (mimeType.startsWith('video/')) return Video;
    return FileText;
  };

  const totalPages = Math.ceil(total / 30);

  return (
    <div className="p-6">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-2xl font-bold text-gray-900 dark:text-white flex items-center gap-2">
            <Image className="w-6 h-6 text-[#0ea5e9]" />
            媒体库
          </h1>
          <p className="text-gray-500 dark:text-gray-400 mt-1">
            共 {total} 个文件
          </p>
        </div>
        <div className="flex gap-2">
          {/* 批量操作按钮 */}
          {selectMode ? (
            <>
              <Button
                variant="outline"
                onClick={toggleSelectAll}
                className="gap-2"
              >
                {selectedIds.size === files.length ? (
                  <>
                    <CheckSquare className="w-4 h-4" />
                    取消全选
                  </>
                ) : (
                  <>
                    <Square className="w-4 h-4" />
                    全选
                  </>
                )}
              </Button>
              <Button
                variant="destructive"
                onClick={() => setBatchDeleteOpen(true)}
                disabled={selectedIds.size === 0}
                className="gap-2"
              >
                <Trash2 className="w-4 h-4" />
                删除 ({selectedIds.size})
              </Button>
              <Button
                variant="ghost"
                onClick={toggleSelectMode}
                className="gap-2"
              >
                <XCircle className="w-4 h-4" />
                取消选择
              </Button>
            </>
          ) : (
            <Button
              variant="outline"
              onClick={toggleSelectMode}
              className="gap-2"
            >
              <CheckSquare className="w-4 h-4" />
              批量选择
            </Button>
          )}
          
          <input
            type="file"
            id="file-upload"
            className="hidden"
            onChange={handleUpload}
            accept="image/*,video/*,.pdf,.doc,.docx"
          />
          <label htmlFor="file-upload">
            <Button asChild className="cursor-pointer">
              <span>
                <Upload className="w-4 h-4 mr-2" />
                {uploading ? '上传中...' : '上传文件'}
              </span>
            </Button>
          </label>
          <Button variant="outline" onClick={fetchFiles}>
            <RefreshCw className="w-4 h-4" />
          </Button>
        </div>
      </div>

      {/* 文件类型筛选 */}
      <Tabs value={type} onValueChange={(value) => { setType(value); setPage(1); }} className="mb-6">
        <TabsList>
          <TabsTrigger value="image">图片</TabsTrigger>
          <TabsTrigger value="video">视频</TabsTrigger>
          <TabsTrigger value="application">文档</TabsTrigger>
          <TabsTrigger value="all">全部</TabsTrigger>
        </TabsList>
      </Tabs>

      {/* 文件网格 */}
      <div className="bg-white dark:bg-gray-800 rounded-lg shadow">
        {loading ? (
          <div className="p-8 text-center text-gray-500">加载中...</div>
        ) : files.length === 0 ? (
          <div className="p-8 text-center text-gray-500">
            <Image className="w-12 h-12 mx-auto mb-4 text-gray-300" />
            <p>暂无文件</p>
          </div>
        ) : (
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-4 p-4">
            {files.map((file) => {
              const Icon = getFileIcon(file.mime_type);
              const isImage = file.mime_type.startsWith('image/');
              const isSelected = selectedIds.has(file.id);
              
              return (
                <div
                  key={file.id}
                  className={`group relative aspect-square rounded-lg border-2 overflow-hidden cursor-pointer transition-all ${
                    isSelected 
                      ? 'ring-2 ring-[#0ea5e9] border-[#0ea5e9]' 
                      : 'border-gray-200 dark:border-gray-700 hover:ring-2 hover:ring-[#0ea5e9]'
                  }`}
                  onClick={() => {
                    if (selectMode) {
                      toggleSelect(file.id, {} as React.MouseEvent);
                    } else {
                      setSelectedFile(file);
                    }
                  }}
                >
                  {isImage ? (
                    <img
                      src={file.url}
                      alt={file.original_name}
                      className="w-full h-full object-cover"
                    />
                  ) : (
                    <div className="w-full h-full flex items-center justify-center bg-gray-100 dark:bg-gray-700">
                      <Icon className="w-12 h-12 text-gray-400" />
                    </div>
                  )}
                  
                  {/* 选择模式下显示选择框 */}
                  {selectMode && (
                    <div className="absolute top-2 left-2">
                      {isSelected ? (
                        <CheckSquare className="w-6 h-6 text-[#0ea5e9] bg-white rounded" />
                      ) : (
                        <Square className="w-6 h-6 text-gray-400 bg-white rounded" />
                      )}
                    </div>
                  )}
                  
                  {/* 悬浮操作（非选择模式） */}
                  {!selectMode && (
                    <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-2">
                      <Button
                        size="icon"
                        variant="ghost"
                        className="text-white hover:text-white hover:bg-white/20"
                        onClick={(e) => {
                          e.stopPropagation();
                          copyUrl(file.url);
                        }}
                      >
                        {copiedUrl === file.url ? (
                          <Check className="w-4 h-4" />
                        ) : (
                          <Copy className="w-4 h-4" />
                        )}
                      </Button>
                      <Button
                        size="icon"
                        variant="ghost"
                        className="text-white hover:text-white hover:bg-white/20"
                        onClick={(e) => {
                          e.stopPropagation();
                          setDeleteId(file.id);
                        }}
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* 分页 */}
      {totalPages > 1 && (
        <div className="flex items-center justify-center gap-2 mt-6">
          <Button
            variant="outline"
            disabled={page === 1}
            onClick={() => setPage(page - 1)}
          >
            上一页
          </Button>
          <span className="text-gray-500">
            第 {page} / {totalPages} 页
          </span>
          <Button
            variant="outline"
            disabled={page === totalPages}
            onClick={() => setPage(page + 1)}
          >
            下一页
          </Button>
        </div>
      )}

      {/* 文件详情对话框 */}
      {selectedFile && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50" onClick={() => setSelectedFile(null)}>
          <div className="bg-white dark:bg-gray-800 rounded-lg p-6 max-w-2xl w-full mx-4 max-h-[90vh] overflow-auto" onClick={(e) => e.stopPropagation()}>
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-bold">文件详情</h3>
              <Button variant="ghost" size="icon" onClick={() => setSelectedFile(null)}>
                <X className="w-4 h-4" />
              </Button>
            </div>
            
            {selectedFile.mime_type.startsWith('image/') ? (
              <img
                src={selectedFile.url}
                alt={selectedFile.original_name}
                className="w-full max-h-80 object-contain rounded-lg mb-4"
              />
            ) : (
              <div className="w-full h-48 flex items-center justify-center bg-gray-100 dark:bg-gray-700 rounded-lg mb-4">
                {(() => {
                  const Icon = getFileIcon(selectedFile.mime_type);
                  return <Icon className="w-16 h-16 text-gray-400" />;
                })()}
              </div>
            )}
            
            <div className="space-y-2 text-sm">
              <div className="flex justify-between">
                <span className="text-gray-500">文件名</span>
                <span>{selectedFile.original_name}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-500">大小</span>
                <span>{formatSize(selectedFile.size)}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-500">类型</span>
                <span>{selectedFile.mime_type}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-500">上传时间</span>
                <span>{new Date(selectedFile.created_at).toLocaleString('zh-CN')}</span>
              </div>
              <div className="pt-2">
                <span className="text-gray-500 block mb-1">URL</span>
                <div className="flex gap-2">
                  <input
                    type="text"
                    value={selectedFile.url}
                    readOnly
                    className="flex-1 px-3 py-2 bg-gray-100 dark:bg-gray-700 rounded text-xs"
                  />
                  <Button size="sm" onClick={() => copyUrl(selectedFile.url)}>
                    复制
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* 单个删除确认对话框 */}
      <AlertDialog open={!!deleteId} onOpenChange={() => setDeleteId(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>确认删除</AlertDialogTitle>
            <AlertDialogDescription>
              确定要删除这个文件吗？此操作不可撤销，且文章中使用该图片的链接将失效。
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>取消</AlertDialogCancel>
            <AlertDialogAction onClick={handleDelete} className="bg-red-500 hover:bg-red-600">
              删除
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* 批量删除确认对话框 */}
      <AlertDialog open={batchDeleteOpen} onOpenChange={setBatchDeleteOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>确认批量删除</AlertDialogTitle>
            <AlertDialogDescription>
              确定要删除选中的 {selectedIds.size} 个文件吗？此操作不可撤销，且文章中使用这些图片的链接将失效。
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={batchDeleting}>取消</AlertDialogCancel>
            <AlertDialogAction 
              onClick={handleBatchDelete} 
              className="bg-red-500 hover:bg-red-600"
              disabled={batchDeleting}
            >
              {batchDeleting ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  删除中...
                </>
              ) : (
                `删除 ${selectedIds.size} 个文件`
              )}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
