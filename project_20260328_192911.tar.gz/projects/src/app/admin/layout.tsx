import { redirect } from 'next/navigation';
import { getCurrentUser } from '@/lib/auth';
import { AdminSidebar } from './components/AdminSidebar';
import { getSupabaseClient } from '@/storage/database/supabase-client';

async function getSiteName() {
  try {
    const client = getSupabaseClient();
    const { data } = await client
      .from('settings')
      .select('value')
      .eq('key', 'site_name')
      .single();
    return data?.value || '我的博客';
  } catch {
    return '我的博客';
  }
}

export default async function AdminLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const user = await getCurrentUser();
  
  if (user && user.role !== 'admin' && user.role !== 'editor') {
    redirect('/');
  }
  
  // 未登录用户显示简单布局（用于登录页）
  if (!user) {
    return (
      <div className="min-h-screen bg-gray-100 dark:bg-gray-900">
        {/* 隐藏前台 header 和 footer */}
        <style dangerouslySetInnerHTML={{ __html: `
          body > header, body > footer { display: none !important; }
          body > main { padding: 0 !important; max-width: none !important; margin: 0 !important; }
        `}} />
        {children}
      </div>
    );
  }
  
  const siteName = await getSiteName();
  
  // 已登录用户显示带侧边栏的布局
  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      {/* 隐藏前台 header 和 footer */}
      <style dangerouslySetInnerHTML={{ __html: `
        body > header, body > footer { display: none !important; }
        body > main { padding: 0 !important; max-width: none !important; margin: 0 !important; }
      `}} />
      
      {/* 固定侧边栏 */}
      <AdminSidebar user={user} siteName={siteName} />
      
      {/* 主内容区 - 左侧留出侧边栏宽度 */}
      <main className="ml-64 min-h-screen">
        {children}
      </main>
    </div>
  );
}
