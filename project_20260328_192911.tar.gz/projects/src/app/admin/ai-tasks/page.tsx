'use client';

import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogFooter,
} from '@/components/ui/dialog';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import { Badge } from '@/components/ui/badge';
import { Checkbox } from '@/components/ui/checkbox';
import {
  Clock,
  Play,
  Pause,
  Plus,
  Trash2,
  RefreshCw,
  Loader2,
  Settings,
  FileText,
  CheckCircle,
  XCircle,
  Calendar,
  Hash,
} from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

interface Category {
  id: string;
  name: string;
}

interface Tag {
  id: string;
  name: string;
  slug: string;
}

interface TaskLog {
  id: string;
  post_id: string | null;
  title: string | null;
  status: string;
  error_message: string | null;
  execution_time: number | null;
  created_at: string;
}

interface AITask {
  id: string;
  name: string;
  article_type: string;
  writing_style: string;
  article_length: number;
  publish_interval: number;
  status: string;
  category_id: string | null;
  category_name: string | null;
  tags: string[];
  last_run_at: string | null;
  next_run_at: string | null;
  total_published: number;
  created_at: string;
  recent_logs: TaskLog[];
  execute_hour: number | null;
  execute_minute: number;
}

const ARTICLE_TYPES = [
  { value: '水果', label: '水果种植' },
  { value: '花草种植', label: '花草种植' },
  { value: '蔬菜种植', label: '蔬菜种植' },
  { value: '园艺技术', label: '园艺技术' },
];

const WRITING_STYLES = [
  { value: 'professional', label: '专业严谨' },
  { value: 'casual', label: '轻松活泼' },
  { value: 'tutorial', label: '教程指南' },
  { value: 'storytelling', label: '故事叙述' },
];

const PUBLISH_INTERVALS = [
  { value: '1', label: '每小时' },
  { value: '6', label: '每6小时' },
  { value: '12', label: '每12小时' },
  { value: '24', label: '每天' },
  { value: '48', label: '每2天' },
  { value: '72', label: '每3天' },
  { value: '168', label: '每周' },
];

export default function AITasksPage() {
  const [tasks, setTasks] = useState<AITask[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [tags, setTags] = useState<Tag[]>([]);
  const [loading, setLoading] = useState(true);
  const [createDialogOpen, setCreateDialogOpen] = useState(false);
  const [editDialogOpen, setEditDialogOpen] = useState(false);
  const [logDialogOpen, setLogDialogOpen] = useState(false);
  const [selectedTask, setSelectedTask] = useState<AITask | null>(null);
  const [selectedLogs, setSelectedLogs] = useState<TaskLog[]>([]);
  const [saving, setSaving] = useState(false);
  const [executing, setExecuting] = useState<string | null>(null);
  
  // 批量选择
  const [selectMode, setSelectMode] = useState(false);
  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set());
  const [batchDeleteOpen, setBatchDeleteOpen] = useState(false);
  const [batchDeleting, setBatchDeleting] = useState(false);
  
  const { toast } = useToast();

  const [formData, setFormData] = useState({
    name: '',
    article_type: '水果',
    writing_style: 'professional',
    article_length: 1500,
    publish_interval: 24,
    category_id: '',
    tag_ids: [] as string[],
    use_custom_time: false,
    execute_hour: 10,
    execute_minute: 0,
  });

  useEffect(() => {
    fetchTasks();
    fetchCategories();
    fetchTags();
  }, []);

  const fetchTasks = async () => {
    setLoading(true);
    try {
      const response = await fetch('/api/ai-tasks');
      const data = await response.json();
      setTasks(data.tasks || []);
    } catch (error) {
      console.error('Failed to fetch tasks:', error);
    } finally {
      setLoading(false);
    }
  };

  const fetchCategories = async () => {
    try {
      const response = await fetch('/api/categories');
      const data = await response.json();
      setCategories(data.categories || []);
    } catch (error) {
      console.error('Failed to fetch categories:', error);
    }
  };

  const fetchTags = async () => {
    try {
      const response = await fetch('/api/tags');
      const data = await response.json();
      setTags(data.tags || []);
    } catch (error) {
      console.error('Failed to fetch tags:', error);
    }
  };

  const handleCreate = async () => {
    if (!formData.name.trim()) {
      toast({ title: '请输入任务名称', variant: 'destructive' });
      return;
    }

    setSaving(true);
    try {
      const response = await fetch('/api/ai-tasks', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: formData.name,
          article_type: formData.article_type,
          writing_style: formData.writing_style,
          article_length: formData.article_length,
          publish_interval: formData.publish_interval,
          category_id: formData.category_id || null,
          tags: formData.tag_ids,
          execute_hour: formData.use_custom_time ? formData.execute_hour : null,
          execute_minute: formData.use_custom_time ? formData.execute_minute : 0,
        }),
      });

      if (response.ok) {
        toast({ title: '任务创建成功' });
        setCreateDialogOpen(false);
        resetForm();
        fetchTasks();
      } else {
        throw new Error('创建失败');
      }
    } catch (error) {
      toast({ title: '创建失败', variant: 'destructive' });
    } finally {
      setSaving(false);
    }
  };

  const handleEdit = async () => {
    if (!selectedTask || !formData.name.trim()) return;

    setSaving(true);
    try {
      const response = await fetch(`/api/ai-tasks/${selectedTask.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: formData.name,
          article_type: formData.article_type,
          writing_style: formData.writing_style,
          article_length: formData.article_length,
          publish_interval: formData.publish_interval,
          category_id: formData.category_id || null,
          tags: formData.tag_ids,
          execute_hour: formData.use_custom_time ? formData.execute_hour : null,
          execute_minute: formData.use_custom_time ? formData.execute_minute : 0,
        }),
      });

      if (response.ok) {
        toast({ title: '任务更新成功' });
        setEditDialogOpen(false);
        resetForm();
        fetchTasks();
      } else {
        throw new Error('更新失败');
      }
    } catch (error) {
      toast({ title: '更新失败', variant: 'destructive' });
    } finally {
      setSaving(false);
    }
  };

  const handleToggleStatus = async (task: AITask) => {
    const action = task.status === 'active' ? 'pause' : 'resume';
    try {
      const response = await fetch(`/api/ai-tasks/${task.id}/action`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action }),
      });

      if (response.ok) {
        toast({ 
          title: action === 'pause' ? '任务已暂停' : '任务已恢复' 
        });
        fetchTasks();
      }
    } catch (error) {
      toast({ title: '操作失败', variant: 'destructive' });
    }
  };

  const handleExecute = async (task: AITask) => {
    setExecuting(task.id);
    try {
      const response = await fetch(`/api/ai-tasks/${task.id}/action`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'execute' }),
      });

      const result = await response.json();
      
      if (result.success) {
        toast({ 
          title: '任务已在后台执行',
          description: result.message || '文章生成中，请稍后查看执行日志',
        });
        // 延迟刷新任务列表，等待后台执行
        setTimeout(() => fetchTasks(), 3000);
      } else {
        throw new Error(result.error || '执行失败');
      }
    } catch (error) {
      toast({ 
        title: '执行失败', 
        description: error instanceof Error ? error.message : '请稍后重试',
        variant: 'destructive' 
      });
    } finally {
      setExecuting(null);
    }
  };

  const handleDelete = async (id: string) => {
    if (!confirm('确定要删除此任务吗？')) return;

    try {
      const response = await fetch(`/api/ai-tasks/${id}`, {
        method: 'DELETE',
      });

      if (response.ok) {
        toast({ title: '删除成功' });
        fetchTasks();
      }
    } catch (error) {
      toast({ title: '删除失败', variant: 'destructive' });
    }
  };

  const handleBatchDelete = async () => {
    if (selectedIds.size === 0) return;

    setBatchDeleting(true);
    try {
      const response = await fetch('/api/ai-tasks', {
        method: 'DELETE',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ids: Array.from(selectedIds) }),
      });

      if (response.ok) {
        toast({ title: `已删除 ${selectedIds.size} 个任务` });
        setSelectedIds(new Set());
        setSelectMode(false);
        fetchTasks();
      }
    } catch (error) {
      toast({ title: '批量删除失败', variant: 'destructive' });
    } finally {
      setBatchDeleting(false);
      setBatchDeleteOpen(false);
    }
  };

  const openEditDialog = (task: AITask) => {
    setSelectedTask(task);
    setFormData({
      name: task.name,
      article_type: task.article_type,
      writing_style: task.writing_style,
      article_length: task.article_length,
      publish_interval: task.publish_interval,
      category_id: task.category_id || '',
      tag_ids: task.tags || [],
      use_custom_time: task.execute_hour !== null,
      execute_hour: task.execute_hour || 10,
      execute_minute: task.execute_minute || 0,
    });
    setEditDialogOpen(true);
  };

  const openLogDialog = (task: AITask) => {
    setSelectedTask(task);
    setSelectedLogs(task.recent_logs || []);
    setLogDialogOpen(true);
  };

  const resetForm = () => {
    setFormData({
      name: '',
      article_type: '水果',
      writing_style: 'professional',
      article_length: 1500,
      publish_interval: 24,
      category_id: '',
      tag_ids: [],
      use_custom_time: false,
      execute_hour: 10,
      execute_minute: 0,
    });
    setSelectedTask(null);
  };

  const toggleTag = (tagId: string) => {
    setFormData((prev) => ({
      ...prev,
      tag_ids: prev.tag_ids.includes(tagId)
        ? prev.tag_ids.filter((id) => id !== tagId)
        : [...prev.tag_ids, tagId],
    }));
  };

  const toggleSelect = (id: string) => {
    const newSelected = new Set(selectedIds);
    if (newSelected.has(id)) {
      newSelected.delete(id);
    } else {
      newSelected.add(id);
    }
    setSelectedIds(newSelected);
  };

  const toggleSelectAll = () => {
    if (selectedIds.size === tasks.length) {
      setSelectedIds(new Set());
    } else {
      setSelectedIds(new Set(tasks.map((t) => t.id)));
    }
  };

  const formatDate = (dateStr: string | null) => {
    if (!dateStr) return '-';
    return new Date(dateStr).toLocaleString('zh-CN', {
      month: '2-digit',
      day: '2-digit',
      hour: '2-digit',
      minute: '2-digit',
    });
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'active':
        return <Badge className="bg-green-500">运行中</Badge>;
      case 'paused':
        return <Badge variant="secondary">已暂停</Badge>;
      default:
        return <Badge variant="outline">{status}</Badge>;
    }
  };

  return (
    <div className="p-6">
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-gray-900 dark:text-white flex items-center gap-2">
          <Clock className="w-6 h-6 text-[#0ea5e9]" />
          AI 自动任务
        </h1>
        <p className="text-gray-500 dark:text-gray-400 mt-1">
          配置AI定时写作任务，自动生成并发布文章
        </p>
      </div>

      {/* 操作栏 */}
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-2">
          {selectMode ? (
            <>
              <Button variant="outline" size="sm" onClick={toggleSelectAll}>
                {selectedIds.size === tasks.length ? '取消全选' : '全选'}
              </Button>
              <Button
                variant="destructive"
                size="sm"
                onClick={() => setBatchDeleteOpen(true)}
                disabled={selectedIds.size === 0}
              >
                <Trash2 className="w-4 h-4 mr-1" />
                删除 ({selectedIds.size})
              </Button>
              <Button variant="ghost" size="sm" onClick={() => { setSelectMode(false); setSelectedIds(new Set()); }}>
                取消
              </Button>
            </>
          ) : (
            <>
              <Button variant="outline" size="sm" onClick={() => setSelectMode(true)}>
                批量选择
              </Button>
              <Button variant="ghost" size="sm" onClick={fetchTasks}>
                <RefreshCw className="w-4 h-4" />
              </Button>
            </>
          )}
        </div>
        
        <Dialog open={createDialogOpen} onOpenChange={setCreateDialogOpen}>
          <DialogTrigger asChild>
            <Button onClick={() => resetForm()}>
              <Plus className="w-4 h-4 mr-2" />
              创建任务
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-md">
            <DialogHeader>
              <DialogTitle>创建AI自动任务</DialogTitle>
            </DialogHeader>
            <div className="space-y-4 py-4">
              <div className="space-y-2">
                <Label>任务名称</Label>
                <Input
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  placeholder="例如：每日水果种植文章"
                />
              </div>

              <div className="space-y-2">
                <Label>文章类型</Label>
                <Select
                  value={formData.article_type}
                  onValueChange={(v) => setFormData({ ...formData, article_type: v })}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {ARTICLE_TYPES.map((type) => (
                      <SelectItem key={type.value} value={type.value}>
                        {type.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>写作风格</Label>
                  <Select
                    value={formData.writing_style}
                    onValueChange={(v) => setFormData({ ...formData, writing_style: v })}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {WRITING_STYLES.map((style) => (
                        <SelectItem key={style.value} value={style.value}>
                          {style.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label>文章长度</Label>
                  <Select
                    value={formData.article_length.toString()}
                    onValueChange={(v) => setFormData({ ...formData, article_length: parseInt(v) })}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="800">短文 (~800字)</SelectItem>
                      <SelectItem value="1500">标准 (~1500字)</SelectItem>
                      <SelectItem value="2000">长文 (~2000字)</SelectItem>
                      <SelectItem value="3000">深度 (~3000字)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="space-y-2">
                <Label>发布频率</Label>
                <Select
                  value={formData.publish_interval.toString()}
                  onValueChange={(v) => setFormData({ ...formData, publish_interval: parseInt(v) })}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {PUBLISH_INTERVALS.map((interval) => (
                      <SelectItem key={interval.value} value={interval.value}>
                        {interval.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              {/* 自定义执行时间 */}
              <div className="space-y-3 p-3 bg-gray-50 dark:bg-gray-800/50 rounded-lg">
                <div className="flex items-center justify-between">
                  <Label className="cursor-pointer">指定执行时间</Label>
                  <input
                    type="checkbox"
                    checked={formData.use_custom_time}
                    onChange={(e) => setFormData({ ...formData, use_custom_time: e.target.checked })}
                    className="w-4 h-4 rounded border-gray-300"
                  />
                </div>
                {formData.use_custom_time && (
                  <div className="grid grid-cols-2 gap-4 pt-2">
                    <div className="space-y-2">
                      <Label className="text-xs text-gray-500">小时 (0-23)</Label>
                      <Input
                        type="number"
                        min="0"
                        max="23"
                        value={formData.execute_hour}
                        onChange={(e) => setFormData({ 
                          ...formData, 
                          execute_hour: Math.min(23, Math.max(0, parseInt(e.target.value) || 0))
                        })}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label className="text-xs text-gray-500">分钟 (0-59)</Label>
                      <Input
                        type="number"
                        min="0"
                        max="59"
                        value={formData.execute_minute}
                        onChange={(e) => setFormData({ 
                          ...formData, 
                          execute_minute: Math.min(59, Math.max(0, parseInt(e.target.value) || 0))
                        })}
                      />
                    </div>
                  </div>
                )}
                <p className="text-xs text-gray-500">
                  {formData.use_custom_time 
                    ? `将在每天 ${String(formData.execute_hour).padStart(2, '0')}:${String(formData.execute_minute).padStart(2, '0')} 执行`
                    : '启用后将按指定时间点执行（如每天10:00）'
                }
                </p>
              </div>

              <div className="space-y-2">
                <Label>分类（可选）</Label>
                <Select
                  value={formData.category_id || 'none'}
                  onValueChange={(v) => setFormData({ ...formData, category_id: v === 'none' ? '' : v })}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="选择分类" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="none">无分类</SelectItem>
                    {categories.map((cat) => (
                      <SelectItem key={cat.id} value={cat.id}>
                        {cat.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label>标签（可选）</Label>
                <div className="flex flex-wrap gap-2 p-3 border dark:border-gray-700 rounded-lg max-h-32 overflow-y-auto">
                  {tags.map((tag) => (
                    <button
                      key={tag.id}
                      type="button"
                      onClick={() => toggleTag(tag.id)}
                      className={`inline-flex items-center gap-1 px-2 py-1 rounded-full text-xs font-medium transition-colors ${
                        formData.tag_ids.includes(tag.id)
                          ? 'bg-[#0ea5e9] text-white'
                          : 'bg-gray-100 dark:bg-gray-700 text-gray-600 dark:text-gray-300 hover:bg-gray-200'
                      }`}
                    >
                      <Hash className="w-3 h-3" />
                      {tag.name}
                    </button>
                  ))}
                </div>
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setCreateDialogOpen(false)}>
                取消
              </Button>
              <Button onClick={handleCreate} disabled={saving}>
                {saving ? '创建中...' : '创建任务'}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>

      {/* 任务列表 */}
      {loading ? (
        <div className="flex items-center justify-center py-12">
          <Loader2 className="w-8 h-8 animate-spin text-[#0ea5e9]" />
        </div>
      ) : tasks.length === 0 ? (
        <Card>
          <CardContent className="py-12 text-center">
            <Clock className="w-12 h-12 mx-auto mb-4 text-gray-300" />
            <p className="text-gray-500">暂无AI任务</p>
            <p className="text-sm text-gray-400 mt-1">点击"创建任务"开始配置自动写作</p>
          </CardContent>
        </Card>
      ) : (
        <div className="grid gap-4">
          {tasks.map((task) => {
            const isSelected = selectedIds.has(task.id);
            return (
              <Card key={task.id} className={isSelected ? 'ring-2 ring-[#0ea5e9]' : ''}>
                <CardContent className="p-4">
                  <div className="flex items-start gap-4">
                    {selectMode && (
                      <Checkbox
                        checked={isSelected}
                        onCheckedChange={() => toggleSelect(task.id)}
                        className="mt-1"
                      />
                    )}
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-2">
                        <h3 className="font-semibold text-lg truncate">{task.name}</h3>
                        {getStatusBadge(task.status)}
                      </div>
                      
                      <div className="flex flex-wrap gap-4 text-sm text-gray-500">
                        <span className="flex items-center gap-1">
                          <FileText className="w-4 h-4" />
                          {ARTICLE_TYPES.find(t => t.value === task.article_type)?.label || task.article_type}
                        </span>
                        <span className="flex items-center gap-1">
                          <Settings className="w-4 h-4" />
                          {WRITING_STYLES.find(s => s.value === task.writing_style)?.label}
                        </span>
                        <span className="flex items-center gap-1">
                          <Clock className="w-4 h-4" />
                          {task.execute_hour !== null 
                            ? `每天 ${String(task.execute_hour).padStart(2, '0')}:${String(task.execute_minute || 0).padStart(2, '0')}`
                            : `每${task.publish_interval}小时`
                          }
                        </span>
                        {task.category_name && (
                          <span className="flex items-center gap-1">
                            分类: {task.category_name}
                          </span>
                        )}
                      </div>

                      <div className="flex flex-wrap gap-4 text-sm text-gray-500 mt-2">
                        <span>已发布: {task.total_published} 篇</span>
                        <span>上次执行: {formatDate(task.last_run_at)}</span>
                        <span>下次执行: {formatDate(task.next_run_at)}</span>
                      </div>
                    </div>

                    {!selectMode && (
                      <div className="flex items-center gap-2">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => openLogDialog(task)}
                        >
                          <Calendar className="w-4 h-4 mr-1" />
                          日志
                        </Button>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => handleToggleStatus(task)}
                        >
                          {task.status === 'active' ? (
                            <>
                              <Pause className="w-4 h-4 mr-1" />
                              暂停
                            </>
                          ) : (
                            <>
                              <Play className="w-4 h-4 mr-1" />
                              恢复
                            </>
                          )}
                        </Button>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => handleExecute(task)}
                          disabled={executing === task.id}
                        >
                          {executing === task.id ? (
                            <>
                              <Loader2 className="w-4 h-4 mr-1 animate-spin" />
                              执行中
                            </>
                          ) : (
                            <>
                              <Play className="w-4 h-4 mr-1" />
                              立即执行
                            </>
                          )}
                        </Button>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => openEditDialog(task)}
                        >
                          <Settings className="w-4 h-4" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="sm"
                          className="text-red-500 hover:text-red-600"
                          onClick={() => handleDelete(task.id)}
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      )}

      {/* 编辑对话框 */}
      <Dialog open={editDialogOpen} onOpenChange={setEditDialogOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>编辑任务</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label>任务名称</Label>
              <Input
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
              />
            </div>

            <div className="space-y-2">
              <Label>文章类型</Label>
              <Select
                value={formData.article_type}
                onValueChange={(v) => setFormData({ ...formData, article_type: v })}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {ARTICLE_TYPES.map((type) => (
                    <SelectItem key={type.value} value={type.value}>
                      {type.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>写作风格</Label>
                <Select
                  value={formData.writing_style}
                  onValueChange={(v) => setFormData({ ...formData, writing_style: v })}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {WRITING_STYLES.map((style) => (
                      <SelectItem key={style.value} value={style.value}>
                        {style.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label>文章长度</Label>
                <Select
                  value={formData.article_length.toString()}
                  onValueChange={(v) => setFormData({ ...formData, article_length: parseInt(v) })}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="800">短文 (~800字)</SelectItem>
                    <SelectItem value="1500">标准 (~1500字)</SelectItem>
                    <SelectItem value="2000">长文 (~2000字)</SelectItem>
                    <SelectItem value="3000">深度 (~3000字)</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="space-y-2">
              <Label>发布频率</Label>
              <Select
                value={formData.publish_interval.toString()}
                onValueChange={(v) => setFormData({ ...formData, publish_interval: parseInt(v) })}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {PUBLISH_INTERVALS.map((interval) => (
                    <SelectItem key={interval.value} value={interval.value}>
                      {interval.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {/* 自定义执行时间 */}
            <div className="space-y-3 p-3 bg-gray-50 dark:bg-gray-800/50 rounded-lg">
              <div className="flex items-center justify-between">
                <Label className="cursor-pointer">指定执行时间</Label>
                <input
                  type="checkbox"
                  checked={formData.use_custom_time}
                  onChange={(e) => setFormData({ ...formData, use_custom_time: e.target.checked })}
                  className="w-4 h-4 rounded border-gray-300"
                />
              </div>
              {formData.use_custom_time && (
                <div className="grid grid-cols-2 gap-4 pt-2">
                  <div className="space-y-2">
                    <Label className="text-xs text-gray-500">小时 (0-23)</Label>
                    <Input
                      type="number"
                      min="0"
                      max="23"
                      value={formData.execute_hour}
                      onChange={(e) => setFormData({ 
                        ...formData, 
                        execute_hour: Math.min(23, Math.max(0, parseInt(e.target.value) || 0))
                      })}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label className="text-xs text-gray-500">分钟 (0-59)</Label>
                    <Input
                      type="number"
                      min="0"
                      max="59"
                      value={formData.execute_minute}
                      onChange={(e) => setFormData({ 
                        ...formData, 
                        execute_minute: Math.min(59, Math.max(0, parseInt(e.target.value) || 0))
                      })}
                    />
                  </div>
                </div>
              )}
              <p className="text-xs text-gray-500">
                {formData.use_custom_time 
                  ? `将在每天 ${String(formData.execute_hour).padStart(2, '0')}:${String(formData.execute_minute).padStart(2, '0')} 执行`
                  : '启用后将按指定时间点执行（如每天10:00）'
              }
              </p>
            </div>

            <div className="space-y-2">
              <Label>分类（可选）</Label>
              <Select
                value={formData.category_id || 'none'}
                onValueChange={(v) => setFormData({ ...formData, category_id: v === 'none' ? '' : v })}
              >
                <SelectTrigger>
                  <SelectValue placeholder="选择分类" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="none">无分类</SelectItem>
                  {categories.map((cat) => (
                    <SelectItem key={cat.id} value={cat.id}>
                      {cat.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setEditDialogOpen(false)}>
              取消
            </Button>
            <Button onClick={handleEdit} disabled={saving}>
              {saving ? '保存中...' : '保存'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* 日志对话框 */}
      <Dialog open={logDialogOpen} onOpenChange={setLogDialogOpen}>
        <DialogContent className="max-w-2xl max-h-[80vh]">
          <DialogHeader>
            <DialogTitle>执行日志 - {selectedTask?.name}</DialogTitle>
          </DialogHeader>
          <div className="overflow-y-auto max-h-[60vh]">
            {selectedLogs.length === 0 ? (
              <div className="text-center py-8 text-gray-500">
                暂无执行记录
              </div>
            ) : (
              <div className="space-y-3">
                {selectedLogs.map((log) => (
                  <div
                    key={log.id}
                    className="flex items-center gap-3 p-3 bg-gray-50 dark:bg-gray-800 rounded-lg"
                  >
                    <div className="flex-shrink-0">
                      {log.status === 'success' ? (
                        <CheckCircle className="w-5 h-5 text-green-500" />
                      ) : (
                        <XCircle className="w-5 h-5 text-red-500" />
                      )}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2">
                        <span className="font-medium truncate">
                          {log.title || '文章生成失败'}
                        </span>
                        <Badge variant={log.status === 'success' ? 'default' : 'destructive'} className="text-xs">
                          {log.status === 'success' ? '成功' : '失败'}
                        </Badge>
                      </div>
                      <div className="text-xs text-gray-500 mt-1">
                        {formatDate(log.created_at)}
                        {log.execution_time && ` · 耗时 ${log.execution_time}秒`}
                      </div>
                      {log.error_message && (
                        <div className="text-xs text-red-500 mt-1">
                          {log.error_message}
                        </div>
                      )}
                    </div>
                    {log.post_id && (
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => window.open(`/admin/posts/${log.post_id}`, '_blank')}
                      >
                        查看
                      </Button>
                    )}
                  </div>
                ))}
              </div>
            )}
          </div>
        </DialogContent>
      </Dialog>

      {/* 批量删除确认 */}
      <AlertDialog open={batchDeleteOpen} onOpenChange={setBatchDeleteOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>确认删除</AlertDialogTitle>
            <AlertDialogDescription>
              确定要删除选中的 {selectedIds.size} 个任务吗？此操作不可撤销。
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={batchDeleting}>取消</AlertDialogCancel>
            <AlertDialogAction
              onClick={handleBatchDelete}
              className="bg-red-500 hover:bg-red-600"
              disabled={batchDeleting}
            >
              {batchDeleting ? '删除中...' : '删除'}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
