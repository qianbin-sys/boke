'use client';

import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { 
  FileText, 
  Users, 
  FolderTree, 
  MessageSquare, 
  ArrowRight, 
  Eye, 
  DollarSign,
  Crown,
  ShoppingCart,
  TrendingUp,
  Clock,
} from 'lucide-react';
import Link from 'next/link';

interface DashboardStats {
  overview: {
    totalPosts: number;
    publishedPosts: number;
    draftPosts: number;
    totalViews: number;
    totalUsers: number;
    totalCategories: number;
    totalTags: number;
    totalOrders: number;
    totalRevenue: string;
    activeMembers: number;
    totalComments: number;
    pendingComments: number;
  };
  chart: {
    last7Days: Array<{ date: string; count: number }>;
  };
  recentPosts: Array<{
    id: string;
    title: string;
    slug: string;
    status: string;
    view_count: number;
    created_at: string;
    categories: { name: string } | null;
  }>;
  recentOrders: Array<{
    id: string;
    order_no: string;
    amount: string;
    payment_status: string;
    created_at: string;
    users: { username: string; display_name: string } | null;
  }>;
}

export default function AdminDashboard() {
  const [stats, setStats] = useState<DashboardStats | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchStats();
  }, []);

  const fetchStats = async () => {
    try {
      const response = await fetch('/api/dashboard/stats');
      const data = await response.json();
      setStats(data);
    } catch (error) {
      console.error('Failed to fetch stats:', error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="p-6">
        <div className="animate-pulse space-y-4">
          <div className="h-8 w-48 bg-gray-200 dark:bg-gray-700 rounded"></div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {[...Array(8)].map((_, i) => (
              <div key={i} className="h-24 bg-gray-200 dark:bg-gray-700 rounded-lg"></div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  const statCards = [
    { title: '文章总数', value: stats?.overview.totalPosts || 0, icon: FileText, color: 'bg-blue-500', href: '/admin/posts' },
    { title: '总阅读量', value: stats?.overview.totalViews || 0, icon: Eye, color: 'bg-cyan-500', href: '/admin/posts' },
    { title: '用户总数', value: stats?.overview.totalUsers || 0, icon: Users, color: 'bg-green-500', href: '/admin/users' },
    { title: '活跃会员', value: stats?.overview.activeMembers || 0, icon: Crown, color: 'bg-amber-500', href: '/admin/membership/users' },
    { title: '总订单数', value: stats?.overview.totalOrders || 0, icon: ShoppingCart, color: 'bg-purple-500', href: '#' },
    { title: '总收入', value: `¥${stats?.overview.totalRevenue || '0'}`, icon: DollarSign, color: 'bg-emerald-500', href: '#' },
    { title: '待审评论', value: stats?.overview.pendingComments || 0, icon: MessageSquare, color: 'bg-orange-500', href: '/admin/comments' },
    { title: '分类/标签', value: `${stats?.overview.totalCategories || 0}/${stats?.overview.totalTags || 0}`, icon: FolderTree, color: 'bg-pink-500', href: '/admin/categories' },
  ];

  const maxCount = Math.max(...(stats?.chart.last7Days.map(d => d.count) || [1]), 1);

  return (
    <div className="p-6">
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-gray-900 dark:text-white">仪表盘</h1>
        <p className="text-gray-500 dark:text-gray-400 mt-1">网站运营数据概览</p>
      </div>
      
      {/* 统计卡片 */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
        {statCards.map((card) => {
          const Icon = card.icon;
          return (
            <Link key={card.title} href={card.href}>
              <Card className="hover:shadow-md transition-shadow cursor-pointer">
                <CardContent className="p-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-gray-500 dark:text-gray-400">{card.title}</p>
                      <p className="text-2xl font-bold mt-1">{card.value}</p>
                    </div>
                    <div className={`${card.color} p-3 rounded-lg`}>
                      <Icon className="h-5 w-5 text-white" />
                    </div>
                  </div>
                </CardContent>
              </Card>
            </Link>
          );
        })}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* 发布趋势 */}
        <Card className="lg:col-span-2">
          <CardHeader className="pb-3">
            <CardTitle className="text-lg flex items-center gap-2">
              <TrendingUp className="w-5 h-5 text-[#0ea5e9]" />
              最近7天发布趋势
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-end justify-between h-40 gap-2">
              {stats?.chart.last7Days.map((day, index) => (
                <div key={index} className="flex-1 flex flex-col items-center">
                  <div className="w-full bg-gray-100 dark:bg-gray-800 rounded-t-lg relative" style={{ height: '100%' }}>
                    <div
                      className="absolute bottom-0 w-full bg-gradient-to-t from-[#0ea5e9] to-[#06b6d4] rounded-t-lg transition-all"
                      style={{ height: `${(day.count / maxCount) * 100}%` }}
                    ></div>
                  </div>
                  <div className="mt-2 text-center">
                    <p className="text-xs text-gray-500">{day.date.split('/')[1]}日</p>
                    <p className="text-sm font-medium">{day.count}</p>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* 快捷操作 */}
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-lg">快捷操作</CardTitle>
          </CardHeader>
          <CardContent className="space-y-2">
            <Link
              href="/admin/posts/new"
              className="flex items-center justify-between p-3 rounded-lg bg-blue-50 dark:bg-blue-900/20 hover:bg-blue-100 dark:hover:bg-blue-900/30 transition-colors group"
            >
              <div>
                <div className="font-medium text-blue-700 dark:text-blue-300">撰写新文章</div>
                <div className="text-sm text-gray-500 dark:text-gray-400">创建一篇新的博客文章</div>
              </div>
              <ArrowRight className="h-4 w-4 text-blue-500 opacity-0 group-hover:opacity-100 transition-opacity" />
            </Link>
            <Link
              href="/admin/categories"
              className="flex items-center justify-between p-3 rounded-lg bg-purple-50 dark:bg-purple-900/20 hover:bg-purple-100 dark:hover:bg-purple-900/30 transition-colors group"
            >
              <div>
                <div className="font-medium text-purple-700 dark:text-purple-300">管理分类</div>
                <div className="text-sm text-gray-500 dark:text-gray-400">添加或编辑文章分类</div>
              </div>
              <ArrowRight className="h-4 w-4 text-purple-500 opacity-0 group-hover:opacity-100 transition-opacity" />
            </Link>
            <Link
              href="/admin/tags"
              className="flex items-center justify-between p-3 rounded-lg bg-pink-50 dark:bg-pink-900/20 hover:bg-pink-100 dark:hover:bg-pink-900/30 transition-colors group"
            >
              <div>
                <div className="font-medium text-pink-700 dark:text-pink-300">管理标签</div>
                <div className="text-sm text-gray-500 dark:text-gray-400">添加或编辑文章标签</div>
              </div>
              <ArrowRight className="h-4 w-4 text-pink-500 opacity-0 group-hover:opacity-100 transition-opacity" />
            </Link>
            <Link
              href="/admin/users"
              className="flex items-center justify-between p-3 rounded-lg bg-green-50 dark:bg-green-900/20 hover:bg-green-100 dark:hover:bg-green-900/30 transition-colors group"
            >
              <div>
                <div className="font-medium text-green-700 dark:text-green-300">用户管理</div>
                <div className="text-sm text-gray-500 dark:text-gray-400">管理用户账户和权限</div>
              </div>
              <ArrowRight className="h-4 w-4 text-green-500 opacity-0 group-hover:opacity-100 transition-opacity" />
            </Link>
          </CardContent>
        </Card>
      </div>

      {/* 最近文章和订单 */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mt-6">
        {/* 最近文章 */}
        <Card>
          <CardHeader className="pb-3">
            <div className="flex items-center justify-between">
              <CardTitle className="text-lg flex items-center gap-2">
                <FileText className="w-5 h-5 text-[#0ea5e9]" />
                最近文章
              </CardTitle>
              <Link href="/admin/posts" className="text-sm text-[#0ea5e9] hover:underline">
                查看全部
              </Link>
            </div>
          </CardHeader>
          <CardContent>
            {stats?.recentPosts.length === 0 ? (
              <p className="text-center text-gray-500 py-4">暂无文章</p>
            ) : (
              <div className="space-y-3">
                {stats?.recentPosts.map((post) => (
                  <Link
                    key={post.id}
                    href={`/admin/posts/${post.id}`}
                    className="flex items-center justify-between p-3 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-800 transition-colors"
                  >
                    <div className="min-w-0">
                      <p className="font-medium truncate">{post.title}</p>
                      <div className="flex items-center gap-2 mt-1">
                        {post.categories && (
                          <span className="text-xs text-[#0ea5e9]">{post.categories.name}</span>
                        )}
                        <span className={`text-xs px-1.5 py-0.5 rounded ${
                          post.status === 'published' 
                            ? 'bg-green-100 text-green-600' 
                            : 'bg-gray-100 text-gray-600'
                        }`}>
                          {post.status === 'published' ? '已发布' : '草稿'}
                        </span>
                      </div>
                    </div>
                    <div className="flex items-center gap-3 text-sm text-gray-500">
                      <span className="flex items-center gap-1">
                        <Eye className="w-3 h-3" />
                        {post.view_count}
                      </span>
                    </div>
                  </Link>
                ))}
              </div>
            )}
          </CardContent>
        </Card>

        {/* 最近订单 */}
        <Card>
          <CardHeader className="pb-3">
            <div className="flex items-center justify-between">
              <CardTitle className="text-lg flex items-center gap-2">
                <ShoppingCart className="w-5 h-5 text-[#0ea5e9]" />
                最近订单
              </CardTitle>
              <Link href="/admin/orders" className="text-sm text-[#0ea5e9] hover:underline">
                查看全部
              </Link>
            </div>
          </CardHeader>
          <CardContent>
            {stats?.recentOrders.length === 0 ? (
              <p className="text-center text-gray-500 py-4">暂无订单</p>
            ) : (
              <div className="space-y-3">
                {stats?.recentOrders.map((order) => (
                  <div
                    key={order.id}
                    className="flex items-center justify-between p-3 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-800 transition-colors"
                  >
                    <div className="min-w-0">
                      <p className="font-medium">¥{order.amount}</p>
                      <div className="flex items-center gap-2 mt-1 text-xs text-gray-500">
                        <span>{order.users?.display_name || order.users?.username || '未知用户'}</span>
                        <span className={`px-1.5 py-0.5 rounded ${
                          order.payment_status === 'paid' 
                            ? 'bg-green-100 text-green-600' 
                            : 'bg-amber-100 text-amber-600'
                        }`}>
                          {order.payment_status === 'paid' ? '已支付' : '待支付'}
                        </span>
                      </div>
                    </div>
                    <div className="flex items-center gap-1 text-sm text-gray-500">
                      <Clock className="w-3 h-3" />
                      {new Date(order.created_at).toLocaleDateString('zh-CN')}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
