'use client';

import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Alert, AlertDescription } from '@/components/ui/alert';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Crown, Search, UserPlus, Clock, CheckCircle, XCircle } from 'lucide-react';

interface UserMembership {
  id: string;
  user_id: string;
  plan_id: string;
  status: string;
  started_at: string;
  expired_at: string;
  created_at: string;
  users: {
    id: string;
    username: string;
    email: string;
    display_name: string;
  };
  membership_plans: {
    id: string;
    name: string;
    slug: string;
    price: string;
    duration_days: number;
  };
}

interface Plan {
  id: string;
  name: string;
  slug: string;
  is_active?: boolean;
}

export default function UserMembershipsPage() {
  const [memberships, setMemberships] = useState<UserMembership[]>([]);
  const [plans, setPlans] = useState<Plan[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  
  // 对话框状态
  const [dialogOpen, setDialogOpen] = useState(false);
  const [formData, setFormData] = useState({
    user_id: '',
    plan_id: '',
    duration_days: '',
  });

  useEffect(() => {
    fetchMemberships();
    fetchPlans();
  }, []);

  const fetchMemberships = async () => {
    setLoading(true);
    try {
      let url = '/api/user-memberships?';
      if (statusFilter && statusFilter !== 'all') url += `status=${statusFilter}`;
      
      const response = await fetch(url);
      const data = await response.json();
      setMemberships(data.memberships || []);
    } catch (error) {
      console.error('Failed to fetch memberships:', error);
      setError('获取会员列表失败');
    } finally {
      setLoading(false);
    }
  };

  const fetchPlans = async () => {
    try {
      const response = await fetch('/api/membership-plans');
      const data = await response.json();
      setPlans(data.plans || []);
    } catch (error) {
      console.error('Failed to fetch plans:', error);
    }
  };

  const handleCreateMembership = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    try {
      const response = await fetch('/api/user-memberships', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          user_id: formData.user_id,
          plan_id: formData.plan_id,
          duration_days: formData.duration_days ? parseInt(formData.duration_days) : undefined,
        }),
      });

      const data = await response.json();

      if (!response.ok) {
        setError(data.error || '创建失败');
        return;
      }

      setDialogOpen(false);
      setFormData({ user_id: '', plan_id: '', duration_days: '' });
      fetchMemberships();
    } catch (error) {
      console.error('Create error:', error);
      setError('网络错误，请稍后重试');
    }
  };

  const getStatusBadge = (status: string) => {
    const styles = {
      active: 'bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-400',
      expired: 'bg-gray-100 text-gray-700 dark:bg-gray-800 dark:text-gray-400',
      cancelled: 'bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-400',
    };
    const labels = {
      active: '有效',
      expired: '已过期',
      cancelled: '已取消',
    };
    return (
      <span className={`inline-flex items-center gap-1 px-2 py-1 rounded-full text-xs font-medium ${styles[status as keyof typeof styles] || styles.expired}`}>
        {status === 'active' && <CheckCircle className="h-3 w-3" />}
        {status === 'expired' && <Clock className="h-3 w-3" />}
        {status === 'cancelled' && <XCircle className="h-3 w-3" />}
        {labels[status as keyof typeof labels] || status}
      </span>
    );
  };

  const getDurationText = (days: number) => {
    if (days === 0) return '永久';
    if (days === 30) return '1个月';
    if (days === 365) return '1年';
    return `${days}天`;
  };

  const filteredMemberships = memberships.filter(m => {
    if (!searchQuery) return true;
    const query = searchQuery.toLowerCase();
    return (
      m.users?.username?.toLowerCase().includes(query) ||
      m.users?.email?.toLowerCase().includes(query) ||
      m.users?.display_name?.toLowerCase().includes(query)
    );
  });

  return (
    <div className="p-6">
      <div className="max-w-6xl mx-auto">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h1 className="text-2xl font-bold text-gray-900 dark:text-white">会员用户管理</h1>
            <p className="text-gray-500 dark:text-gray-400 mt-1">管理网站的会员用户</p>
          </div>
          <Button onClick={() => setDialogOpen(true)}>
            <UserPlus className="h-4 w-4 mr-2" />
            开通会员
          </Button>
        </div>

        <Card className="mb-6">
          <CardContent className="pt-6">
            <div className="flex gap-4">
              <div className="flex-1 relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                <Input
                  placeholder="搜索用户名、邮箱..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-10"
                />
              </div>
              <Select value={statusFilter} onValueChange={(value) => {
                setStatusFilter(value);
                fetchMemberships();
              }}>
                <SelectTrigger className="w-40">
                  <SelectValue placeholder="状态筛选" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">全部状态</SelectItem>
                  <SelectItem value="active">有效</SelectItem>
                  <SelectItem value="expired">已过期</SelectItem>
                  <SelectItem value="cancelled">已取消</SelectItem>
                </SelectContent>
              </Select>
              <Button variant="outline" onClick={fetchMemberships}>
                刷新
              </Button>
            </div>
          </CardContent>
        </Card>

        {error && (
          <Alert variant="destructive" className="mb-6">
            <AlertDescription>{error}</AlertDescription>
          </Alert>
        )}

        {loading ? (
          <div className="text-center py-12 text-gray-500">加载中...</div>
        ) : filteredMemberships.length === 0 ? (
          <Card>
            <CardContent className="py-12 text-center">
              <Crown className="h-12 w-12 mx-auto text-gray-400 mb-4" />
              <p className="text-gray-500 mb-2">暂无会员用户</p>
              <p className="text-sm text-gray-400">点击"开通会员"按钮手动添加会员</p>
            </CardContent>
          </Card>
        ) : (
          <div className="space-y-4">
            {filteredMemberships.map((membership) => (
              <Card key={membership.id}>
                <CardContent className="p-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-4">
                      <div className="w-12 h-12 bg-gradient-to-br from-[#0ea5e9] to-[#06b6d4] rounded-full flex items-center justify-center">
                        <span className="text-white text-lg font-medium">
                          {(membership.users?.display_name || membership.users?.username || '?')[0]}
                        </span>
                      </div>
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="font-medium text-gray-900 dark:text-white">
                            {membership.users?.display_name || membership.users?.username}
                          </span>
                          {getStatusBadge(membership.status)}
                        </div>
                        <p className="text-sm text-gray-500">{membership.users?.email}</p>
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="flex items-center gap-2">
                        <Crown className="h-4 w-4 text-amber-500" />
                        <span className="font-medium">{membership.membership_plans?.name}</span>
                      </div>
                      <p className="text-sm text-gray-500">
                        {membership.expired_at 
                          ? `到期: ${new Date(membership.expired_at).toLocaleDateString('zh-CN')}`
                          : '永久有效'}
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}

        {/* 开通会员对话框 */}
        <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
          <DialogContent>
            <form onSubmit={handleCreateMembership}>
              <DialogHeader>
                <DialogTitle>开通会员</DialogTitle>
                <DialogDescription>
                  为用户手动开通会员权限
                </DialogDescription>
              </DialogHeader>
              <div className="grid gap-4 py-4">
                <div className="space-y-2">
                  <Label htmlFor="user_id">用户ID</Label>
                  <Input
                    id="user_id"
                    value={formData.user_id}
                    onChange={(e) => setFormData({ ...formData, user_id: e.target.value })}
                    placeholder="输入用户ID"
                    required
                  />
                  <p className="text-xs text-gray-500">可在用户管理中查看用户ID</p>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="plan_id">会员套餐</Label>
                  <Select
                    value={formData.plan_id}
                    onValueChange={(value) => setFormData({ ...formData, plan_id: value })}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="选择套餐" />
                    </SelectTrigger>
                    <SelectContent>
                      {plans.filter(p => p.is_active !== false).map((plan) => (
                        <SelectItem key={plan.id} value={plan.id}>
                          {plan.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="duration_days">自定义天数（可选）</Label>
                  <Input
                    id="duration_days"
                    type="number"
                    value={formData.duration_days}
                    onChange={(e) => setFormData({ ...formData, duration_days: e.target.value })}
                    placeholder="留空使用套餐默认天数"
                  />
                </div>
              </div>
              <DialogFooter>
                <Button type="button" variant="outline" onClick={() => setDialogOpen(false)}>
                  取消
                </Button>
                <Button type="submit">确认开通</Button>
              </DialogFooter>
            </form>
          </DialogContent>
        </Dialog>
      </div>
    </div>
  );
}
