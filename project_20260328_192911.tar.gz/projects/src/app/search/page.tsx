'use client';

import { useState, useEffect } from 'react';
import { useRouter, useSearchParams } from 'next/navigation';
import Link from 'next/link';
import { Search, ChevronRight, Loader2, Hash } from 'lucide-react';

interface Post {
  id: string;
  title: string;
  slug: string;
  excerpt: string | null;
  featured_image: string | null;
  view_count: number;
  published_at: string | null;
  created_at: string;
  categories: { id: string; name: string; slug: string } | null;
  tags: { id: string; name: string; slug: string }[];
}

export default function SearchPage() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const queryFromUrl = searchParams.get('q') || '';
  
  const [query, setQuery] = useState(queryFromUrl);
  const [posts, setPosts] = useState<Post[]>([]);
  const [loading, setLoading] = useState(false);
  const [searched, setSearched] = useState(false);
  const [total, setTotal] = useState(0);

  useEffect(() => {
    if (queryFromUrl) {
      performSearch(queryFromUrl);
    }
  }, [queryFromUrl]);

  const performSearch = async (searchQuery: string) => {
    if (!searchQuery.trim()) return;
    
    setLoading(true);
    setSearched(true);
    
    try {
      const response = await fetch(`/api/search?q=${encodeURIComponent(searchQuery)}`);
      const data = await response.json();
      
      setPosts(data.posts || []);
      setTotal(data.total || 0);
    } catch (error) {
      console.error('Search error:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!query.trim()) return;
    
    router.push(`/search?q=${encodeURIComponent(query)}`);
    performSearch(query);
  };

  return (
    <div className="max-w-4xl mx-auto">
      {/* Header */}
      <div className="mb-8">
        <nav className="flex items-center gap-2 text-sm text-[#64748b] dark:text-[#94a3b8] mb-4">
          <Link href="/" className="hover:text-[#0ea5e9] transition-colors">首页</Link>
          <ChevronRight className="w-4 h-4" />
          <span className="text-[#1e293b] dark:text-white">搜索</span>
        </nav>
        <h1 className="text-3xl font-bold text-[#1e293b] dark:text-white mb-2">
          搜索文章
        </h1>
      </div>

      {/* Search Form */}
      <form onSubmit={handleSubmit} className="mb-8">
        <div className="relative">
          <input
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="输入关键词搜索文章..."
            className="w-full h-14 pl-12 pr-4 text-lg bg-white dark:bg-[#1e293b] border border-[#e2e8f0] dark:border-[#334155] rounded-xl focus:outline-none focus:border-[#0ea5e9] focus:ring-2 focus:ring-[#0ea5e9]/20 transition-all"
          />
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-[#64748b]" />
          <button
            type="submit"
            className="absolute right-2 top-1/2 -translate-y-1/2 px-4 py-2 bg-[#0ea5e9] text-white rounded-lg hover:bg-[#0284c7] transition-colors"
          >
            搜索
          </button>
        </div>
      </form>

      {/* Results */}
      {loading ? (
        <div className="flex items-center justify-center py-16">
          <Loader2 className="w-8 h-8 animate-spin text-[#0ea5e9]" />
        </div>
      ) : searched ? (
        <>
          {queryFromUrl && (
            <p className="text-sm text-[#64748b] dark:text-[#94a3b8] mb-6">
              找到 <span className="font-semibold text-[#1e293b] dark:text-white">{total}</span> 篇与 "<span className="font-semibold text-[#1e293b] dark:text-white">{queryFromUrl}</span>" 相关的文章
            </p>
          )}

          {posts.length === 0 ? (
            <div className="text-center py-16 bg-white dark:bg-[#1e293b] rounded-xl border border-[#e2e8f0] dark:border-[#334155]">
              <Search className="w-12 h-12 mx-auto text-gray-400 mb-4" />
              <p className="text-gray-500 dark:text-gray-400">未找到相关文章</p>
              <p className="text-sm text-gray-400 mt-2">请尝试其他关键词</p>
            </div>
          ) : (
            <div className="space-y-4">
              {posts.map((post) => (
                <Link
                  key={post.id}
                  href={`/post/${post.slug}`}
                  className="block bg-white dark:bg-[#1e293b] border border-[#e2e8f0] dark:border-[#334155] rounded-xl overflow-hidden hover:border-[#0ea5e9]/50 hover:shadow-lg transition-all"
                >
                  <div className="flex gap-4 p-4">
                    {post.featured_image ? (
                      <div className="w-32 h-24 flex-shrink-0 rounded-lg overflow-hidden">
                        <img
                          src={post.featured_image}
                          alt={post.title}
                          className="w-full h-full object-cover"
                        />
                      </div>
                    ) : (
                      <div className="w-32 h-24 flex-shrink-0 rounded-lg bg-gradient-to-br from-[#f1f5f9] to-[#e2e8f0] dark:from-[#334155] dark:to-[#1e293b] flex items-center justify-center">
                        <svg className="w-8 h-8 text-gray-300" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1} d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" />
                        </svg>
                      </div>
                    )}
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-1">
                        {post.categories && (
                          <span className="text-xs text-[#0ea5e9] font-medium">
                            {post.categories.name}
                          </span>
                        )}
                        <span className="text-xs text-[#94a3b8]">
                          {new Date(post.published_at || post.created_at).toLocaleDateString('zh-CN')}
                        </span>
                      </div>
                      <h2 className="text-lg font-semibold text-[#1e293b] dark:text-white hover:text-[#0ea5e9] transition-colors line-clamp-1 mb-2">
                        {post.title}
                      </h2>
                      <p className="text-sm text-[#64748b] dark:text-[#94a3b8] line-clamp-2">
                        {post.excerpt || '暂无摘要'}
                      </p>
                      {post.tags && post.tags.length > 0 && (
                        <div className="flex flex-wrap gap-1 mt-2">
                          {post.tags.slice(0, 3).map((tag) => (
                            <span
                              key={tag.id}
                              className="inline-flex items-center gap-0.5 text-xs px-2 py-0.5 bg-gray-100 dark:bg-gray-800 text-gray-500 dark:text-gray-400 rounded"
                            >
                              <Hash className="w-2.5 h-2.5" />
                              {tag.name}
                            </span>
                          ))}
                        </div>
                      )}
                    </div>
                  </div>
                </Link>
              ))}
            </div>
          )}
        </>
      ) : (
        <div className="text-center py-16 bg-white dark:bg-[#1e293b] rounded-xl border border-[#e2e8f0] dark:border-[#334155]">
          <Search className="w-12 h-12 mx-auto text-gray-400 mb-4" />
          <p className="text-gray-500 dark:text-gray-400">输入关键词搜索文章</p>
        </div>
      )}
    </div>
  );
}
