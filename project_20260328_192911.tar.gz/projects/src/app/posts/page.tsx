import { getSupabaseClient } from '@/storage/database/supabase-client';
import Link from 'next/link';
import { ChevronRight, Search } from 'lucide-react';

interface Props {
  searchParams: Promise<{ page?: string; category?: string; tag?: string }>;
}

interface PostCategory {
  id: string;
  name: string;
  slug: string;
}

interface PostTag {
  id: string;
  name: string;
  slug: string;
}

interface Post {
  id: string;
  title: string;
  slug: string;
  excerpt: string | null;
  featured_image: string | null;
  view_count: number;
  published_at: string | null;
  created_at: string;
  categories: PostCategory | null;
  users: {
    id: string;
    username: string;
    display_name: string | null;
  } | null;
  tags?: PostTag[];
}

async function getPosts(page: number = 1, category?: string): Promise<{ posts: Post[]; total: number; totalPages: number }> {
  const client = getSupabaseClient();
  const pageSize = 12;

  let query = client
    .from('posts')
    .select(`
      id,
      title,
      slug,
      excerpt,
      featured_image,
      view_count,
      published_at,
      created_at,
      categories(id, name, slug),
      users!posts_author_id_users_id_fk(id, username, display_name),
      post_tags(
        id,
        tags(id, name, slug)
      )
    `, { count: 'exact' })
    .eq('status', 'published')
    .order('published_at', { ascending: false })
    .range((page - 1) * pageSize, page * pageSize - 1);

  if (category) {
    // 通过分类slug筛选
    const { data: cat } = await client
      .from('categories')
      .select('id')
      .eq('slug', category)
      .maybeSingle();
    
    if (cat) {
      query = query.eq('category_id', cat.id);
    }
  }

  const { data: posts, error, count } = await query;

  if (error) {
    console.error('Failed to fetch posts:', error);
    return { posts: [], total: 0, totalPages: 0 };
  }

  // 格式化标签
  const formattedPosts: Post[] = (posts || []).map(post => ({
    ...post,
    categories: Array.isArray(post.categories) ? post.categories[0] || null : post.categories,
    users: Array.isArray(post.users) ? post.users[0] || null : post.users,
    tags: (post.post_tags || []).map((pt: any) => pt.tags).filter(Boolean),
  }));

  return {
    posts: formattedPosts,
    total: count || 0,
    totalPages: Math.ceil((count || 0) / pageSize),
  };
}

async function getCategories() {
  const client = getSupabaseClient();
  
  const { data, error } = await client
    .from('categories')
    .select(`
      id,
      name,
      slug,
      posts(count)
    `)
    .order('sort_order', { ascending: true });

  if (error) {
    console.error('Failed to fetch categories:', error);
    return [];
  }

  return (data || []).map(cat => ({
    id: cat.id,
    name: cat.name,
    slug: cat.slug,
    post_count: (cat.posts as any[])?.length || 0,
  }));
}

export default async function PostsPage({ searchParams }: Props) {
  const { page, category } = await searchParams;
  const currentPage = parseInt(page || '1');
  
  const [{ posts, total, totalPages }, categories] = await Promise.all([
    getPosts(currentPage, category),
    getCategories(),
  ]);

  const currentCategory = category 
    ? categories.find(c => c.slug === category) 
    : null;

  return (
    <div className="max-w-6xl mx-auto">
      {/* Header */}
      <div className="mb-8">
        <nav className="flex items-center gap-2 text-sm text-[#64748b] dark:text-[#94a3b8] mb-4">
          <Link href="/" className="hover:text-[#0ea5e9] transition-colors">首页</Link>
          {currentCategory && (
            <>
              <ChevronRight className="w-4 h-4" />
              <span className="text-[#1e293b] dark:text-white">{currentCategory.name}</span>
            </>
          )}
          {!currentCategory && (
            <>
              <ChevronRight className="w-4 h-4" />
              <span className="text-[#1e293b] dark:text-white">全部文章</span>
            </>
          )}
        </nav>
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-[#1e293b] dark:text-white mb-2">
              {currentCategory ? currentCategory.name : '全部文章'}
            </h1>
            <p className="text-[#64748b] dark:text-[#94a3b8]">
              共 {total} 篇文章
            </p>
          </div>
          {/* Search */}
          <Link
            href="/search"
            className="flex items-center gap-2 px-4 py-2 bg-white dark:bg-[#1e293b] border border-[#e2e8f0] dark:border-[#334155] rounded-lg hover:border-[#0ea5e9] transition-colors"
          >
            <Search className="w-4 h-4 text-[#64748b]" />
            <span className="text-sm text-[#64748b]">搜索</span>
          </Link>
        </div>
      </div>

      <div className="flex gap-8">
        {/* Sidebar - Categories */}
        <aside className="w-48 flex-shrink-0">
          <div className="sticky top-20">
            <h3 className="text-sm font-semibold text-[#64748b] dark:text-[#94a3b8] mb-3">分类筛选</h3>
            <div className="space-y-1">
              <Link
                href="/posts"
                className={`block px-3 py-2 rounded-lg text-sm transition-colors ${
                  !category 
                    ? 'bg-[#0ea5e9] text-white' 
                    : 'text-[#64748b] dark:text-[#94a3b8] hover:bg-gray-100 dark:hover:bg-gray-800'
                }`}
              >
                全部
              </Link>
              {categories.map((cat) => (
                <Link
                  key={cat.id}
                  href={`/posts?category=${cat.slug}`}
                  className={`block px-3 py-2 rounded-lg text-sm transition-colors ${
                    category === cat.slug 
                      ? 'bg-[#0ea5e9] text-white' 
                      : 'text-[#64748b] dark:text-[#94a3b8] hover:bg-gray-100 dark:hover:bg-gray-800'
                  }`}
                >
                  {cat.name}
                  <span className="ml-2 text-xs opacity-60">({cat.post_count})</span>
                </Link>
              ))}
            </div>

            {/* Tags Link */}
            <div className="mt-6 pt-6 border-t border-[#e2e8f0] dark:border-[#334155]">
              <Link
                href="/tags"
                className="block px-3 py-2 rounded-lg text-sm text-[#64748b] dark:text-[#94a3b8] hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors"
              >
                标签云
              </Link>
            </div>
          </div>
        </aside>

        {/* Main Content */}
        <div className="flex-1">
          {posts.length === 0 ? (
            <div className="text-center py-16 bg-white dark:bg-[#1e293b] rounded-xl border border-[#e2e8f0] dark:border-[#334155]">
              <p className="text-gray-500 dark:text-gray-400">暂无文章</p>
            </div>
          ) : (
            <>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {posts.map((post) => (
                  <Link
                    key={post.id}
                    href={`/post/${post.slug}`}
                    className="group bg-white dark:bg-[#1e293b] border border-[#e2e8f0] dark:border-[#334155] rounded-xl overflow-hidden hover:border-[#0ea5e9]/50 hover:shadow-lg transition-all"
                  >
                    {/* Image */}
                    {post.featured_image ? (
                      <div className="aspect-video overflow-hidden">
                        <img
                          src={post.featured_image}
                          alt={post.title}
                          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                        />
                      </div>
                    ) : (
                      <div className="aspect-video bg-gradient-to-br from-[#f1f5f9] to-[#e2e8f0] dark:from-[#334155] dark:to-[#1e293b] flex items-center justify-center">
                        <svg className="w-12 h-12 text-gray-300 dark:text-gray-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1} d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" />
                        </svg>
                      </div>
                    )}

                    {/* Content */}
                    <div className="p-4">
                      {/* Category & Date */}
                      <div className="flex items-center gap-3 mb-2">
                        {post.categories && (
                          <span className="text-xs text-[#0ea5e9] font-medium">
                            {post.categories.name}
                          </span>
                        )}
                        <span className="text-xs text-[#94a3b8]">
                          {new Date(post.published_at || post.created_at).toLocaleDateString('zh-CN')}
                        </span>
                      </div>

                      {/* Title */}
                      <h2 className="text-base font-semibold text-[#1e293b] dark:text-white group-hover:text-[#0ea5e9] transition-colors line-clamp-2 mb-2">
                        {post.title}
                      </h2>

                      {/* Excerpt */}
                      <p className="text-sm text-[#64748b] dark:text-[#94a3b8] line-clamp-2 mb-3">
                        {post.excerpt || '暂无摘要'}
                      </p>

                      {/* Tags */}
                      {post.tags && post.tags.length > 0 && (
                        <div className="flex flex-wrap gap-1">
                          {post.tags.slice(0, 3).map((tag: any) => (
                            <span
                              key={tag.id}
                              className="text-xs px-2 py-0.5 bg-gray-100 dark:bg-gray-800 text-gray-500 dark:text-gray-400 rounded"
                            >
                              #{tag.name}
                            </span>
                          ))}
                        </div>
                      )}
                    </div>
                  </Link>
                ))}
              </div>

              {/* Pagination */}
              {totalPages > 1 && (
                <div className="flex items-center justify-center gap-2 mt-8">
                  {currentPage > 1 && (
                    <Link
                      href={`/posts?page=${currentPage - 1}${category ? `&category=${category}` : ''}`}
                      className="px-4 py-2 text-sm rounded-lg bg-gray-100 dark:bg-gray-800 text-gray-600 dark:text-gray-400 hover:bg-gray-200 dark:hover:bg-gray-700"
                    >
                      上一页
                    </Link>
                  )}
                  <span className="text-sm text-[#64748b]">
                    第 {currentPage} / {totalPages} 页
                  </span>
                  {currentPage < totalPages && (
                    <Link
                      href={`/posts?page=${currentPage + 1}${category ? `&category=${category}` : ''}`}
                      className="px-4 py-2 text-sm rounded-lg bg-gray-100 dark:bg-gray-800 text-gray-600 dark:text-gray-400 hover:bg-gray-200 dark:hover:bg-gray-700"
                    >
                      下一页
                    </Link>
                  )}
                </div>
              )}
            </>
          )}
        </div>
      </div>
    </div>
  );
}
