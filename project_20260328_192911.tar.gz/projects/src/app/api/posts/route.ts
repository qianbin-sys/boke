import { NextRequest, NextResponse } from 'next/server';
import { getSupabaseClient } from '@/storage/database/supabase-client';
import { getCurrentUser } from '@/lib/auth';

// 获取文章列表
export async function GET(request: NextRequest) {
  try {
    const client = getSupabaseClient();
    const searchParams = request.nextUrl.searchParams;
    
    const page = parseInt(searchParams.get('page') || '1');
    const limit = parseInt(searchParams.get('limit') || '10');
    const status = searchParams.get('status');
    const category_id = searchParams.get('category_id');
    const tag_id = searchParams.get('tag_id');
    const search = searchParams.get('search');
    
    let query = client
      .from('posts')
      .select(`
        *,
        categories(id, name, slug),
        users!posts_author_id_users_id_fk(id, username, display_name),
        post_tags(
          id,
          tags(id, name, slug)
        )
      `, { count: 'exact' })
      .order('created_at', { ascending: false })
      .range((page - 1) * limit, page * limit - 1);
    
    if (status && status !== 'all') {
      query = query.eq('status', status);
    }
    
    if (category_id) {
      query = query.eq('category_id', category_id);
    }

    if (tag_id) {
      // 通过标签筛选文章
      const { data: postIds } = await client
        .from('post_tags')
        .select('post_id')
        .eq('tag_id', tag_id);
      
      if (postIds && postIds.length > 0) {
        const ids = postIds.map(p => p.post_id);
        query = query.in('id', ids);
      } else {
        return NextResponse.json({
          posts: [],
          total: 0,
          page,
          limit,
          totalPages: 0,
        });
      }
    }
    
    if (search) {
      query = query.or(`title.ilike.%${search}%,content.ilike.%${search}%`);
    }
    
    const { data, error, count } = await query;
    
    if (error) {
      return NextResponse.json({ error: error.message }, { status: 500 });
    }

    // 格式化标签数据
    const formattedPosts = (data || []).map(post => ({
      ...post,
      tags: (post.post_tags || []).map((pt: any) => pt.tags).filter(Boolean),
    }));
    
    return NextResponse.json({
      posts: formattedPosts,
      total: count,
      page,
      limit,
      totalPages: Math.ceil((count || 0) / limit),
    });
  } catch (error) {
    console.error('Get posts error:', error);
    return NextResponse.json({ error: '获取文章列表失败' }, { status: 500 });
  }
}

// 创建文章
export async function POST(request: NextRequest) {
  try {
    const user = await getCurrentUser();
    if (!user) {
      return NextResponse.json({ error: '未登录' }, { status: 401 });
    }
    
    const body = await request.json();
    const { 
      title, 
      slug, 
      content, 
      excerpt, 
      category_id, 
      status, 
      featured_image,
      // 付费相关字段
      is_paid,
      price,
      payment_methods,
      free_content,
      // 标签
      tag_ids,
      // SEO字段
      seo_title,
      seo_description,
      seo_keywords,
    } = body;
    
    if (!title || !slug || !content) {
      return NextResponse.json({ error: '标题、别名和内容不能为空' }, { status: 400 });
    }
    
    const client = getSupabaseClient();
    
    // 检查 slug 是否已存在
    const { data: existingPost } = await client
      .from('posts')
      .select('id')
      .eq('slug', slug)
      .maybeSingle();
    
    if (existingPost) {
      return NextResponse.json({ error: '文章别名已存在' }, { status: 400 });
    }
    
    const { data, error } = await client
      .from('posts')
      .insert({
        title,
        slug,
        content,
        excerpt,
        category_id,
        status: status || 'draft',
        featured_image,
        author_id: user.userId,
        published_at: status === 'published' ? new Date().toISOString() : null,
        // 付费字段
        is_paid: is_paid || false,
        price: is_paid ? price : 0,
        payment_methods: is_paid ? payment_methods : [],
        free_content: is_paid ? free_content : null,
        // SEO字段
        seo_title: seo_title || null,
        seo_description: seo_description || null,
        seo_keywords: seo_keywords || null,
      })
      .select()
      .single();
    
    if (error) {
      return NextResponse.json({ error: error.message }, { status: 500 });
    }

    // 添加标签关联
    if (tag_ids && tag_ids.length > 0) {
      const tagInserts = tag_ids.map((tagId: string) => ({
        post_id: data.id,
        tag_id: tagId,
      }));
      await client.from('post_tags').insert(tagInserts);
    }
    
    return NextResponse.json({ post: data });
  } catch (error) {
    console.error('Create post error:', error);
    return NextResponse.json({ error: '创建文章失败' }, { status: 500 });
  }
}
