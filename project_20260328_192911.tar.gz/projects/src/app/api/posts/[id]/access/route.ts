import { NextRequest, NextResponse } from 'next/server';
import { getSupabaseClient } from '@/storage/database/supabase-client';
import { getCurrentUser } from '@/lib/auth';

// 检查用户对文章的访问权限
export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const client = getSupabaseClient();

    // 获取文章信息
    const { data: post, error: postError } = await client
      .from('posts')
      .select('id, is_paid, price')
      .eq('id', id)
      .single();

    if (postError || !post) {
      return NextResponse.json({ hasAccess: false });
    }

    // 非付费文章，直接有权限
    if (!post.is_paid || !post.price) {
      return NextResponse.json({ hasAccess: true });
    }

    // 检查用户是否登录
    const user = await getCurrentUser();
    if (!user) {
      return NextResponse.json({ 
        hasAccess: false, 
        reason: 'login_required',
        price: post.price 
      });
    }

    // 检查是否是会员
    const now = new Date().toISOString();
    const { data: membership } = await client
      .from('user_memberships')
      .select('id')
      .eq('user_id', user.userId)
      .eq('status', 'active')
      .or(`expired_at.is.null,expired_at.gt.${now}`)
      .maybeSingle();

    if (membership) {
      return NextResponse.json({ hasAccess: true, reason: 'membership' });
    }

    // 检查是否单独购买过
    const { data: purchase } = await client
      .from('post_purchases')
      .select('id')
      .eq('user_id', user.userId)
      .eq('post_id', id)
      .eq('status', 'completed')
      .maybeSingle();

    if (purchase) {
      return NextResponse.json({ hasAccess: true, reason: 'purchased' });
    }

    // 无权限
    return NextResponse.json({ 
      hasAccess: false, 
      reason: 'payment_required',
      price: post.price 
    });
  } catch (error) {
    console.error('Check access error:', error);
    return NextResponse.json({ hasAccess: false });
  }
}
