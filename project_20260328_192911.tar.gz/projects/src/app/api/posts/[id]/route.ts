import { NextRequest, NextResponse } from 'next/server';
import { getSupabaseClient } from '@/storage/database/supabase-client';
import { getCurrentUser } from '@/lib/auth';

// 获取单篇文章
export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const client = getSupabaseClient();
    
    const { data, error } = await client
      .from('posts')
      .select(`
        *,
        categories(id, name, slug),
        users!posts_author_id_users_id_fk(id, username, display_name),
        post_tags(
          id,
          tags(id, name, slug)
        )
      `)
      .eq('id', id)
      .maybeSingle();
    
    if (error) {
      return NextResponse.json({ error: error.message }, { status: 500 });
    }
    
    if (!data) {
      return NextResponse.json({ error: '文章不存在' }, { status: 404 });
    }
    
    // 格式化标签数据
    const tags = (data.post_tags || []).map((pt: any) => pt.tags).filter(Boolean);
    
    return NextResponse.json({ 
      post: {
        ...data,
        tags,
      }
    });
  } catch (error) {
    console.error('Get post error:', error);
    return NextResponse.json({ error: '获取文章失败' }, { status: 500 });
  }
}

// 更新文章
export async function PUT(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const user = await getCurrentUser();
    if (!user) {
      return NextResponse.json({ error: '未登录' }, { status: 401 });
    }
    
    const { id } = await params;
    const body = await request.json();
    const { 
      title, 
      slug, 
      content, 
      excerpt, 
      category_id, 
      status, 
      featured_image,
      // 付费相关字段
      is_paid,
      price,
      payment_methods,
      free_content,
      // 标签
      tag_ids,
      // SEO字段
      seo_title,
      seo_description,
      seo_keywords,
    } = body;
    
    const client = getSupabaseClient();
    
    // 检查 slug 是否被其他文章占用
    if (slug) {
      const { data: existingPost } = await client
        .from('posts')
        .select('id')
        .eq('slug', slug)
        .neq('id', id)
        .maybeSingle();
      
      if (existingPost) {
        return NextResponse.json({ error: '文章别名已存在' }, { status: 400 });
      }
    }
    
    const updateData: Record<string, unknown> = {
      title,
      slug,
      content,
      excerpt,
      category_id,
      status,
      featured_image,
      updated_at: new Date().toISOString(),
      // 付费字段
      is_paid: is_paid || false,
      price: is_paid ? price : 0,
      payment_methods: is_paid ? payment_methods : [],
      free_content: is_paid ? free_content : null,
      // SEO字段
      seo_title: seo_title || null,
      seo_description: seo_description || null,
      seo_keywords: seo_keywords || null,
    };
    
    // 如果状态改为发布，设置发布时间
    if (status === 'published') {
      const { data: post } = await client
        .from('posts')
        .select('status, published_at')
        .eq('id', id)
        .maybeSingle();
      
      if (post && post.status !== 'published' && !post.published_at) {
        updateData.published_at = new Date().toISOString();
      }
    }
    
    const { data, error } = await client
      .from('posts')
      .update(updateData)
      .eq('id', id)
      .select()
      .single();
    
    if (error) {
      return NextResponse.json({ error: error.message }, { status: 500 });
    }

    // 更新标签关联
    if (tag_ids !== undefined) {
      // 先删除现有关联
      await client
        .from('post_tags')
        .delete()
        .eq('post_id', id);

      // 添加新关联
      if (tag_ids.length > 0) {
        const tagInserts = tag_ids.map((tagId: string) => ({
          post_id: id,
          tag_id: tagId,
        }));
        await client.from('post_tags').insert(tagInserts);
      }
    }
    
    return NextResponse.json({ post: data });
  } catch (error) {
    console.error('Update post error:', error);
    return NextResponse.json({ error: '更新文章失败' }, { status: 500 });
  }
}

// 删除文章
export async function DELETE(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const user = await getCurrentUser();
    if (!user) {
      return NextResponse.json({ error: '未登录' }, { status: 401 });
    }
    
    const { id } = await params;
    const client = getSupabaseClient();
    
    const { error } = await client
      .from('posts')
      .delete()
      .eq('id', id);
    
    if (error) {
      return NextResponse.json({ error: error.message }, { status: 500 });
    }
    
    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('Delete post error:', error);
    return NextResponse.json({ error: '删除文章失败' }, { status: 500 });
  }
}
