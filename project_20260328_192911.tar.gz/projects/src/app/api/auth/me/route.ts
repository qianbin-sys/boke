import { NextResponse } from 'next/server';
import { getCurrentUser } from '@/lib/auth';

// 获取当前登录用户信息
export async function GET() {
  try {
    const user = await getCurrentUser();
    
    if (!user) {
      return NextResponse.json({ error: '未登录' }, { status: 401 });
    }
    
    return NextResponse.json({
      user: {
        userId: user.userId,
        username: user.username,
        email: user.email,
        display_name: user.display_name,
        role: user.role,
      }
    });
  } catch (error) {
    console.error('Get current user error:', error);
    return NextResponse.json({ error: '获取用户信息失败' }, { status: 500 });
  }
}
