import { NextRequest, NextResponse } from 'next/server';
import { getSupabaseClient } from '@/storage/database/supabase-client';
import { verifyPassword, createSessionToken } from '@/lib/auth';

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { username, password } = body;
    
    if (!username || !password) {
      return NextResponse.json(
        { success: false, error: '用户名和密码不能为空' },
        { status: 400 }
      );
    }
    
    const client = getSupabaseClient();
    
    // 查找用户
    const { data: user, error } = await client
      .from('users')
      .select('*')
      .eq('username', username)
      .maybeSingle();
    
    if (error) {
      return NextResponse.json(
        { success: false, error: '数据库查询失败' },
        { status: 500 }
      );
    }
    
    if (!user) {
      return NextResponse.json(
        { success: false, error: '用户不存在' },
        { status: 401 }
      );
    }
    
    // 验证密码
    const isValid = await verifyPassword(password, user.password_hash);
    if (!isValid) {
      return NextResponse.json(
        { success: false, error: '密码错误' },
        { status: 401 }
      );
    }
    
    // 检查用户是否激活
    if (!user.is_active) {
      return NextResponse.json(
        { success: false, error: '账户已被禁用' },
        { status: 401 }
      );
    }
    
    // 创建 Session Token
    const token = await createSessionToken({
      userId: user.id,
      username: user.username,
      role: user.role,
    });
    
    // 创建响应并设置 cookie
    const response = NextResponse.json({ success: true });
    
    response.cookies.set('session', token, {
      httpOnly: true,
      secure: false, // 开发和生产环境都允许 HTTP
      sameSite: 'lax',
      maxAge: 60 * 60 * 24 * 7, // 7 天
      path: '/',
    });
    
    return response;
  } catch (error) {
    console.error('Login error:', error);
    return NextResponse.json(
      { success: false, error: '登录失败，请稍后重试' },
      { status: 500 }
    );
  }
}
