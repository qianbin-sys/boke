import { NextRequest, NextResponse } from 'next/server';
import { getSupabaseClient } from '@/storage/database/supabase-client';
import { hashPassword, createSessionToken } from '@/lib/auth';

// 用户注册
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { username, email, password, display_name } = body;

    // 参数验证
    if (!username || !email || !password) {
      return NextResponse.json(
        { success: false, error: '用户名、邮箱和密码不能为空' },
        { status: 400 }
      );
    }

    // 用户名格式验证
    if (username.length < 3 || username.length > 20) {
      return NextResponse.json(
        { success: false, error: '用户名长度需在3-20个字符之间' },
        { status: 400 }
      );
    }

    if (!/^[a-zA-Z0-9_]+$/.test(username)) {
      return NextResponse.json(
        { success: false, error: '用户名只能包含字母、数字和下划线' },
        { status: 400 }
      );
    }

    // 邮箱格式验证
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
      return NextResponse.json(
        { success: false, error: '邮箱格式不正确' },
        { status: 400 }
      );
    }

    // 密码强度验证
    if (password.length < 6) {
      return NextResponse.json(
        { success: false, error: '密码长度至少6个字符' },
        { status: 400 }
      );
    }

    const client = getSupabaseClient();

    // 检查用户名是否已存在
    const { data: existingUser, error: checkError } = await client
      .from('users')
      .select('id, username, email')
      .or(`username.eq.${username},email.eq.${email}`)
      .maybeSingle();

    if (checkError) {
      console.error('Check user error:', checkError);
      return NextResponse.json(
        { success: false, error: '注册失败，请稍后重试' },
        { status: 500 }
      );
    }

    if (existingUser) {
      if (existingUser.username === username) {
        return NextResponse.json(
          { success: false, error: '用户名已被使用' },
          { status: 400 }
        );
      }
      if (existingUser.email === email) {
        return NextResponse.json(
          { success: false, error: '邮箱已被注册' },
          { status: 400 }
        );
      }
    }

    // 密码加密
    const passwordHash = await hashPassword(password);

    // 创建用户
    const { data: newUser, error: createError } = await client
      .from('users')
      .insert({
        username,
        email,
        password_hash: passwordHash,
        display_name: display_name || username,
        role: 'user',
        is_active: true,
      })
      .select('id, username, email, display_name, role')
      .single();

    if (createError) {
      console.error('Create user error:', createError);
      return NextResponse.json(
        { success: false, error: '注册失败，请稍后重试' },
        { status: 500 }
      );
    }

    // 创建 Session Token
    const token = await createSessionToken({
      userId: newUser.id,
      username: newUser.username,
      role: newUser.role,
    });

    // 创建响应并设置 cookie
    const response = NextResponse.json({
      success: true,
      user: {
        userId: newUser.id,
        username: newUser.username,
        email: newUser.email,
        display_name: newUser.display_name,
      },
    });

    response.cookies.set('session', token, {
      httpOnly: true,
      secure: false,
      sameSite: 'lax',
      maxAge: 60 * 60 * 24 * 7, // 7 天
      path: '/',
    });

    return response;
  } catch (error) {
    console.error('Register error:', error);
    return NextResponse.json(
      { success: false, error: '注册失败，请稍后重试' },
      { status: 500 }
    );
  }
}
