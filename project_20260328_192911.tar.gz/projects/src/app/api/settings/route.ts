import { NextRequest, NextResponse } from 'next/server';
import { getSupabaseClient } from '@/storage/database/supabase-client';
import { getCurrentUser } from '@/lib/auth';

// 获取设置
export async function GET() {
  try {
    const client = getSupabaseClient();
    
    const { data, error } = await client
      .from('settings')
      .select('*');
    
    if (error) {
      return NextResponse.json({ error: error.message }, { status: 500 });
    }
    
    // 转换为键值对对象
    const settings: Record<string, string> = {};
    data?.forEach((item) => {
      settings[item.key] = item.value || '';
    });
    
    return NextResponse.json({ settings });
  } catch (error) {
    console.error('Get settings error:', error);
    return NextResponse.json({ error: '获取设置失败' }, { status: 500 });
  }
}

// 更新设置
export async function POST(request: NextRequest) {
  try {
    const user = await getCurrentUser();
    if (!user || user.role !== 'admin') {
      return NextResponse.json({ error: '权限不足' }, { status: 403 });
    }
    
    const body = await request.json();
    const client = getSupabaseClient();
    
    for (const [key, value] of Object.entries(body)) {
      await client
        .from('settings')
        .upsert(
          { key, value: value as string },
          { onConflict: 'key' }
        );
    }
    
    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('Update settings error:', error);
    return NextResponse.json({ error: '更新设置失败' }, { status: 500 });
  }
}
