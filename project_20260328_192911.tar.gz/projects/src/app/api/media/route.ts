import { NextRequest, NextResponse } from 'next/server';
import { getSupabaseClient } from '@/storage/database/supabase-client';
import { getCurrentUser } from '@/lib/auth';

// 获取媒体文件列表
export async function GET(request: NextRequest) {
  try {
    const user = await getCurrentUser();
    if (!user || user.role !== 'admin') {
      return NextResponse.json({ error: '权限不足' }, { status: 403 });
    }

    const client = getSupabaseClient();
    const searchParams = request.nextUrl.searchParams;
    const page = parseInt(searchParams.get('page') || '1');
    const limit = parseInt(searchParams.get('limit') || '30');
    const type = searchParams.get('type'); // image, video, document, etc.
    const offset = (page - 1) * limit;

    let query = client
      .from('media')
      .select('*', { count: 'exact' })
      .order('created_at', { ascending: false })
      .range(offset, offset + limit - 1);

    if (type && type !== 'all') {
      query = query.like('mime_type', `${type}%`);
    }

    const { data, error, count } = await query;

    if (error) {
      console.error('Get media files error:', error);
      return NextResponse.json({ error: '获取媒体文件失败' }, { status: 500 });
    }

    return NextResponse.json({
      files: data,
      total: count,
      page,
      limit,
    });
  } catch (error) {
    console.error('Get media files error:', error);
    return NextResponse.json({ error: '获取媒体文件失败' }, { status: 500 });
  }
}
