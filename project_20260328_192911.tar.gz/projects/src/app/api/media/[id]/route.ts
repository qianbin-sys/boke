import { NextRequest, NextResponse } from 'next/server';
import { getSupabaseClient } from '@/storage/database/supabase-client';
import { getCurrentUser } from '@/lib/auth';
import { S3Storage } from 'coze-coding-dev-sdk';

// 初始化存储
const storage = new S3Storage({
  endpointUrl: process.env.COZE_BUCKET_ENDPOINT_URL,
  accessKey: '',
  secretKey: '',
  bucketName: process.env.COZE_BUCKET_NAME,
  region: 'cn-beijing',
});

// 获取单个媒体文件
export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const client = getSupabaseClient();

    const { data, error } = await client
      .from('media')
      .select('*')
      .eq('id', id)
      .single();

    if (error) {
      return NextResponse.json({ error: '文件不存在' }, { status: 404 });
    }

    return NextResponse.json({ file: data });
  } catch (error) {
    console.error('Get media file error:', error);
    return NextResponse.json({ error: '获取文件失败' }, { status: 500 });
  }
}

// 删除媒体文件
export async function DELETE(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const user = await getCurrentUser();
    if (!user || user.role !== 'admin') {
      return NextResponse.json({ error: '权限不足' }, { status: 403 });
    }

    const { id } = await params;
    const client = getSupabaseClient();

    // 获取文件信息
    const { data: file, error: fetchError } = await client
      .from('media')
      .select('*')
      .eq('id', id)
      .single();

    if (fetchError || !file) {
      return NextResponse.json({ error: '文件不存在' }, { status: 404 });
    }

    // 删除存储中的文件
    try {
      await storage.deleteFile({ fileKey: file.filename });
    } catch (storageError) {
      console.error('Delete from storage error:', storageError);
      // 继续删除数据库记录
    }

    // 删除数据库记录
    const { error } = await client
      .from('media')
      .delete()
      .eq('id', id);

    if (error) {
      return NextResponse.json({ error: '删除失败' }, { status: 500 });
    }

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('Delete media file error:', error);
    return NextResponse.json({ error: '删除失败' }, { status: 500 });
  }
}
