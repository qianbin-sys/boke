import { NextRequest, NextResponse } from 'next/server';
import { getSupabaseClient } from '@/storage/database/supabase-client';
import { getCurrentUser } from '@/lib/auth';

// 获取用户会员列表（管理端）
export async function GET(request: NextRequest) {
  try {
    const user = await getCurrentUser();
    if (!user || user.role !== 'admin') {
      return NextResponse.json({ error: '权限不足' }, { status: 403 });
    }
    
    const searchParams = request.nextUrl.searchParams;
    const status = searchParams.get('status');
    const page = parseInt(searchParams.get('page') || '1');
    const pageSize = parseInt(searchParams.get('pageSize') || '20');
    
    const client = getSupabaseClient();
    
    let query = client
      .from('user_memberships')
      .select(`
        *,
        users(id, username, email, display_name),
        membership_plans(id, name, slug, price, duration_days)
      `)
      .order('created_at', { ascending: false })
      .range((page - 1) * pageSize, page * pageSize - 1);
    
    if (status) {
      query = query.eq('status', status);
    }
    
    const { data, error } = await query;
    
    if (error) {
      return NextResponse.json({ error: error.message }, { status: 500 });
    }
    
    // 获取总数
    let countQuery = client
      .from('user_memberships')
      .select('id', { count: 'exact', head: true });
    
    if (status) {
      countQuery = countQuery.eq('status', status);
    }
    
    const { count } = await countQuery;
    
    return NextResponse.json({
      memberships: data,
      total: count || 0,
      page,
      pageSize,
    });
  } catch (error) {
    console.error('Get user memberships error:', error);
    return NextResponse.json({ error: '获取用户会员列表失败' }, { status: 500 });
  }
}

// 创建用户会员（管理员手动开通）
export async function POST(request: NextRequest) {
  try {
    const user = await getCurrentUser();
    if (!user || user.role !== 'admin') {
      return NextResponse.json({ error: '权限不足' }, { status: 403 });
    }
    
    const body = await request.json();
    const { user_id, plan_id, duration_days } = body;
    
    if (!user_id || !plan_id) {
      return NextResponse.json({ error: '用户ID和套餐ID不能为空' }, { status: 400 });
    }
    
    const client = getSupabaseClient();
    
    // 获取套餐信息
    const { data: plan, error: planError } = await client
      .from('membership_plans')
      .select('*')
      .eq('id', plan_id)
      .single();
    
    if (planError || !plan) {
      return NextResponse.json({ error: '套餐不存在' }, { status: 400 });
    }
    
    // 计算过期时间
    const days = duration_days || plan.duration_days;
    let expiredAt = null;
    if (days > 0) {
      expiredAt = new Date();
      expiredAt.setDate(expiredAt.getDate() + days);
    }
    
    // 创建会员记录
    const { data, error } = await client
      .from('user_memberships')
      .insert({
        user_id,
        plan_id,
        status: 'active',
        expired_at: expiredAt ? expiredAt.toISOString() : null,
      })
      .select()
      .single();
    
    if (error) {
      return NextResponse.json({ error: error.message }, { status: 500 });
    }
    
    return NextResponse.json({ membership: data });
  } catch (error) {
    console.error('Create user membership error:', error);
    return NextResponse.json({ error: '创建用户会员失败' }, { status: 500 });
  }
}
