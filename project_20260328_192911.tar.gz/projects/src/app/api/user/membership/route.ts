import { NextResponse } from 'next/server';
import { getSupabaseClient } from '@/storage/database/supabase-client';
import { getCurrentUser } from '@/lib/auth';

// 获取当前用户的会员信息
export async function GET() {
  try {
    const user = await getCurrentUser();
    if (!user) {
      return NextResponse.json({ error: '未登录' }, { status: 401 });
    }
    
    const client = getSupabaseClient();
    
    // 获取用户的有效会员信息
    const now = new Date().toISOString();
    
    // 先获取所有会员记录，再在代码中筛选
    const { data: allMemberships, error } = await client
      .from('user_memberships')
      .select(`
        id,
        status,
        started_at,
        expired_at,
        created_at,
        membership_plans(id, name, slug, price, duration_days)
      `)
      .eq('user_id', user.userId)
      .eq('status', 'active')
      .order('created_at', { ascending: false });
    
    if (error) {
      console.error('Membership query error:', error);
      return NextResponse.json({ error: error.message }, { status: 500 });
    }
    
    // 筛选有效会员：expired_at 为 null（永久）或大于当前时间
    const validMemberships = (allMemberships || []).filter(m => 
      !m.expired_at || new Date(m.expired_at) > new Date()
    );
    
    // 检查是否有有效会员
    const hasActiveMembership = validMemberships.length > 0;
    const activeMembership = hasActiveMembership ? validMemberships[0] : null;
    
    // 获取所有可用的会员套餐
    const { data: plans } = await client
      .from('membership_plans')
      .select('*')
      .eq('is_active', true)
      .order('sort_order', { ascending: true });
    
    return NextResponse.json({
      isMember: hasActiveMembership,
      membership: activeMembership,
      plans: plans || [],
    });
  } catch (error) {
    console.error('Get user membership error:', error);
    return NextResponse.json({ error: '获取会员信息失败' }, { status: 500 });
  }
}
