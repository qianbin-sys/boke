import { NextRequest } from 'next/server';
import { LLMClient, Config, HeaderUtils } from 'coze-coding-dev-sdk';
import { getCurrentUser } from '@/lib/auth';
import { generateCoverImage } from '@/lib/generate-cover-image';
import { getModelConfig, createLLMClient } from '@/lib/ai-model-service';

export const maxDuration = 300; // 5分钟超时

export async function POST(request: NextRequest) {
  try {
    const user = await getCurrentUser();
    if (!user || user.role !== 'admin') {
      return new Response(JSON.stringify({ error: '权限不足' }), { 
        status: 403,
        headers: { 'Content-Type': 'application/json' }
      });
    }

    const { prompt, topic, style, length, modelId } = await request.json();

    if (!prompt && !topic) {
      return new Response(JSON.stringify({ error: '请提供写作主题或要求' }), { 
        status: 400,
        headers: { 'Content-Type': 'application/json' }
      });
    }

    const customHeaders = HeaderUtils.extractForwardHeaders(request.headers);

    // 获取模型配置
    const modelConfig = await getModelConfig('llm', modelId);
    
    // 构建系统提示
    const systemPrompt = `你是一位专业的内容创作专家，擅长撰写各类文章。
请根据用户的要求创作文章，注意：
1. 文章标题要吸引人，简洁有力
2. 内容要有深度，逻辑清晰
3. 段落分明，易于阅读
4. 可以适当使用Markdown格式增强可读性
${style ? `5. 写作风格：${style}` : ''}
${length ? `6. 文章长度：约${length}字` : ''}

请直接输出文章内容，第一行为标题（用#标记），然后是正文内容。`;

    const userContent = prompt || `请为我写一篇关于"${topic}"的文章`;

    const messages = [
      { role: 'system' as const, content: systemPrompt },
      { role: 'user' as const, content: userContent }
    ];

    // 创建流式响应
    const encoder = new TextEncoder();
    let fullContent = ''; // 收集完整内容用于生成封面图
    const stream = new ReadableStream({
      async start(controller) {
        try {
          // 使用动态模型配置
          if (modelConfig) {
            const { client, customConfig } = createLLMClient(modelConfig);
            
            if (client) {
              // 使用SDK客户端（豆包默认）
              const llmStream = client.stream(messages, { 
                temperature: 0.8,
                model: modelConfig.model_id,
              });

              for await (const chunk of llmStream) {
                if (chunk.content) {
                  const text = chunk.content.toString();
                  fullContent += text;
                  const data = JSON.stringify({ content: text });
                  controller.enqueue(encoder.encode(`data: ${data}\n\n`));
                }
              }
            } else if (customConfig) {
              // 使用自定义API
              const response = await fetch(`${customConfig.endpoint}/chat/completions`, {
                method: 'POST',
                headers: {
                  'Content-Type': 'application/json',
                  'Authorization': `Bearer ${customConfig.apiKey}`,
                },
                body: JSON.stringify({
                  model: modelConfig.model_id,
                  messages,
                  temperature: 0.8,
                  stream: true,
                }),
              });

              if (!response.ok) {
                throw new Error(`API错误: ${response.status}`);
              }

              const reader = response.body?.getReader();
              if (!reader) {
                throw new Error('无法读取响应流');
              }

              const decoder = new TextDecoder();
              let buffer = '';

              while (true) {
                const { done, value } = await reader.read();
                if (done) break;

                buffer += decoder.decode(value, { stream: true });
                const lines = buffer.split('\n');
                buffer = lines.pop() || '';

                for (const line of lines) {
                  if (line.startsWith('data: ')) {
                    const data = line.slice(6);
                    if (data === '[DONE]') continue;
                    
                    try {
                      const parsed = JSON.parse(data);
                      const content = parsed.choices?.[0]?.delta?.content;
                      if (content) {
                        fullContent += content;
                        const outputData = JSON.stringify({ content });
                        controller.enqueue(encoder.encode(`data: ${outputData}\n\n`));
                      }
                    } catch {
                      // 忽略解析错误
                    }
                  }
                }
              }
            }
          } else {
            // 没有模型配置，使用SDK默认
            const config = new Config();
            const client = new LLMClient(config, customHeaders);
            
            const llmStream = client.stream(messages, { 
              temperature: 0.8,
              model: 'doubao-seed-2-0-pro-260215'
            });

            for await (const chunk of llmStream) {
              if (chunk.content) {
                const text = chunk.content.toString();
                fullContent += text;
                const data = JSON.stringify({ content: text });
                controller.enqueue(encoder.encode(`data: ${data}\n\n`));
              }
            }
          }

          // 文章生成完成，开始生成封面图
          const title = extractTitle(fullContent);
          if (title) {
            const coverResult = await generateCoverImage({
              title,
              content: fullContent,
              userId: user.userId,
              customHeaders,
            });

            if (coverResult.success && coverResult.imageUrl) {
              const coverData = JSON.stringify({ 
                coverImage: coverResult.imageUrl,
                mediaId: coverResult.mediaId,
              });
              controller.enqueue(encoder.encode(`data: ${coverData}\n\n`));
            }
          }

          // 发送结束标记
          controller.enqueue(encoder.encode(`data: ${JSON.stringify({ done: true })}\n\n`));
          controller.close();
        } catch (error) {
          console.error('Stream error:', error);
          const errorData = JSON.stringify({ error: '生成失败，请重试' });
          controller.enqueue(encoder.encode(`data: ${errorData}\n\n`));
          controller.close();
        }
      }
    });

    return new Response(stream, {
      headers: {
        'Content-Type': 'text/event-stream',
        'Cache-Control': 'no-cache',
        'Connection': 'keep-alive',
      },
    });
  } catch (error) {
    console.error('AI write error:', error);
    return new Response(JSON.stringify({ error: 'AI写作失败' }), { 
      status: 500,
      headers: { 'Content-Type': 'application/json' }
    });
  }
}

/**
 * 从Markdown内容中提取标题
 */
function extractTitle(content: string): string | null {
  // 匹配第一个 # 开头的标题
  const match = content.match(/^#\s+(.+?)(?:\n|$)/);
  return match ? match[1].trim() : null;
}
