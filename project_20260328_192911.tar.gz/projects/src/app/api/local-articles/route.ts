import { NextRequest, NextResponse } from 'next/server';
import { getCurrentUser } from '@/lib/auth';
import * as fs from 'fs';
import * as path from 'path';

// 获取文章存储目录
function getArticlesDir(): string {
  const env = process.env.COZE_PROJECT_ENV;
  const workspacePath = process.env.COZE_WORKSPACE_PATH || '/workspace/projects';
  
  if (env === 'PROD') {
    return '/tmp/articles';
  }
  return path.join(workspacePath, 'articles');
}

// 确保目录存在
function ensureDirExists(dir: string): void {
  if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir, { recursive: true });
  }
}

// 清理Markdown格式符号（#和*）
function cleanMarkdown(text: string): string {
  // 移除标题标记 # ## ### 等（行首的#）
  let cleaned = text.replace(/^#{1,6}\s+/gm, '');
  // 移除粗体/斜体标记 **text** 或 *text*
  cleaned = cleaned.replace(/\*{1,2}([^*]+)\*{1,2}/g, '$1');
  // 移除列表标记（行首的 - 或 * 后跟空格）
  cleaned = cleaned.replace(/^[\*\-]\s+/gm, '');
  return cleaned;
}

// 保存文章到txt文件
export async function POST(request: NextRequest) {
  try {
    const user = await getCurrentUser();
    if (!user || user.role !== 'admin') {
      return NextResponse.json({ error: '权限不足' }, { status: 403 });
    }

    const { title, content, filenames, coverImage, mediaId } = await request.json();
    
    // 批量删除模式
    if (filenames && Array.isArray(filenames)) {
      const articlesDir = getArticlesDir();
      let successCount = 0;
      let failCount = 0;
      
      for (const filename of filenames) {
        try {
          const filePath = path.join(articlesDir, filename);
          if (fs.existsSync(filePath)) {
            fs.unlinkSync(filePath);
            successCount++;
          } else {
            failCount++;
          }
        } catch {
          failCount++;
        }
      }
      
      return NextResponse.json({ 
        success: true, 
        deleted: successCount,
        failed: failCount 
      });
    }

    // 单个保存模式
    if (!title || !content) {
      return NextResponse.json({ error: '标题和内容不能为空' }, { status: 400 });
    }

    // 清理Markdown格式符号
    const cleanedContent = cleanMarkdown(content);

    const articlesDir = getArticlesDir();
    ensureDirExists(articlesDir);

    // 生成文件名：时间戳_标题前20字符
    const timestamp = Date.now();
    const safeTitle = title.replace(/[^a-zA-Z0-9\u4e00-\u9fa5]/g, '_').substring(0, 20);
    const filename = `${timestamp}_${safeTitle}.txt`;
    const filePath = path.join(articlesDir, filename);

    // 格式：第一行标题，第二行封面图URL，第三行mediaId，后面是内容
    const fileContent = `${title}\nCOVER:${coverImage || ''}\nMEDIA_ID:${mediaId || ''}\n${cleanedContent}`;
    
    fs.writeFileSync(filePath, fileContent, 'utf-8');

    return NextResponse.json({ 
      success: true, 
      filename,
      path: filePath,
      coverImage,
      mediaId,
    });
  } catch (error) {
    console.error('Save article error:', error);
    return NextResponse.json({ error: '保存失败' }, { status: 500 });
  }
}

// 获取文章列表
export async function GET(request: NextRequest) {
  try {
    const user = await getCurrentUser();
    if (!user || user.role !== 'admin') {
      return NextResponse.json({ error: '权限不足' }, { status: 403 });
    }

    const articlesDir = getArticlesDir();
    
    if (!fs.existsSync(articlesDir)) {
      return NextResponse.json({ articles: [] });
    }

    const files = fs.readdirSync(articlesDir)
      .filter(file => file.endsWith('.txt'))
      .map(file => {
        const filePath = path.join(articlesDir, file);
        const stats = fs.statSync(filePath);
        const content = fs.readFileSync(filePath, 'utf-8');
        const lines = content.split('\n');
        const title = lines[0] || '无标题';
        
        return {
          filename: file,
          title,
          size: stats.size,
          createdAt: stats.birthtime,
          modifiedAt: stats.mtime,
        };
      })
      .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());

    return NextResponse.json({ articles: files });
  } catch (error) {
    console.error('Get articles error:', error);
    return NextResponse.json({ error: '获取文章列表失败' }, { status: 500 });
  }
}
