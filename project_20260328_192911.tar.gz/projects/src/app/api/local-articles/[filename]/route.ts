import { NextRequest, NextResponse } from 'next/server';
import { getCurrentUser } from '@/lib/auth';
import * as fs from 'fs';
import * as path from 'path';

// 获取文章存储目录
function getArticlesDir(): string {
  const env = process.env.COZE_PROJECT_ENV;
  const workspacePath = process.env.COZE_WORKSPACE_PATH || '/workspace/projects';
  
  if (env === 'PROD') {
    return '/tmp/articles';
  }
  return path.join(workspacePath, 'articles');
}

// 获取单个文章内容
export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ filename: string }> }
) {
  try {
    const user = await getCurrentUser();
    if (!user || user.role !== 'admin') {
      return NextResponse.json({ error: '权限不足' }, { status: 403 });
    }

    const { filename } = await params;
    
    // 安全检查：防止路径遍历攻击
    if (filename.includes('..') || filename.includes('/') || filename.includes('\\')) {
      return NextResponse.json({ error: '非法文件名' }, { status: 400 });
    }

    const articlesDir = getArticlesDir();
    const filePath = path.join(articlesDir, filename);

    // 确保文件在指定目录内
    if (!filePath.startsWith(articlesDir)) {
      return NextResponse.json({ error: '非法路径' }, { status: 400 });
    }

    if (!fs.existsSync(filePath)) {
      return NextResponse.json({ error: '文件不存在' }, { status: 404 });
    }

    const content = fs.readFileSync(filePath, 'utf-8');
    const lines = content.split('\n');
    const title = lines[0] || '';
    
    // 解析封面图和媒体ID（新格式）
    let coverImage = '';
    let mediaId = '';
    let contentStartIndex = 1;
    
    if (lines[1]?.startsWith('COVER:')) {
      coverImage = lines[1].substring(6).trim();
      contentStartIndex = 2;
    }
    
    if (lines[2]?.startsWith('MEDIA_ID:')) {
      mediaId = lines[2].substring(9).trim();
      contentStartIndex = 3;
    }
    
    const body = lines.slice(contentStartIndex).join('\n');

    return NextResponse.json({
      filename,
      title,
      content: body,
      coverImage,
      mediaId,
    });
  } catch (error) {
    console.error('Get article error:', error);
    return NextResponse.json({ error: '读取文件失败' }, { status: 500 });
  }
}

// 删除单个文章
export async function DELETE(
  request: NextRequest,
  { params }: { params: Promise<{ filename: string }> }
) {
  try {
    const user = await getCurrentUser();
    if (!user || user.role !== 'admin') {
      return NextResponse.json({ error: '权限不足' }, { status: 403 });
    }

    const { filename } = await params;
    
    // 安全检查
    if (filename.includes('..') || filename.includes('/') || filename.includes('\\')) {
      return NextResponse.json({ error: '非法文件名' }, { status: 400 });
    }

    const articlesDir = getArticlesDir();
    const filePath = path.join(articlesDir, filename);

    if (!filePath.startsWith(articlesDir)) {
      return NextResponse.json({ error: '非法路径' }, { status: 400 });
    }

    if (!fs.existsSync(filePath)) {
      return NextResponse.json({ error: '文件不存在' }, { status: 404 });
    }

    fs.unlinkSync(filePath);

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('Delete article error:', error);
    return NextResponse.json({ error: '删除失败' }, { status: 500 });
  }
}
