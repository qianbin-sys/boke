import { NextRequest, NextResponse } from 'next/server';
import { getSupabaseClient } from '@/storage/database/supabase-client';
import { getCurrentUser } from '@/lib/auth';

// 获取支付配置
export async function GET() {
  try {
    const client = getSupabaseClient();
    
    const { data, error } = await client
      .from('payment_configs')
      .select('*')
      .order('created_at', { ascending: true });
    
    if (error) {
      return NextResponse.json({ error: error.message }, { status: 500 });
    }
    
    return NextResponse.json({ configs: data });
  } catch (error) {
    console.error('Get payment configs error:', error);
    return NextResponse.json({ error: '获取支付配置失败' }, { status: 500 });
  }
}

// 更新支付配置
export async function PUT(request: NextRequest) {
  try {
    const user = await getCurrentUser();
    if (!user || user.role !== 'admin') {
      return NextResponse.json({ error: '权限不足' }, { status: 403 });
    }
    
    const body = await request.json();
    const { id, is_enabled, config, description } = body;
    
    const client = getSupabaseClient();
    
    const { error } = await client
      .from('payment_configs')
      .update({
        is_enabled,
        config,
        description,
        updated_at: new Date().toISOString(),
      })
      .eq('id', id);
    
    if (error) {
      return NextResponse.json({ error: error.message }, { status: 500 });
    }
    
    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('Update payment config error:', error);
    return NextResponse.json({ error: '更新支付配置失败' }, { status: 500 });
  }
}
