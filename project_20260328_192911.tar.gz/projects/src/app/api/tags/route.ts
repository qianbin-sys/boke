import { NextRequest, NextResponse } from 'next/server';
import { getSupabaseClient } from '@/storage/database/supabase-client';
import { getCurrentUser } from '@/lib/auth';

// 获取标签列表
export async function GET(request: NextRequest) {
  try {
    const client = getSupabaseClient();
    const searchParams = request.nextUrl.searchParams;
    const withCount = searchParams.get('withCount') === 'true';

    if (withCount) {
      // 获取标签及其文章数量
      const { data: tags, error } = await client
        .from('tags')
        .select(`
          id,
          name,
          slug,
          created_at,
          post_tags(count)
        `)
        .order('name', { ascending: true });

      if (error) {
        return NextResponse.json({ error: error.message }, { status: 500 });
      }

      // 格式化数据
      const formattedTags = (tags || []).map(tag => ({
        id: tag.id,
        name: tag.name,
        slug: tag.slug,
        created_at: tag.created_at,
        post_count: (tag.post_tags as any[])?.length || 0,
      }));

      return NextResponse.json({ tags: formattedTags });
    } else {
      const { data: tags, error } = await client
        .from('tags')
        .select('id, name, slug, created_at')
        .order('name', { ascending: true });

      if (error) {
        return NextResponse.json({ error: error.message }, { status: 500 });
      }

      return NextResponse.json({ tags });
    }
  } catch (error) {
    console.error('Get tags error:', error);
    return NextResponse.json({ error: '获取标签列表失败' }, { status: 500 });
  }
}

// 创建标签
export async function POST(request: NextRequest) {
  try {
    const user = await getCurrentUser();
    if (!user || user.role !== 'admin') {
      return NextResponse.json({ error: '权限不足' }, { status: 403 });
    }

    const body = await request.json();
    const { name, slug } = body;

    if (!name || !slug) {
      return NextResponse.json({ error: '标签名称和别名不能为空' }, { status: 400 });
    }

    const client = getSupabaseClient();

    // 检查slug是否已存在
    const { data: existingTag } = await client
      .from('tags')
      .select('id')
      .eq('slug', slug)
      .maybeSingle();

    if (existingTag) {
      return NextResponse.json({ error: '标签别名已存在' }, { status: 400 });
    }

    const { data: tag, error } = await client
      .from('tags')
      .insert({ name, slug })
      .select()
      .single();

    if (error) {
      return NextResponse.json({ error: error.message }, { status: 500 });
    }

    return NextResponse.json({ tag });
  } catch (error) {
    console.error('Create tag error:', error);
    return NextResponse.json({ error: '创建标签失败' }, { status: 500 });
  }
}
