import { NextRequest, NextResponse } from 'next/server';
import { getSupabaseClient } from '@/storage/database/supabase-client';
import { getCurrentUser } from '@/lib/auth';

// 获取单个标签
export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const client = getSupabaseClient();

    const { data: tag, error } = await client
      .from('tags')
      .select(`
        id,
        name,
        slug,
        created_at,
        post_tags(count)
      `)
      .eq('id', id)
      .single();

    if (error || !tag) {
      return NextResponse.json({ error: '标签不存在' }, { status: 404 });
    }

    return NextResponse.json({
      tag: {
        ...tag,
        post_count: (tag.post_tags as any[])?.length || 0,
      },
    });
  } catch (error) {
    console.error('Get tag error:', error);
    return NextResponse.json({ error: '获取标签失败' }, { status: 500 });
  }
}

// 更新标签
export async function PUT(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const user = await getCurrentUser();
    if (!user || user.role !== 'admin') {
      return NextResponse.json({ error: '权限不足' }, { status: 403 });
    }

    const { id } = await params;
    const body = await request.json();
    const { name, slug } = body;

    if (!name || !slug) {
      return NextResponse.json({ error: '标签名称和别名不能为空' }, { status: 400 });
    }

    const client = getSupabaseClient();

    // 检查slug是否被其他标签占用
    const { data: existingTag } = await client
      .from('tags')
      .select('id')
      .eq('slug', slug)
      .neq('id', id)
      .maybeSingle();

    if (existingTag) {
      return NextResponse.json({ error: '标签别名已被使用' }, { status: 400 });
    }

    const { data: tag, error } = await client
      .from('tags')
      .update({ name, slug })
      .eq('id', id)
      .select()
      .single();

    if (error) {
      return NextResponse.json({ error: error.message }, { status: 500 });
    }

    return NextResponse.json({ tag });
  } catch (error) {
    console.error('Update tag error:', error);
    return NextResponse.json({ error: '更新标签失败' }, { status: 500 });
  }
}

// 删除标签
export async function DELETE(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const user = await getCurrentUser();
    if (!user || user.role !== 'admin') {
      return NextResponse.json({ error: '权限不足' }, { status: 403 });
    }

    const { id } = await params;
    const client = getSupabaseClient();

    const { error } = await client
      .from('tags')
      .delete()
      .eq('id', id);

    if (error) {
      return NextResponse.json({ error: error.message }, { status: 500 });
    }

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('Delete tag error:', error);
    return NextResponse.json({ error: '删除标签失败' }, { status: 500 });
  }
}
