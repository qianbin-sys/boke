import { NextRequest, NextResponse } from 'next/server';
import { checkAndExecuteTasks } from '@/lib/ai-task-executor';

// 定时检查并执行到期的AI任务
// 可以通过外部cron服务或前端定时调用此接口
export async function GET(request: NextRequest) {
  try {
    // 简单的访问控制：检查是否有特定的cron密钥
    const cronKey = request.headers.get('x-cron-key');
    const expectedKey = process.env.CRON_SECRET_KEY;
    
    // 如果设置了密钥，则验证
    if (expectedKey && cronKey !== expectedKey) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    await checkAndExecuteTasks();
    
    return NextResponse.json({ 
      success: true, 
      message: '任务检查完成',
      timestamp: new Date().toISOString(),
    });
  } catch (error) {
    console.error('Cron check error:', error);
    return NextResponse.json({ 
      error: '任务检查失败',
      message: error instanceof Error ? error.message : '未知错误',
    }, { status: 500 });
  }
}

// 也支持POST请求
export async function POST(request: NextRequest) {
  return GET(request);
}
