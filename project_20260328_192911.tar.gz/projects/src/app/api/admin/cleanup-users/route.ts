import { NextRequest, NextResponse } from 'next/server';
import { getSupabaseClient } from '@/storage/database/supabase-client';
import { getCurrentUser } from '@/lib/auth';

// 清空非管理员用户数据
export async function POST(request: NextRequest) {
  try {
    const user = await getCurrentUser();
    if (!user || user.role !== 'admin') {
      return NextResponse.json({ error: '权限不足，只有管理员可以执行此操作' }, { status: 403 });
    }

    const client = getSupabaseClient();
    const results = {
      deletedUsers: 0,
      deletedOrders: 0,
      deletedMemberships: 0,
      deletedPostPurchases: 0,
      deletedComments: 0,
      errors: [] as string[],
    };

    // 1. 获取所有非管理员用户ID
    const { data: nonAdminUsers, error: usersError } = await client
      .from('users')
      .select('id, username')
      .neq('role', 'admin');

    if (usersError) {
      return NextResponse.json({ error: '查询用户失败: ' + usersError.message }, { status: 500 });
    }

    if (!nonAdminUsers || nonAdminUsers.length === 0) {
      return NextResponse.json({ 
        message: '没有需要清理的非管理员用户',
        results 
      });
    }

    const nonAdminUserIds = nonAdminUsers.map(u => u.id);
    results.deletedUsers = nonAdminUsers.length;

    // 2. 删除订单
    const { error: ordersError } = await client
      .from('orders')
      .delete()
      .in('user_id', nonAdminUserIds);

    if (ordersError) {
      results.errors.push(`删除订单失败: ${ordersError.message}`);
    } else {
      // 统计删除的订单数
      const { count } = await client
        .from('orders')
        .select('*', { count: 'exact', head: true });
      results.deletedOrders = (count || 0);
    }

    // 3. 删除会员记录
    const { error: membershipsError } = await client
      .from('user_memberships')
      .delete()
      .in('user_id', nonAdminUserIds);

    if (membershipsError) {
      results.errors.push(`删除会员记录失败: ${membershipsError.message}`);
    }

    // 4. 删除文章购买记录
    const { error: purchasesError } = await client
      .from('post_purchases')
      .delete()
      .in('user_id', nonAdminUserIds);

    if (purchasesError) {
      results.errors.push(`删除购买记录失败: ${purchasesError.message}`);
    }

    // 5. 删除评论（如果表存在）
    const { error: commentsError } = await client
      .from('comments')
      .delete()
      .in('user_id', nonAdminUserIds);

    if (commentsError && !commentsError.message.includes('does not exist')) {
      results.errors.push(`删除评论失败: ${commentsError.message}`);
    }

    // 6. 最后删除用户
    const { error: deleteUsersError } = await client
      .from('users')
      .delete()
      .in('id', nonAdminUserIds);

    if (deleteUsersError) {
      results.errors.push(`删除用户失败: ${deleteUsersError.message}`);
      results.deletedUsers = 0;
    }

    // 获取管理员列表
    const { data: admins } = await client
      .from('users')
      .select('id, username, email, role')
      .eq('role', 'admin');

    return NextResponse.json({
      success: results.errors.length === 0,
      message: results.errors.length === 0 
        ? `成功清理 ${results.deletedUsers} 个非管理员用户及其相关数据`
        : '清理完成，但有部分错误',
      results: {
        deletedUsers: results.deletedUsers,
        deletedOrders: results.deletedOrders,
        errors: results.errors,
      },
      remainingAdmins: admins || [],
    });
  } catch (error) {
    console.error('Cleanup users error:', error);
    return NextResponse.json({ 
      error: error instanceof Error ? error.message : '清理失败' 
    }, { status: 500 });
  }
}
