import { NextRequest, NextResponse } from 'next/server';
import { getSupabaseClient } from '@/storage/database/supabase-client';
import { getCurrentUser } from '@/lib/auth';

// 生成订单号
function generateOrderNo() {
  const now = new Date();
  const timestamp = now.getTime().toString(36).toUpperCase();
  const random = Math.random().toString(36).substring(2, 8).toUpperCase();
  return `ORD${timestamp}${random}`;
}

// 获取用户订单列表
export async function GET(request: NextRequest) {
  try {
    const user = await getCurrentUser();
    if (!user) {
      return NextResponse.json({ error: '请先登录' }, { status: 401 });
    }

    const searchParams = request.nextUrl.searchParams;
    const status = searchParams.get('status');
    const type = searchParams.get('type'); // 'membership' | 'post' | 'all'
    const page = parseInt(searchParams.get('page') || '1');
    const pageSize = parseInt(searchParams.get('pageSize') || '20');
    const userId = searchParams.get('userId'); // 管理员查看指定用户的订单

    const client = getSupabaseClient();

    // 管理员可以查看指定用户的订单
    const targetUserId = (user.role === 'admin' && userId) ? userId : user.userId;

    console.log('Get orders for user:', { 
      userId: user.userId, 
      targetUserId, 
      role: user.role,
      status,
      type 
    });

    // 简化查询，先不关联其他表
    let query = client
      .from('orders')
      .select('*', { count: 'exact' })
      .eq('user_id', targetUserId)
      .order('created_at', { ascending: false })
      .range((page - 1) * pageSize, page * pageSize - 1);

    if (status) {
      query = query.eq('payment_status', status);
    }

    // 暂时移除可能导致问题的 metadata 查询
    // if (type === 'membership') {
    //   query = query.not('metadata->plan_id', 'is', null);
    // } else if (type === 'post') {
    //   query = query.not('metadata->post_id', 'is', null);
    // }

    const { data, error, count } = await query;

    if (error) {
      console.error('Get orders DB error:', error);
      return NextResponse.json({ error: error.message }, { status: 500 });
    }

    console.log('Orders found:', { count, dataLength: data?.length });

    return NextResponse.json({
      orders: data,
      total: count || 0,
      page,
      pageSize,
    });
  } catch (error) {
    console.error('Get orders error:', error);
    return NextResponse.json({ error: error instanceof Error ? error.message : '获取订单列表失败' }, { status: 500 });
  }
}

// 创建订单
export async function POST(request: NextRequest) {
  try {
    const user = await getCurrentUser();
    if (!user) {
      return NextResponse.json({ error: '请先登录' }, { status: 401 });
    }

    const body = await request.json();
    const { type, plan_id, post_id, payment_method } = body;

    if (!type || !payment_method) {
      return NextResponse.json({ error: '缺少必要参数' }, { status: 400 });
    }

    const client = getSupabaseClient();
    let amount = 0;
    let metadata: Record<string, unknown> = {};

    if (type === 'membership' && plan_id) {
      // 会员套餐订单
      const { data: plan, error: planError } = await client
        .from('membership_plans')
        .select('*')
        .eq('id', plan_id)
        .eq('is_active', true)
        .single();

      if (planError || !plan) {
        return NextResponse.json({ error: '套餐不存在或已下架' }, { status: 400 });
      }

      // 检查用户是否已经是永久会员
      const { data: existingMembership } = await client
        .from('user_memberships')
        .select('id, expired_at')
        .eq('user_id', user.userId)
        .eq('status', 'active')
        .maybeSingle();

      if (existingMembership && existingMembership.expired_at === null) {
        // 已经是永久会员，不允许再购买任何会员套餐
        return NextResponse.json({ error: '您已经是永久会员，无需再次购买' }, { status: 400 });
      }

      amount = parseFloat(plan.price);
      metadata = {
        plan_id: plan.id,
        plan_name: plan.name,
        duration_days: plan.duration_days,
      };
    } else if (type === 'post' && post_id) {
      // 文章购买订单
      const { data: post, error: postError } = await client
        .from('posts')
        .select('id, title, slug, price, is_paid')
        .eq('id', post_id)
        .single();

      if (postError || !post) {
        return NextResponse.json({ error: '文章不存在' }, { status: 400 });
      }

      if (!post.is_paid || !post.price) {
        return NextResponse.json({ error: '该文章无需购买' }, { status: 400 });
      }

      // 检查是否已购买
      const { data: existingPurchase } = await client
        .from('post_purchases')
        .select('id')
        .eq('user_id', user.userId)
        .eq('post_id', post_id)
        .maybeSingle();

      if (existingPurchase) {
        return NextResponse.json({ error: '您已购买过此文章' }, { status: 400 });
      }

      amount = parseFloat(post.price);
      metadata = {
        post_id: post.id,
        post_title: post.title,
        post_slug: post.slug,
      };
    } else {
      return NextResponse.json({ error: '无效的订单类型' }, { status: 400 });
    }

    // 创建订单
    const orderNo = generateOrderNo();
    const { data: order, error: orderError } = await client
      .from('orders')
      .insert({
        order_no: orderNo,
        user_id: user.userId,
        amount: amount.toFixed(2),
        currency: 'CNY',
        payment_method,
        payment_status: 'pending',
        metadata,
      })
      .select()
      .single();

    if (orderError) {
      return NextResponse.json({ error: orderError.message }, { status: 500 });
    }

    return NextResponse.json({ order });
  } catch (error) {
    console.error('Create order error:', error);
    return NextResponse.json({ error: '创建订单失败' }, { status: 500 });
  }
}
