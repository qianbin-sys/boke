import { NextRequest, NextResponse } from 'next/server';
import { getSupabaseClient } from '@/storage/database/supabase-client';
import { getCurrentUser } from '@/lib/auth';

// 获取订单详情
export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const user = await getCurrentUser();
    if (!user) {
      return NextResponse.json({ error: '请先登录' }, { status: 401 });
    }

    const { id } = await params;
    const client = getSupabaseClient();

    console.log('Get order detail:', { orderId: id, userId: user.userId });

    // 简化查询，先不关联其他表
    const { data: order, error } = await client
      .from('orders')
      .select('*')
      .eq('id', id)
      .eq('user_id', user.userId)
      .single();

    console.log('Order query result:', { order: order?.id, error: error?.message });

    if (error || !order) {
      // 尝试不带用户ID查询，看看订单是否存在
      const { data: rawOrder } = await client
        .from('orders')
        .select('id, user_id')
        .eq('id', id)
        .single();
      
      console.log('Raw order check:', rawOrder);
      
      return NextResponse.json({ error: '订单不存在' }, { status: 404 });
    }

    return NextResponse.json({ order });
  } catch (error) {
    console.error('Get order error:', error);
    return NextResponse.json({ error: '获取订单详情失败' }, { status: 500 });
  }
}

// 取消订单（用户取消未支付的订单）
export async function DELETE(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const user = await getCurrentUser();
    if (!user) {
      return NextResponse.json({ error: '请先登录' }, { status: 401 });
    }

    const { id } = await params;
    const client = getSupabaseClient();

    // 检查订单是否存在且属于当前用户
    const { data: order, error: orderError } = await client
      .from('orders')
      .select('id, payment_status')
      .eq('id', id)
      .eq('user_id', user.userId)
      .single();

    if (orderError || !order) {
      return NextResponse.json({ error: '订单不存在' }, { status: 404 });
    }

    // 只有待支付的订单可以取消
    if (order.payment_status !== 'pending') {
      return NextResponse.json({ error: '该订单无法取消' }, { status: 400 });
    }

    // 更新订单状态为已取消
    const { error: updateError } = await client
      .from('orders')
      .update({ payment_status: 'cancelled' })
      .eq('id', id);

    if (updateError) {
      return NextResponse.json({ error: '取消订单失败' }, { status: 500 });
    }

    return NextResponse.json({ success: true, message: '订单已取消' });
  } catch (error) {
    console.error('Cancel order error:', error);
    return NextResponse.json({ error: '取消订单失败' }, { status: 500 });
  }
}

// 支付回调处理 - 仅接受来自支付平台的回调
// 注意：此接口已废弃，请使用各支付方式的专用回调接口
// - 支付宝: /api/payment/alipay/notify
// - PayPal: /api/payment/paypal/capture-order
export async function PUT(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  // 禁止前端直接调用支付完成接口
  // 支付必须通过支付平台的回调来确认
  return NextResponse.json({ 
    error: '请通过正规支付流程完成支付',
    message: '此接口已禁用，请使用支付宝或PayPal进行支付'
  }, { status: 403 });
}
