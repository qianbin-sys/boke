import { NextRequest, NextResponse } from 'next/server';
import { getCurrentUser } from '@/lib/auth';
import { getSupabaseClient } from '@/storage/database/supabase-client';
import { LLMClient, Config, ImageGenerationClient } from 'coze-coding-dev-sdk';

// 设置默认模型或测试模型
export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const user = await getCurrentUser();
    if (!user || user.role !== 'admin') {
      return NextResponse.json({ error: '权限不足' }, { status: 403 });
    }

    const { id } = await params;
    const body = await request.json();
    const { action } = body;

    const supabase = getSupabaseClient();

    // 获取模型配置
    const { data: model, error: modelError } = await supabase
      .from('ai_models')
      .select('*')
      .eq('id', id)
      .single();

    if (modelError || !model) {
      return NextResponse.json({ error: '模型不存在' }, { status: 404 });
    }

    if (action === 'set_default') {
      // 设置为默认模型
      await supabase
        .from('ai_models')
        .update({ is_default: false, updated_at: new Date().toISOString() })
        .eq('model_type', model.model_type)
        .eq('is_default', true);

      const { error } = await supabase
        .from('ai_models')
        .update({ is_default: true, updated_at: new Date().toISOString() })
        .eq('id', id);

      if (error) {
        return NextResponse.json({ error: '设置默认模型失败' }, { status: 500 });
      }

      return NextResponse.json({ success: true, message: '已设为默认模型' });
    }
    else if (action === 'test') {
      // 测试模型
      try {
        if (model.model_type === 'llm') {
          return await testLLMModel(model);
        } else if (model.model_type === 'image') {
          return await testImageModel(model);
        } else {
          return NextResponse.json({ error: '未知模型类型' }, { status: 400 });
        }
      } catch (testError) {
        return NextResponse.json({ 
          success: false, 
          error: testError instanceof Error ? testError.message : '测试失败' 
        });
      }
    }
    else {
      return NextResponse.json({ error: '未知操作' }, { status: 400 });
    }
  } catch (error) {
    console.error('Model action error:', error);
    return NextResponse.json({ 
      error: error instanceof Error ? error.message : '操作失败' 
    }, { status: 500 });
  }
}

/**
 * 测试LLM模型
 */
async function testLLMModel(model: {
  provider: string;
  model_id: string;
  api_endpoint: string | null;
  api_key_encrypted: string | null;
}): Promise<NextResponse> {
  const { provider, model_id, api_endpoint, api_key_encrypted } = model;

  // 如果是豆包且没有自定义配置，使用SDK默认
  if (provider === 'doubao' && !api_key_encrypted) {
    const config = new Config();
    const client = new LLMClient(config);
    
    const messages = [
      { role: 'user' as const, content: '请回复"测试成功"三个字' }
    ];

    let response = '';
    const stream = client.stream(messages, { 
      model: model_id,
      temperature: 0.7,
    });
    
    for await (const chunk of stream) {
      if (chunk.content) {
        response += chunk.content.toString();
      }
    }

    return NextResponse.json({ 
      success: true, 
      message: 'LLM模型测试成功',
      response: response.substring(0, 200),
    });
  }

  // 自定义API配置
  if (!api_endpoint || !api_key_encrypted) {
    return NextResponse.json({ 
      success: false, 
      error: '请配置API端点和密钥' 
    });
  }

  // 使用自定义配置调用API
  try {
    const response = await fetch(`${api_endpoint}/chat/completions`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${api_key_encrypted}`,
      },
      body: JSON.stringify({
        model: model_id,
        messages: [{ role: 'user', content: '请回复"测试成功"三个字' }],
        max_tokens: 50,
      }),
    });

    if (!response.ok) {
      const errorData = await response.json().catch(() => ({}));
      throw new Error(errorData.error?.message || `HTTP ${response.status}`);
    }

    const data = await response.json();
    const content = data.choices?.[0]?.message?.content || '';

    return NextResponse.json({ 
      success: true, 
      message: 'LLM模型测试成功',
      response: content.substring(0, 200),
    });
  } catch (error) {
    throw new Error(`API调用失败: ${error instanceof Error ? error.message : '未知错误'}`);
  }
}

/**
 * 测试图片模型
 */
async function testImageModel(model: {
  provider: string;
  model_id: string;
  api_endpoint: string | null;
  api_key_encrypted: string | null;
}): Promise<NextResponse> {
  const { provider, api_key_encrypted } = model;

  // 如果是豆包且没有自定义配置，使用SDK默认
  if (provider === 'doubao' && !api_key_encrypted) {
    const config = new Config();
    const client = new ImageGenerationClient(config);
    
    const response = await client.generate({
      prompt: 'A simple test image: a blue circle on white background',
      size: '2K',
    });

    const helper = client.getResponseHelper(response);

    if (helper.success && helper.imageUrls[0]) {
      return NextResponse.json({ 
        success: true, 
        message: '图片模型测试成功',
        imageUrl: helper.imageUrls[0],
      });
    } else {
      throw new Error(helper.errorMessages.join(', ') || '图片生成失败');
    }
  }

  // 自定义配置暂不支持其他图片模型
  return NextResponse.json({ 
    success: false, 
    error: '暂不支持该图片模型的自定义配置' 
  });
}
