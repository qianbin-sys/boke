import { NextRequest, NextResponse } from 'next/server';
import { getCurrentUser } from '@/lib/auth';
import { getSupabaseClient } from '@/storage/database/supabase-client';

// 获取单个模型详情
export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const user = await getCurrentUser();
    if (!user || user.role !== 'admin') {
      return NextResponse.json({ error: '权限不足' }, { status: 403 });
    }

    const { id } = await params;
    const supabase = getSupabaseClient();

    const { data: model, error } = await supabase
      .from('ai_models')
      .select('*')
      .eq('id', id)
      .single();

    if (error || !model) {
      return NextResponse.json({ error: '模型不存在' }, { status: 404 });
    }

    return NextResponse.json({ model });
  } catch (error) {
    console.error('Get AI model error:', error);
    return NextResponse.json({ error: '获取模型详情失败' }, { status: 500 });
  }
}

// 更新模型
export async function PUT(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const user = await getCurrentUser();
    if (!user || user.role !== 'admin') {
      return NextResponse.json({ error: '权限不足' }, { status: 403 });
    }

    const { id } = await params;
    const body = await request.json();
    const {
      name,
      provider,
      model_type,
      model_id,
      api_endpoint,
      api_key,
      config,
      is_enabled,
      is_default,
      priority,
    } = body;

    const supabase = getSupabaseClient();

    // 如果设为默认，先取消同类型的其他默认
    if (is_default) {
      await supabase
        .from('ai_models')
        .update({ is_default: false, updated_at: new Date().toISOString() })
        .eq('model_type', model_type)
        .eq('is_default', true)
        .neq('id', id);
    }

    const updateData: Record<string, unknown> = {
      updated_at: new Date().toISOString(),
    };

    if (name !== undefined) updateData.name = name;
    if (provider !== undefined) updateData.provider = provider;
    if (model_type !== undefined) updateData.model_type = model_type;
    if (model_id !== undefined) updateData.model_id = model_id;
    if (api_endpoint !== undefined) updateData.api_endpoint = api_endpoint || null;
    if (api_key !== undefined) updateData.api_key_encrypted = api_key || null;
    if (config !== undefined) updateData.config = config;
    if (is_enabled !== undefined) updateData.is_enabled = is_enabled;
    if (is_default !== undefined) updateData.is_default = is_default;
    if (priority !== undefined) updateData.priority = priority;

    const { data: model, error } = await supabase
      .from('ai_models')
      .update(updateData)
      .eq('id', id)
      .select()
      .single();

    if (error) {
      console.error('Update model error:', error);
      return NextResponse.json({ error: '更新模型失败' }, { status: 500 });
    }

    return NextResponse.json({ model });
  } catch (error) {
    console.error('Update AI model error:', error);
    return NextResponse.json({ error: '更新模型失败' }, { status: 500 });
  }
}

// 删除模型
export async function DELETE(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const user = await getCurrentUser();
    if (!user || user.role !== 'admin') {
      return NextResponse.json({ error: '权限不足' }, { status: 403 });
    }

    const { id } = await params;
    const supabase = getSupabaseClient();

    const { error } = await supabase
      .from('ai_models')
      .delete()
      .eq('id', id);

    if (error) {
      console.error('Delete model error:', error);
      return NextResponse.json({ error: '删除模型失败' }, { status: 500 });
    }

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('Delete AI model error:', error);
    return NextResponse.json({ error: '删除模型失败' }, { status: 500 });
  }
}
