import { NextRequest, NextResponse } from 'next/server';
import { getCurrentUser } from '@/lib/auth';
import { getSupabaseClient } from '@/storage/database/supabase-client';

// 预设的模型提供商配置
export const MODEL_PROVIDERS = {
  doubao: {
    name: '豆包',
    models: {
      llm: [
        { id: 'doubao-seed-2-0-pro-260215', name: 'Seed 2.0 Pro' },
        { id: 'doubao-pro-32k', name: 'Pro 32K' },
        { id: 'doubao-lite-32k', name: 'Lite 32K' },
      ],
      image: [
        { id: 'default', name: '默认图片模型' },
      ],
    },
    defaultEndpoint: '', // 使用SDK默认
  },
  deepseek: {
    name: 'DeepSeek',
    models: {
      llm: [
        { id: 'deepseek-chat', name: 'DeepSeek Chat' },
        { id: 'deepseek-coder', name: 'DeepSeek Coder' },
      ],
      image: [],
    },
    defaultEndpoint: 'https://api.deepseek.com/v1',
  },
  kimi: {
    name: 'Kimi (月之暗面)',
    models: {
      llm: [
        { id: 'moonshot-v1-8k', name: 'Moonshot V1 8K' },
        { id: 'moonshot-v1-32k', name: 'Moonshot V1 32K' },
        { id: 'moonshot-v1-128k', name: 'Moonshot V1 128K' },
      ],
      image: [],
    },
    defaultEndpoint: 'https://api.moonshot.cn/v1',
  },
  openai: {
    name: 'OpenAI',
    models: {
      llm: [
        { id: 'gpt-4o', name: 'GPT-4o' },
        { id: 'gpt-4o-mini', name: 'GPT-4o Mini' },
        { id: 'gpt-4-turbo', name: 'GPT-4 Turbo' },
        { id: 'gpt-3.5-turbo', name: 'GPT-3.5 Turbo' },
      ],
      image: [
        { id: 'dall-e-3', name: 'DALL-E 3' },
        { id: 'dall-e-2', name: 'DALL-E 2' },
      ],
    },
    defaultEndpoint: 'https://api.openai.com/v1',
  },
  custom: {
    name: '自定义',
    models: {
      llm: [],
      image: [],
    },
    defaultEndpoint: '',
  },
};

// 获取模型列表
export async function GET(request: NextRequest) {
  try {
    const user = await getCurrentUser();
    if (!user || user.role !== 'admin') {
      return NextResponse.json({ error: '权限不足' }, { status: 403 });
    }

    const supabase = getSupabaseClient();
    
    const { data: models, error } = await supabase
      .from('ai_models')
      .select('*')
      .order('model_type')
      .order('priority', { ascending: false })
      .order('created_at', { ascending: true });

    if (error) {
      console.error('Fetch models error:', error);
      return NextResponse.json({ error: '获取模型列表失败' }, { status: 500 });
    }

    return NextResponse.json({ 
      models,
      providers: MODEL_PROVIDERS,
    });
  } catch (error) {
    console.error('Get AI models error:', error);
    return NextResponse.json({ error: '获取模型列表失败' }, { status: 500 });
  }
}

// 创建/更新模型
export async function POST(request: NextRequest) {
  try {
    const user = await getCurrentUser();
    if (!user || user.role !== 'admin') {
      return NextResponse.json({ error: '权限不足' }, { status: 403 });
    }

    const body = await request.json();
    const {
      id, // 如果有id则是更新
      name,
      provider,
      model_type,
      model_id,
      api_endpoint,
      api_key,
      config,
      is_enabled,
      is_default,
      priority,
    } = body;

    if (!name || !provider || !model_type || !model_id) {
      return NextResponse.json({ error: '缺少必要参数' }, { status: 400 });
    }

    const supabase = getSupabaseClient();

    // 如果设为默认，先取消同类型的其他默认
    if (is_default) {
      await supabase
        .from('ai_models')
        .update({ is_default: false, updated_at: new Date().toISOString() })
        .eq('model_type', model_type)
        .eq('is_default', true);
    }

    const modelData = {
      name,
      provider,
      model_type,
      model_id,
      api_endpoint: api_endpoint || null,
      api_key_encrypted: api_key || null, // 实际应加密存储
      config: config || {},
      is_enabled: is_enabled !== undefined ? is_enabled : true,
      is_default: is_default || false,
      priority: priority || 0,
      updated_at: new Date().toISOString(),
    };

    let result;
    if (id) {
      // 更新
      const { data, error } = await supabase
        .from('ai_models')
        .update(modelData)
        .eq('id', id)
        .select()
        .single();
      
      if (error) throw error;
      result = data;
    } else {
      // 创建
      const { data, error } = await supabase
        .from('ai_models')
        .insert(modelData)
        .select()
        .single();
      
      if (error) throw error;
      result = data;
    }

    return NextResponse.json({ model: result });
  } catch (error) {
    console.error('Save AI model error:', error);
    return NextResponse.json({ error: '保存模型失败' }, { status: 500 });
  }
}

// 删除模型
export async function DELETE(request: NextRequest) {
  try {
    const user = await getCurrentUser();
    if (!user || user.role !== 'admin') {
      return NextResponse.json({ error: '权限不足' }, { status: 403 });
    }

    const { ids } = await request.json();
    
    if (!ids || !Array.isArray(ids) || ids.length === 0) {
      return NextResponse.json({ error: '请选择要删除的模型' }, { status: 400 });
    }

    const supabase = getSupabaseClient();
    
    const { error } = await supabase
      .from('ai_models')
      .delete()
      .in('id', ids);

    if (error) {
      console.error('Delete models error:', error);
      return NextResponse.json({ error: '删除模型失败' }, { status: 500 });
    }

    return NextResponse.json({ success: true, deleted: ids.length });
  } catch (error) {
    console.error('Delete AI models error:', error);
    return NextResponse.json({ error: '删除模型失败' }, { status: 500 });
  }
}
