import { NextRequest, NextResponse } from 'next/server';
import { getSupabaseClient } from '@/storage/database/supabase-client';

export async function GET(request: NextRequest) {
  try {
    const searchParams = request.nextUrl.searchParams;
    const query = searchParams.get('q');
    
    if (!query || query.trim().length === 0) {
      return NextResponse.json({ posts: [], total: 0 });
    }

    const client = getSupabaseClient();
    const searchTerm = query.trim();
    
    // 搜索文章标题、内容、摘要
    const { data: posts, error, count } = await client
      .from('posts')
      .select(`
        id,
        title,
        slug,
        excerpt,
        featured_image,
        view_count,
        published_at,
        created_at,
        categories(id, name, slug),
        post_tags(
          id,
          tags(id, name, slug)
        )
      `, { count: 'exact' })
      .eq('status', 'published')
      .or(`title.ilike.%${searchTerm}%,content.ilike.%${searchTerm}%,excerpt.ilike.%${searchTerm}%`)
      .order('published_at', { ascending: false })
      .limit(50);

    if (error) {
      console.error('Search error:', error);
      return NextResponse.json({ error: error.message }, { status: 500 });
    }

    // 格式化标签
    const formattedPosts = (posts || []).map(post => ({
      ...post,
      tags: (post.post_tags || []).map((pt: any) => pt.tags).filter(Boolean),
    }));

    return NextResponse.json({
      posts: formattedPosts,
      total: count || 0,
      query: searchTerm,
    });
  } catch (error) {
    console.error('Search error:', error);
    return NextResponse.json({ error: '搜索失败' }, { status: 500 });
  }
}
