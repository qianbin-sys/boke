import { NextRequest, NextResponse } from 'next/server';
import { getSupabaseClient } from '@/storage/database/supabase-client';
import { getCurrentUser } from '@/lib/auth';
import { hashPassword } from '@/lib/auth';

// 更新用户
export async function PUT(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const currentUser = await getCurrentUser();
    if (!currentUser || currentUser.role !== 'admin') {
      return NextResponse.json({ error: '权限不足' }, { status: 403 });
    }
    
    const { id } = await params;
    const body = await request.json();
    const { username, email, password, display_name, role, is_active } = body;
    
    const client = getSupabaseClient();
    
    const updateData: Record<string, unknown> = {
      username,
      email,
      display_name,
      role,
      is_active,
      updated_at: new Date().toISOString(),
    };
    
    if (password) {
      updateData.password_hash = await hashPassword(password);
    }
    
    const { data, error } = await client
      .from('users')
      .update(updateData)
      .eq('id', id)
      .select('id, username, email, display_name, role, is_active, created_at')
      .single();
    
    if (error) {
      return NextResponse.json({ error: error.message }, { status: 500 });
    }
    
    return NextResponse.json({ user: data });
  } catch (error) {
    console.error('Update user error:', error);
    return NextResponse.json({ error: '更新用户失败' }, { status: 500 });
  }
}

// 删除用户
export async function DELETE(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const currentUser = await getCurrentUser();
    if (!currentUser || currentUser.role !== 'admin') {
      return NextResponse.json({ error: '权限不足' }, { status: 403 });
    }
    
    const { id } = await params;
    
    // 不能删除自己
    if (id === currentUser.userId) {
      return NextResponse.json({ error: '不能删除自己的账户' }, { status: 400 });
    }
    
    const client = getSupabaseClient();
    
    // 检查用户是否有关联订单
    const { data: orders, error: ordersError } = await client
      .from('orders')
      .select('id')
      .eq('user_id', id)
      .limit(1);
    
    if (ordersError) {
      return NextResponse.json({ error: '查询用户订单失败' }, { status: 500 });
    }
    
    if (orders && orders.length > 0) {
      return NextResponse.json({ 
        error: '该用户存在关联订单，无法直接删除。请先删除用户的订单记录，或禁用该用户账户。',
        hasOrders: true 
      }, { status: 400 });
    }
    
    // 检查用户是否有会员记录
    const { data: memberships, error: membershipsError } = await client
      .from('user_memberships')
      .select('id')
      .eq('user_id', id)
      .limit(1);
    
    if (membershipsError) {
      return NextResponse.json({ error: '查询用户会员记录失败' }, { status: 500 });
    }
    
    // 删除会员记录（如果没有订单，会员记录可以安全删除）
    if (memberships && memberships.length > 0) {
      await client
        .from('user_memberships')
        .delete()
        .eq('user_id', id);
    }
    
    const { error } = await client
      .from('users')
      .delete()
      .eq('id', id);
    
    if (error) {
      return NextResponse.json({ error: error.message }, { status: 500 });
    }
    
    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('Delete user error:', error);
    return NextResponse.json({ error: '删除用户失败' }, { status: 500 });
  }
}
