import { NextRequest, NextResponse } from 'next/server';
import { getSupabaseClient } from '@/storage/database/supabase-client';
import { getCurrentUser } from '@/lib/auth';
import { hashPassword } from '@/lib/auth';

// 获取用户列表
export async function GET(request: NextRequest) {
  try {
    const user = await getCurrentUser();
    if (!user || user.role !== 'admin') {
      return NextResponse.json({ error: '权限不足' }, { status: 403 });
    }
    
    const client = getSupabaseClient();
    const searchParams = request.nextUrl.searchParams;
    
    const page = parseInt(searchParams.get('page') || '1');
    const limit = parseInt(searchParams.get('limit') || '10');
    const search = searchParams.get('search');
    
    let query = client
      .from('users')
      .select('id, username, email, display_name, role, is_active, created_at', { count: 'exact' })
      .order('created_at', { ascending: false })
      .range((page - 1) * limit, page * limit - 1);
    
    if (search) {
      query = query.or(`username.ilike.%${search}%,email.ilike.%${search}%,display_name.ilike.%${search}%`);
    }
    
    const { data, error, count } = await query;
    
    if (error) {
      return NextResponse.json({ error: error.message }, { status: 500 });
    }

    // 获取用户会员信息
    const userIds = (data || []).map(u => u.id);
    const now = new Date().toISOString();
    
    const { data: memberships } = await client
      .from('user_memberships')
      .select(`
        user_id,
        status,
        expired_at,
        membership_plans(id, name)
      `)
      .in('user_id', userIds)
      .eq('status', 'active');

    // 获取用户订单统计
    const { data: orderStats } = await client
      .from('orders')
      .select('user_id, payment_status')
      .in('user_id', userIds);

    // 整理会员信息
    const membershipMap = new Map();
    (memberships || []).forEach(m => {
      const isValid = !m.expired_at || new Date(m.expired_at) > new Date();
      if (isValid) {
        membershipMap.set(m.user_id, m);
      }
    });

    // 整理订单统计
    const orderMap = new Map();
    (orderStats || []).forEach(o => {
      if (!orderMap.has(o.user_id)) {
        orderMap.set(o.user_id, { total: 0, paid: 0 });
      }
      const stats = orderMap.get(o.user_id);
      stats.total++;
      if (o.payment_status === 'paid') stats.paid++;
    });

    // 合并数据
    const usersWithMembership = (data || []).map(u => ({
      ...u,
      membership: membershipMap.get(u.id) || null,
      orderStats: orderMap.get(u.id) || { total: 0, paid: 0 },
    }));
    
    return NextResponse.json({
      users: usersWithMembership,
      total: count,
      page,
      limit,
      totalPages: Math.ceil((count || 0) / limit),
    });
  } catch (error) {
    console.error('Get users error:', error);
    return NextResponse.json({ error: '获取用户列表失败' }, { status: 500 });
  }
}

// 创建用户
export async function POST(request: NextRequest) {
  try {
    const currentUser = await getCurrentUser();
    if (!currentUser || currentUser.role !== 'admin') {
      return NextResponse.json({ error: '权限不足' }, { status: 403 });
    }
    
    const body = await request.json();
    const { username, email, password, display_name, role } = body;
    
    if (!username || !email || !password) {
      return NextResponse.json({ error: '用户名、邮箱和密码不能为空' }, { status: 400 });
    }
    
    const client = getSupabaseClient();
    
    // 检查用户名是否已存在
    const { data: existingUser } = await client
      .from('users')
      .select('id')
      .or(`username.eq.${username},email.eq.${email}`)
      .maybeSingle();
    
    if (existingUser) {
      return NextResponse.json({ error: '用户名或邮箱已存在' }, { status: 400 });
    }
    
    const passwordHash = await hashPassword(password);
    
    const { data, error } = await client
      .from('users')
      .insert({
        username,
        email,
        password_hash: passwordHash,
        display_name,
        role: role || 'subscriber',
        is_active: true,
      })
      .select('id, username, email, display_name, role, is_active, created_at')
      .single();
    
    if (error) {
      return NextResponse.json({ error: error.message }, { status: 500 });
    }
    
    return NextResponse.json({ user: data });
  } catch (error) {
    console.error('Create user error:', error);
    return NextResponse.json({ error: '创建用户失败' }, { status: 500 });
  }
}
