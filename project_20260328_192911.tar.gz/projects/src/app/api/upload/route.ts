import { NextRequest, NextResponse } from 'next/server';
import { S3Storage } from 'coze-coding-dev-sdk';
import { getSupabaseClient } from '@/storage/database/supabase-client';
import { getCurrentUser } from '@/lib/auth';

// 初始化存储
const storage = new S3Storage({
  endpointUrl: process.env.COZE_BUCKET_ENDPOINT_URL,
  accessKey: '',
  secretKey: '',
  bucketName: process.env.COZE_BUCKET_NAME,
  region: 'cn-beijing',
});

// 允许的文件类型
const ALLOWED_TYPES: Record<string, string[]> = {
  image: ['image/jpeg', 'image/png', 'image/gif', 'image/webp', 'image/svg+xml'],
  video: ['video/mp4', 'video/webm', 'video/ogg'],
  document: ['application/pdf', 'application/msword', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'],
};

// 获取文件类型分类
function getFileCategory(mimeType: string): string {
  for (const [category, types] of Object.entries(ALLOWED_TYPES)) {
    if (types.includes(mimeType)) {
      return category;
    }
  }
  return 'other';
}

export async function POST(request: NextRequest) {
  try {
    // 检查用户认证
    const user = await getCurrentUser();
    if (!user) {
      return NextResponse.json(
        { success: false, error: '请先登录' },
        { status: 401 }
      );
    }

    const formData = await request.formData();
    const file = formData.get('file') as File;
    
    if (!file) {
      return NextResponse.json(
        { success: false, error: '请选择要上传的文件' },
        { status: 400 }
      );
    }
    
    // 验证文件类型
    const allAllowedTypes = Object.values(ALLOWED_TYPES).flat();
    if (!allAllowedTypes.includes(file.type)) {
      return NextResponse.json(
        { success: false, error: '不支持的文件类型，支持图片、视频和常见文档格式' },
        { status: 400 }
      );
    }
    
    // 验证文件大小 (图片最大5MB，视频最大50MB，文档最大10MB)
    const category = getFileCategory(file.type);
    let maxSize = 5 * 1024 * 1024; // 默认5MB
    if (category === 'video') {
      maxSize = 50 * 1024 * 1024; // 视频50MB
    } else if (category === 'document') {
      maxSize = 10 * 1024 * 1024; // 文档10MB
    }
    
    if (file.size > maxSize) {
      const maxMB = Math.round(maxSize / (1024 * 1024));
      return NextResponse.json(
        { success: false, error: `文件大小不能超过 ${maxMB}MB` },
        { status: 400 }
      );
    }
    
    // 读取文件内容
    const arrayBuffer = await file.arrayBuffer();
    const buffer = Buffer.from(arrayBuffer);
    
    // 生成文件名
    const timestamp = Date.now();
    const randomStr = Math.random().toString(36).substring(2, 8);
    const ext = file.name.split('.').pop() || 'bin';
    const fileName = `media/${category}/${timestamp}_${randomStr}.${ext}`;
    
    // 上传到对象存储
    const fileKey = await storage.uploadFile({
      fileContent: buffer,
      fileName,
      contentType: file.type,
    });
    
    // 生成访问URL (有效期30天)
    const url = await storage.generatePresignedUrl({
      key: fileKey,
      expireTime: 30 * 24 * 60 * 60, // 30天
    });
    
    // 保存到数据库
    const client = getSupabaseClient();
    const { data: mediaRecord, error: dbError } = await client
      .from('media')
      .insert({
        filename: fileKey,
        original_name: file.name,
        mime_type: file.type,
        size: file.size,
        url: url,
        uploader_id: user.userId,
      })
      .select()
      .single();
    
    if (dbError) {
      console.error('Database save error:', dbError);
      // 文件已上传成功，但数据库保存失败，仍然返回成功
    }
    
    return NextResponse.json({
      success: true,
      data: {
        id: mediaRecord?.id,
        key: fileKey,
        url,
        filename: file.name,
        size: file.size,
        type: file.type,
      },
    });
  } catch (error) {
    console.error('Upload error:', error);
    return NextResponse.json(
      { success: false, error: '上传失败，请稍后重试' },
      { status: 500 }
    );
  }
}
