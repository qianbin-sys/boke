import { NextRequest } from 'next/server';
import { LLMClient, Config, HeaderUtils } from 'coze-coding-dev-sdk';
import { getCurrentUser } from '@/lib/auth';

export const maxDuration = 120; // 2分钟超时

interface SEORequest {
  title: string;
  content: string;
  excerpt?: string;
  category?: string;
  tags?: string[];
}

export async function POST(request: NextRequest) {
  try {
    const user = await getCurrentUser();
    if (!user || user.role !== 'admin') {
      return new Response(JSON.stringify({ error: '权限不足' }), { 
        status: 403,
        headers: { 'Content-Type': 'application/json' }
      });
    }

    const body: SEORequest = await request.json();
    const { title, content, excerpt, category, tags } = body;

    if (!title || !content) {
      return new Response(JSON.stringify({ error: '请提供文章标题和内容' }), { 
        status: 400,
        headers: { 'Content-Type': 'application/json' }
      });
    }

    const customHeaders = HeaderUtils.extractForwardHeaders(request.headers);
    const config = new Config();
    const client = new LLMClient(config, customHeaders);

    // 构建系统提示
    const systemPrompt = `你是一位专业的SEO优化专家，擅长为网站文章生成优化的SEO元数据。

你的任务是根据文章标题和内容，生成以下SEO信息：
1. **SEO标题**：吸引人、包含关键词、适合搜索引擎，建议50-60字符
2. **SEO描述**：简洁有力、概括文章核心内容、包含主要关键词，建议120-160字符
3. **SEO关键词**：提取5-8个核心关键词，用逗号分隔

注意事项：
- SEO标题应该比原标题更具吸引力，同时保持关键词相关性
- SEO描述要自然流畅，避免堆砌关键词，让用户有点击欲望
- 关键词要涵盖文章主题、长尾词和相关词汇
- 返回JSON格式，不要添加任何其他文本

返回格式示例：
{
  "seo_title": "优化后的标题",
  "seo_description": "优化后的描述内容",
  "seo_keywords": "关键词1, 关键词2, 关键词3"
}`;

    // 构建用户消息
    let userContent = `请为以下文章生成SEO优化信息：

【文章标题】
${title}

【文章内容】
${content.substring(0, 3000)}${content.length > 3000 ? '...' : ''}`;

    if (excerpt) {
      userContent += `\n\n【文章摘要】\n${excerpt}`;
    }
    if (category) {
      userContent += `\n\n【文章分类】\n${category}`;
    }
    if (tags && tags.length > 0) {
      userContent += `\n\n【文章标签】\n${tags.join(', ')}`;
    }

    userContent += `\n\n请返回JSON格式的SEO优化信息：`;

    const messages = [
      { role: 'system' as const, content: systemPrompt },
      { role: 'user' as const, content: userContent }
    ];

    // 创建流式响应
    const encoder = new TextEncoder();
    const stream = new ReadableStream({
      async start(controller) {
        try {
          const llmStream = client.stream(messages, { 
            temperature: 0.7,
            model: 'doubao-seed-2-0-pro-260215'
          });

          let fullContent = '';
          
          for await (const chunk of llmStream) {
            if (chunk.content) {
              const text = chunk.content.toString();
              fullContent += text;
              const data = JSON.stringify({ content: text });
              controller.enqueue(encoder.encode(`data: ${data}\n\n`));
            }
          }

          // 尝试解析并验证JSON
          try {
            // 提取JSON部分（去除可能的markdown代码块标记）
            let jsonStr = fullContent.trim();
            if (jsonStr.startsWith('```json')) {
              jsonStr = jsonStr.slice(7);
            }
            if (jsonStr.startsWith('```')) {
              jsonStr = jsonStr.slice(3);
            }
            if (jsonStr.endsWith('```')) {
              jsonStr = jsonStr.slice(0, -3);
            }
            jsonStr = jsonStr.trim();
            
            const seoData = JSON.parse(jsonStr);
            
            // 发送结构化结果
            controller.enqueue(encoder.encode(`data: ${JSON.stringify({ 
              done: true, 
              result: {
                seo_title: seoData.seo_title || title,
                seo_description: seoData.seo_description || excerpt || '',
                seo_keywords: seoData.seo_keywords || ''
              }
            })}\n\n`));
          } catch (parseError) {
            // 如果解析失败，尝试从内容中提取
            console.error('JSON parse error:', parseError);
            controller.enqueue(encoder.encode(`data: ${JSON.stringify({ 
              error: '解析结果失败，请重试',
              raw: fullContent
            })}\n\n`));
          }
          
          controller.close();
        } catch (error) {
          console.error('Stream error:', error);
          const errorData = JSON.stringify({ error: '生成失败，请重试' });
          controller.enqueue(encoder.encode(`data: ${errorData}\n\n`));
          controller.close();
        }
      }
    });

    return new Response(stream, {
      headers: {
        'Content-Type': 'text/event-stream',
        'Cache-Control': 'no-cache',
        'Connection': 'keep-alive',
      },
    });
  } catch (error) {
    console.error('AI SEO error:', error);
    return new Response(JSON.stringify({ error: 'AI SEO优化失败' }), { 
      status: 500,
      headers: { 'Content-Type': 'application/json' }
    });
  }
}
