import { NextRequest, NextResponse } from 'next/server';
import { getSupabaseClient } from '@/storage/database/supabase-client';
import { getCurrentUser } from '@/lib/auth';

// 获取会员套餐列表
export async function GET() {
  try {
    const client = getSupabaseClient();
    
    const { data, error } = await client
      .from('membership_plans')
      .select('*')
      .order('sort_order', { ascending: true });
    
    if (error) {
      return NextResponse.json({ error: error.message }, { status: 500 });
    }
    
    return NextResponse.json({ plans: data });
  } catch (error) {
    console.error('Get membership plans error:', error);
    return NextResponse.json({ error: '获取会员套餐列表失败' }, { status: 500 });
  }
}

// 创建会员套餐
export async function POST(request: NextRequest) {
  try {
    const user = await getCurrentUser();
    if (!user || user.role !== 'admin') {
      return NextResponse.json({ error: '权限不足' }, { status: 403 });
    }
    
    const body = await request.json();
    const { name, slug, description, price, original_price, duration_days, features, is_active, sort_order } = body;
    
    if (!name || !slug || !price || duration_days === undefined) {
      return NextResponse.json({ error: '名称、别名、价格和有效期不能为空' }, { status: 400 });
    }
    
    const client = getSupabaseClient();
    
    // 检查 slug 是否已存在
    const { data: existingPlan } = await client
      .from('membership_plans')
      .select('id')
      .eq('slug', slug)
      .maybeSingle();
    
    if (existingPlan) {
      return NextResponse.json({ error: '套餐别名已存在' }, { status: 400 });
    }
    
    const { data, error } = await client
      .from('membership_plans')
      .insert({
        name,
        slug,
        description,
        price,
        original_price,
        duration_days,
        features: features || [],
        is_active: is_active !== undefined ? is_active : true,
        sort_order: sort_order || 0,
      })
      .select()
      .single();
    
    if (error) {
      return NextResponse.json({ error: error.message }, { status: 500 });
    }
    
    return NextResponse.json({ plan: data });
  } catch (error) {
    console.error('Create membership plan error:', error);
    return NextResponse.json({ error: '创建会员套餐失败' }, { status: 500 });
  }
}
