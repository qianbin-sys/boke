import { NextRequest, NextResponse } from 'next/server';
import { getSupabaseClient } from '@/storage/database/supabase-client';
import { getCurrentUser } from '@/lib/auth';

// 获取单个会员套餐
export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const client = getSupabaseClient();
    
    const { data, error } = await client
      .from('membership_plans')
      .select('*')
      .eq('id', id)
      .single();
    
    if (error) {
      return NextResponse.json({ error: '套餐不存在' }, { status: 404 });
    }
    
    return NextResponse.json({ plan: data });
  } catch (error) {
    console.error('Get membership plan error:', error);
    return NextResponse.json({ error: '获取会员套餐失败' }, { status: 500 });
  }
}

// 更新会员套餐
export async function PUT(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const user = await getCurrentUser();
    if (!user || user.role !== 'admin') {
      return NextResponse.json({ error: '权限不足' }, { status: 403 });
    }
    
    const { id } = await params;
    const body = await request.json();
    const { name, slug, description, price, original_price, duration_days, features, is_active, sort_order } = body;
    
    const client = getSupabaseClient();
    
    // 检查 slug 是否与其他套餐冲突
    if (slug) {
      const { data: existingPlan } = await client
        .from('membership_plans')
        .select('id')
        .eq('slug', slug)
        .neq('id', id)
        .maybeSingle();
      
      if (existingPlan) {
        return NextResponse.json({ error: '套餐别名已存在' }, { status: 400 });
      }
    }
    
    const updateData: Record<string, unknown> = { updated_at: new Date().toISOString() };
    if (name !== undefined) updateData.name = name;
    if (slug !== undefined) updateData.slug = slug;
    if (description !== undefined) updateData.description = description;
    if (price !== undefined) updateData.price = price;
    if (original_price !== undefined) updateData.original_price = original_price;
    if (duration_days !== undefined) updateData.duration_days = duration_days;
    if (features !== undefined) updateData.features = features;
    if (is_active !== undefined) updateData.is_active = is_active;
    if (sort_order !== undefined) updateData.sort_order = sort_order;
    
    const { data, error } = await client
      .from('membership_plans')
      .update(updateData)
      .eq('id', id)
      .select()
      .single();
    
    if (error) {
      return NextResponse.json({ error: error.message }, { status: 500 });
    }
    
    if (!data) {
      return NextResponse.json({ error: '套餐不存在' }, { status: 404 });
    }
    
    return NextResponse.json({ plan: data });
  } catch (error) {
    console.error('Update membership plan error:', error);
    return NextResponse.json({ error: '更新会员套餐失败' }, { status: 500 });
  }
}

// 删除会员套餐
export async function DELETE(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const user = await getCurrentUser();
    if (!user || user.role !== 'admin') {
      return NextResponse.json({ error: '权限不足' }, { status: 403 });
    }
    
    const { id } = await params;
    const client = getSupabaseClient();
    
    // 检查是否有用户正在使用此套餐
    const { data: memberships } = await client
      .from('user_memberships')
      .select('id')
      .eq('plan_id', id)
      .eq('status', 'active')
      .limit(1);
    
    if (memberships && memberships.length > 0) {
      return NextResponse.json({ error: '该套餐有用户正在使用，无法删除' }, { status: 400 });
    }
    
    const { error } = await client
      .from('membership_plans')
      .delete()
      .eq('id', id);
    
    if (error) {
      return NextResponse.json({ error: error.message }, { status: 500 });
    }
    
    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('Delete membership plan error:', error);
    return NextResponse.json({ error: '删除会员套餐失败' }, { status: 500 });
  }
}
