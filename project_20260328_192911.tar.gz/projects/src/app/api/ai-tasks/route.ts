import { NextRequest, NextResponse } from 'next/server';
import { getCurrentUser } from '@/lib/auth';
import { getSupabaseClient } from '@/storage/database/supabase-client';

// 获取AI任务列表
export async function GET(request: NextRequest) {
  try {
    const user = await getCurrentUser();
    if (!user || user.role !== 'admin') {
      return NextResponse.json({ error: '权限不足' }, { status: 403 });
    }

    const supabase = getSupabaseClient();
    
    // 获取任务列表
    const { data: tasks, error } = await supabase
      .from('ai_scheduled_tasks')
      .select('*')
      .order('created_at', { ascending: false });

    if (error) {
      console.error('Fetch tasks error:', error);
      return NextResponse.json({ error: '获取任务列表失败' }, { status: 500 });
    }

    // 如果没有任务，直接返回
    if (!tasks || tasks.length === 0) {
      return NextResponse.json({ tasks: [] });
    }

    // 获取所有关联的分类ID
    const categoryIds = tasks
      .filter(t => t.category_id)
      .map(t => t.category_id);

    // 批量查询分类名称
    let categories: Record<string, string> = {};
    if (categoryIds.length > 0) {
      const { data: categoryData } = await supabase
        .from('categories')
        .select('id, name')
        .in('id', categoryIds);
      
      if (categoryData) {
        categoryData.forEach(cat => {
          categories[cat.id] = cat.name;
        });
      }
    }

    // 获取每个任务的最近执行日志
    const tasksWithLogs = await Promise.all(
      tasks.map(async (task) => {
        const { data: logs } = await supabase
          .from('ai_task_logs')
          .select('*')
          .eq('task_id', task.id)
          .order('created_at', { ascending: false })
          .limit(5);
        
        return {
          ...task,
          category_name: task.category_id ? categories[task.category_id] || null : null,
          recent_logs: logs || [],
        };
      })
    );

    return NextResponse.json({ tasks: tasksWithLogs });
  } catch (error) {
    console.error('Get AI tasks error:', error);
    return NextResponse.json({ error: '获取任务列表失败' }, { status: 500 });
  }
}

// 创建AI任务
export async function POST(request: NextRequest) {
  try {
    const user = await getCurrentUser();
    if (!user || user.role !== 'admin') {
      return NextResponse.json({ error: '权限不足' }, { status: 403 });
    }

    const body = await request.json();
    const {
      name,
      article_type,
      writing_style,
      article_length,
      publish_interval,
      category_id,
      tags,
      execute_hour,
      execute_minute,
    } = body;

    if (!name || !article_type) {
      return NextResponse.json({ error: '任务名称和文章类型不能为空' }, { status: 400 });
    }

    const supabase = getSupabaseClient();
    
    // 计算下次执行时间
    const nextRunAt = calculateNextRunTime(
      publish_interval || 24,
      execute_hour,
      execute_minute
    );

    const { data: task, error } = await supabase
      .from('ai_scheduled_tasks')
      .insert({
        name,
        article_type,
        writing_style: writing_style || 'professional',
        article_length: article_length || 1500,
        publish_interval: publish_interval || 24,
        category_id: category_id || null,
        tags: tags || [],
        status: 'active',
        next_run_at: nextRunAt.toISOString(),
        execute_hour: execute_hour !== undefined ? execute_hour : null,
        execute_minute: execute_minute || 0,
        created_by: user.userId,
      })
      .select()
      .single();

    if (error) {
      console.error('Create task error:', error);
      return NextResponse.json({ error: '创建任务失败' }, { status: 500 });
    }

    return NextResponse.json({ task });
  } catch (error) {
    console.error('Create AI task error:', error);
    return NextResponse.json({ error: '创建任务失败' }, { status: 500 });
  }
}

/**
 * 计算下次执行时间
 */
function calculateNextRunTime(
  intervalHours: number, 
  executeHour?: number | null,
  executeMinute?: number | null
): Date {
  const now = new Date();
  
  // 如果指定了执行时间点（如每天10:00执行）
  if (executeHour !== null && executeHour !== undefined) {
    const nextRun = new Date();
    nextRun.setHours(executeHour, executeMinute || 0, 0, 0);
    
    // 如果今天的执行时间已过，则设置为明天
    if (nextRun <= now) {
      nextRun.setDate(nextRun.getDate() + 1);
    }
    
    return nextRun;
  }
  
  // 否则按间隔计算
  const nextRun = new Date(now.getTime() + intervalHours * 60 * 60 * 1000);
  return nextRun;
}

// 批量删除任务
export async function DELETE(request: NextRequest) {
  try {
    const user = await getCurrentUser();
    if (!user || user.role !== 'admin') {
      return NextResponse.json({ error: '权限不足' }, { status: 403 });
    }

    const { ids } = await request.json();
    
    if (!ids || !Array.isArray(ids) || ids.length === 0) {
      return NextResponse.json({ error: '请选择要删除的任务' }, { status: 400 });
    }

    const supabase = getSupabaseClient();
    
    const { error } = await supabase
      .from('ai_scheduled_tasks')
      .delete()
      .in('id', ids);

    if (error) {
      console.error('Delete tasks error:', error);
      return NextResponse.json({ error: '删除任务失败' }, { status: 500 });
    }

    return NextResponse.json({ success: true, deleted: ids.length });
  } catch (error) {
    console.error('Delete AI tasks error:', error);
    return NextResponse.json({ error: '删除任务失败' }, { status: 500 });
  }
}
