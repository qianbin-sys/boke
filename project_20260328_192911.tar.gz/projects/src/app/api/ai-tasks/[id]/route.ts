import { NextRequest, NextResponse } from 'next/server';
import { getCurrentUser } from '@/lib/auth';
import { getSupabaseClient } from '@/storage/database/supabase-client';
import { executeAITask } from '@/lib/ai-task-executor';

// 获取单个任务详情
export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const user = await getCurrentUser();
    if (!user || user.role !== 'admin') {
      return NextResponse.json({ error: '权限不足' }, { status: 403 });
    }

    const { id } = await params;
    const supabase = getSupabaseClient();

    const { data: task, error } = await supabase
      .from('ai_scheduled_tasks')
      .select('*')
      .eq('id', id)
      .single();

    if (error || !task) {
      return NextResponse.json({ error: '任务不存在' }, { status: 404 });
    }

    // 获取分类名称
    let categoryName = null;
    if (task.category_id) {
      const { data: category } = await supabase
        .from('categories')
        .select('name')
        .eq('id', task.category_id)
        .single();
      categoryName = category?.name || null;
    }

    // 获取执行日志
    const { data: logs } = await supabase
      .from('ai_task_logs')
      .select('*')
      .eq('task_id', id)
      .order('created_at', { ascending: false })
      .limit(20);

    return NextResponse.json({
      task: {
        ...task,
        category_name: categoryName,
        logs: logs || [],
      },
    });
  } catch (error) {
    console.error('Get AI task error:', error);
    return NextResponse.json({ error: '获取任务详情失败' }, { status: 500 });
  }
}

// 更新任务
export async function PUT(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const user = await getCurrentUser();
    if (!user || user.role !== 'admin') {
      return NextResponse.json({ error: '权限不足' }, { status: 403 });
    }

    const { id } = await params;
    const body = await request.json();
    const {
      name,
      article_type,
      writing_style,
      article_length,
      publish_interval,
      category_id,
      tags,
      execute_hour,
      execute_minute,
    } = body;

    const supabase = getSupabaseClient();

    // 获取当前任务状态
    const { data: currentTask } = await supabase
      .from('ai_scheduled_tasks')
      .select('status')
      .eq('id', id)
      .single();

    // 更新任务
    const updateData: Record<string, unknown> = {
      updated_at: new Date().toISOString(),
    };
    
    if (name) updateData.name = name;
    if (article_type) updateData.article_type = article_type;
    if (writing_style) updateData.writing_style = writing_style;
    if (article_length) updateData.article_length = article_length;
    if (publish_interval !== undefined) updateData.publish_interval = publish_interval;
    if (category_id !== undefined) updateData.category_id = category_id || null;
    if (tags !== undefined) updateData.tags = tags;
    
    // 处理执行时间
    if (execute_hour !== undefined) {
      updateData.execute_hour = execute_hour;
      updateData.execute_minute = execute_minute || 0;
    }
    
    // 重新计算下次执行时间（如果任务处于活跃状态）
    if (currentTask?.status === 'active') {
      const interval = publish_interval || 24;
      const hour = execute_hour !== undefined ? execute_hour : body.current_execute_hour;
      const minute = execute_minute !== undefined ? execute_minute : body.current_execute_minute;
      
      updateData.next_run_at = calculateNextRunTime(interval, hour, minute).toISOString();
    }

    const { data: task, error } = await supabase
      .from('ai_scheduled_tasks')
      .update(updateData)
      .eq('id', id)
      .select()
      .single();

    if (error) {
      console.error('Update task error:', error);
      return NextResponse.json({ error: '更新任务失败' }, { status: 500 });
    }

    return NextResponse.json({ task });
  } catch (error) {
    console.error('Update AI task error:', error);
    return NextResponse.json({ error: '更新任务失败' }, { status: 500 });
  }
}

/**
 * 计算下次执行时间
 */
function calculateNextRunTime(
  intervalHours: number, 
  executeHour?: number | null,
  executeMinute?: number | null
): Date {
  const now = new Date();
  
  // 如果指定了执行时间点（如每天10:00执行）
  if (executeHour !== null && executeHour !== undefined) {
    const nextRun = new Date();
    nextRun.setHours(executeHour, executeMinute || 0, 0, 0);
    
    // 如果今天的执行时间已过，则设置为明天
    if (nextRun <= now) {
      nextRun.setDate(nextRun.getDate() + 1);
    }
    
    return nextRun;
  }
  
  // 否则按间隔计算
  const nextRun = new Date(now.getTime() + intervalHours * 60 * 60 * 1000);
  return nextRun;
}

// 删除任务
export async function DELETE(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const user = await getCurrentUser();
    if (!user || user.role !== 'admin') {
      return NextResponse.json({ error: '权限不足' }, { status: 403 });
    }

    const { id } = await params;
    const supabase = getSupabaseClient();

    const { error } = await supabase
      .from('ai_scheduled_tasks')
      .delete()
      .eq('id', id);

    if (error) {
      console.error('Delete task error:', error);
      return NextResponse.json({ error: '删除任务失败' }, { status: 500 });
    }

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('Delete AI task error:', error);
    return NextResponse.json({ error: '删除任务失败' }, { status: 500 });
  }
}
