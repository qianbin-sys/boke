import { NextRequest, NextResponse } from 'next/server';
import { getCurrentUser } from '@/lib/auth';
import { getSupabaseClient } from '@/storage/database/supabase-client';
import { executeAITask } from '@/lib/ai-task-executor';

// 后台执行任务（不阻塞响应）
async function executeInBackground(taskId: string, userId: string) {
  try {
    console.log(`[Background] Starting task execution: ${taskId}`);
    await executeAITask(taskId, userId);
    console.log(`[Background] Task execution completed: ${taskId}`);
  } catch (error) {
    console.error(`[Background] Task execution failed: ${taskId}`, error);
  }
}

// 任务操作
export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const user = await getCurrentUser();
    if (!user || user.role !== 'admin') {
      return NextResponse.json({ error: '权限不足' }, { status: 403 });
    }

    const { id } = await params;
    const body = await request.json();
    const { action } = body;

    const supabase = getSupabaseClient();

    if (action === 'pause') {
      // 暂停任务
      const { error } = await supabase
        .from('ai_scheduled_tasks')
        .update({ 
          status: 'paused',
          updated_at: new Date().toISOString() 
        })
        .eq('id', id);

      if (error) {
        return NextResponse.json({ error: '暂停任务失败' }, { status: 500 });
      }

      return NextResponse.json({ success: true, status: 'paused' });
    } 
    else if (action === 'resume') {
      // 恢复任务
      const { data: task } = await supabase
        .from('ai_scheduled_tasks')
        .select('publish_interval, execute_hour, execute_minute')
        .eq('id', id)
        .single();

      // 计算下次执行时间
      const nextRunAt = calculateNextRunTime(
        task?.publish_interval || 24,
        task?.execute_hour,
        task?.execute_minute
      );

      const { error } = await supabase
        .from('ai_scheduled_tasks')
        .update({ 
          status: 'active',
          next_run_at: nextRunAt.toISOString(),
          updated_at: new Date().toISOString() 
        })
        .eq('id', id);

      if (error) {
        return NextResponse.json({ error: '恢复任务失败' }, { status: 500 });
      }

      return NextResponse.json({ success: true, status: 'active' });
    }
    else if (action === 'execute') {
      // 检查任务是否存在
      const { data: task, error: taskError } = await supabase
        .from('ai_scheduled_tasks')
        .select('name')
        .eq('id', id)
        .single();

      if (taskError || !task) {
        return NextResponse.json({ error: '任务不存在' }, { status: 404 });
      }

      // 在后台启动执行，不等待结果
      executeInBackground(id, user.userId);

      // 立即返回响应
      return NextResponse.json({ 
        success: true, 
        message: '任务已在后台开始执行',
        taskName: task.name,
      });
    }
    else {
      return NextResponse.json({ error: '未知操作' }, { status: 400 });
    }
  } catch (error) {
    console.error('Task action error:', error);
    return NextResponse.json({ 
      error: error instanceof Error ? error.message : '操作失败' 
    }, { status: 500 });
  }
}

/**
 * 计算下次执行时间
 */
function calculateNextRunTime(
  intervalHours: number, 
  executeHour?: number | null,
  executeMinute?: number | null
): Date {
  const now = new Date();
  
  // 如果指定了执行时间点（如每天10:00执行）
  if (executeHour !== null && executeHour !== undefined) {
    const nextRun = new Date();
    nextRun.setHours(executeHour, executeMinute || 0, 0, 0);
    
    // 如果今天的执行时间已过，则设置为明天
    if (nextRun <= now) {
      nextRun.setDate(nextRun.getDate() + 1);
    }
    
    return nextRun;
  }
  
  // 否则按间隔计算
  const nextRun = new Date(now.getTime() + intervalHours * 60 * 60 * 1000);
  return nextRun;
}
