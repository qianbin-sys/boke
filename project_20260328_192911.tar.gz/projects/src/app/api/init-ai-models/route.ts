import { NextRequest, NextResponse } from 'next/server';
import { getSupabaseClient } from '@/storage/database/supabase-client';

/**
 * 初始化AI模型配置表
 * GET /api/init-ai-models
 */
export async function GET(request: NextRequest) {
  const authHeader = request.headers.get('authorization');
  
  // 简单的授权检查（生产环境应使用更安全的方式）
  if (authHeader !== `Bearer ${process.env.INIT_SECRET || 'init-ai-models-2024'}`) {
    return NextResponse.json({ error: '未授权' }, { status: 401 });
  }

  const supabase = getSupabaseClient();

  try {
    // 检查表是否存在
    const { data: existingModels, error: checkError } = await supabase
      .from('ai_models')
      .select('id')
      .limit(1);

    // 如果表不存在，创建表
    if (checkError && checkError.code === '42P01') {
      console.log('表不存在，开始创建...');
      
      // 注意：Supabase客户端不支持直接执行DDL
      // 需要通过Supabase控制台或迁移工具执行SQL
      // 这里返回SQL脚本让用户手动执行
      
      return NextResponse.json({
        success: false,
        message: '请先执行以下SQL创建表',
        sql: `
-- AI模型配置表
CREATE TABLE IF NOT EXISTS ai_models (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name VARCHAR(255) NOT NULL,
  provider VARCHAR(50) NOT NULL,
  model_type VARCHAR(20) NOT NULL CHECK (model_type IN ('llm', 'image')),
  model_id VARCHAR(255) NOT NULL,
  api_endpoint TEXT,
  api_key_encrypted TEXT,
  config JSONB DEFAULT '{}',
  is_enabled BOOLEAN DEFAULT true,
  is_default BOOLEAN DEFAULT false,
  priority INTEGER DEFAULT 0,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- 创建索引
CREATE INDEX IF NOT EXISTS idx_ai_models_type ON ai_models(model_type);
CREATE INDEX IF NOT EXISTS idx_ai_models_enabled ON ai_models(is_enabled);
CREATE INDEX IF NOT EXISTS idx_ai_models_default ON ai_models(model_type, is_default) WHERE is_default = true;

-- 插入默认豆包模型配置
INSERT INTO ai_models (name, provider, model_type, model_id, is_enabled, is_default, priority)
VALUES 
  ('豆包 Seed 2.0 Pro', 'doubao', 'llm', 'doubao-seed-2-0-pro-260215', true, true, 100),
  ('豆包图片生成', 'doubao', 'image', 'default', true, true, 100);
`
      });
    }

    // 表存在，插入默认数据
    if (!existingModels || existingModels.length === 0) {
      // 插入默认LLM模型
      const { error: llmError } = await supabase
        .from('ai_models')
        .insert({
          name: '豆包 Seed 2.0 Pro',
          provider: 'doubao',
          model_type: 'llm',
          model_id: 'doubao-seed-2-0-pro-260215',
          is_enabled: true,
          is_default: true,
          priority: 100,
        });

      if (llmError && llmError.code !== '23505') { // 忽略唯一约束错误
        console.error('插入LLM模型失败:', llmError);
      }

      // 插入默认图片模型
      const { error: imageError } = await supabase
        .from('ai_models')
        .insert({
          name: '豆包图片生成',
          provider: 'doubao',
          model_type: 'image',
          model_id: 'default',
          is_enabled: true,
          is_default: true,
          priority: 100,
        });

      if (imageError && imageError.code !== '23505') {
        console.error('插入图片模型失败:', imageError);
      }

      return NextResponse.json({
        success: true,
        message: 'AI模型配置表初始化完成，默认模型已创建',
      });
    }

    return NextResponse.json({
      success: true,
      message: 'AI模型配置表已存在',
      modelCount: existingModels.length,
    });
  } catch (error) {
    console.error('初始化失败:', error);
    return NextResponse.json({
      success: false,
      error: error instanceof Error ? error.message : '初始化失败',
    }, { status: 500 });
  }
}
