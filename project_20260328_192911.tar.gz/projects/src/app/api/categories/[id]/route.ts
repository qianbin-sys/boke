import { NextRequest, NextResponse } from 'next/server';
import { getSupabaseClient } from '@/storage/database/supabase-client';
import { getCurrentUser } from '@/lib/auth';

// 更新分类
export async function PUT(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const user = await getCurrentUser();
    if (!user || (user.role !== 'admin' && user.role !== 'editor')) {
      return NextResponse.json({ error: '权限不足' }, { status: 403 });
    }
    
    const { id } = await params;
    const body = await request.json();
    const { name, slug, description, parent_id, sort_order } = body;
    
    const client = getSupabaseClient();
    
    // 检查 slug 是否被其他分类占用
    if (slug) {
      const { data: existingCategory } = await client
        .from('categories')
        .select('id')
        .eq('slug', slug)
        .neq('id', id)
        .maybeSingle();
      
      if (existingCategory) {
        return NextResponse.json({ error: '分类别名已存在' }, { status: 400 });
      }
    }
    
    // 如果指定了父分类，验证父分类
    if (parent_id !== undefined) {
      if (parent_id) {
        // 不能将分类设为自己的子分类
        if (parent_id === id) {
          return NextResponse.json({ error: '不能将分类设为自己的父分类' }, { status: 400 });
        }
        
        // 验证父分类是否存在
        const { data: parentCategory } = await client
          .from('categories')
          .select('id')
          .eq('id', parent_id)
          .maybeSingle();
        
        if (!parentCategory) {
          return NextResponse.json({ error: '父分类不存在' }, { status: 400 });
        }
        
        // 检查是否会形成循环引用（父分类不能是当前分类的子分类）
        const { data: childCategories } = await client
          .from('categories')
          .select('id')
          .eq('parent_id', id);
        
        if (childCategories && childCategories.some(child => child.id === parent_id)) {
          return NextResponse.json({ error: '不能将子分类设为父分类' }, { status: 400 });
        }
      }
    }
    
    const updateData: Record<string, unknown> = {
      updated_at: new Date().toISOString(),
    };
    
    if (name !== undefined) updateData.name = name;
    if (slug !== undefined) updateData.slug = slug;
    if (description !== undefined) updateData.description = description;
    if (parent_id !== undefined) updateData.parent_id = parent_id || null;
    if (sort_order !== undefined) updateData.sort_order = sort_order;
    
    const { data, error } = await client
      .from('categories')
      .update(updateData)
      .eq('id', id)
      .select()
      .single();
    
    if (error) {
      return NextResponse.json({ error: error.message }, { status: 500 });
    }
    
    return NextResponse.json({ category: data });
  } catch (error) {
    console.error('Update category error:', error);
    return NextResponse.json({ error: '更新分类失败' }, { status: 500 });
  }
}

// 删除分类
export async function DELETE(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const user = await getCurrentUser();
    if (!user || user.role !== 'admin') {
      return NextResponse.json({ error: '权限不足' }, { status: 403 });
    }
    
    const { id } = await params;
    const client = getSupabaseClient();
    
    // 检查是否有子分类
    const { data: children } = await client
      .from('categories')
      .select('id')
      .eq('parent_id', id)
      .limit(1);
    
    if (children && children.length > 0) {
      return NextResponse.json({ error: '请先删除子分类' }, { status: 400 });
    }
    
    // 将该分类下的文章移到未分类
    const { data: uncategorized } = await client
      .from('categories')
      .select('id')
      .eq('slug', 'uncategorized')
      .maybeSingle();
    
    if (uncategorized) {
      await client
        .from('posts')
        .update({ category_id: uncategorized.id })
        .eq('category_id', id);
    }
    
    const { error } = await client
      .from('categories')
      .delete()
      .eq('id', id);
    
    if (error) {
      return NextResponse.json({ error: error.message }, { status: 500 });
    }
    
    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('Delete category error:', error);
    return NextResponse.json({ error: '删除分类失败' }, { status: 500 });
  }
}
