import { NextRequest, NextResponse } from 'next/server';
import { getSupabaseClient } from '@/storage/database/supabase-client';
import { getCurrentUser } from '@/lib/auth';

// 获取分类列表
export async function GET() {
  try {
    const client = getSupabaseClient();
    
    const { data, error } = await client
      .from('categories')
      .select('*')
      .order('sort_order', { ascending: true });
    
    if (error) {
      return NextResponse.json({ error: error.message }, { status: 500 });
    }
    
    return NextResponse.json({ categories: data });
  } catch (error) {
    console.error('Get categories error:', error);
    return NextResponse.json({ error: '获取分类列表失败' }, { status: 500 });
  }
}

// 创建分类
export async function POST(request: NextRequest) {
  try {
    const user = await getCurrentUser();
    if (!user || (user.role !== 'admin' && user.role !== 'editor')) {
      return NextResponse.json({ error: '权限不足' }, { status: 403 });
    }
    
    const body = await request.json();
    const { name, slug, description, parent_id } = body;
    
    if (!name || !slug) {
      return NextResponse.json({ error: '名称和别名不能为空' }, { status: 400 });
    }
    
    const client = getSupabaseClient();
    
    // 检查 slug 是否已存在
    const { data: existingCategory } = await client
      .from('categories')
      .select('id')
      .eq('slug', slug)
      .maybeSingle();
    
    if (existingCategory) {
      return NextResponse.json({ error: '分类别名已存在' }, { status: 400 });
    }
    
    // 如果指定了父分类，验证父分类是否存在
    if (parent_id) {
      const { data: parentCategory } = await client
        .from('categories')
        .select('id')
        .eq('id', parent_id)
        .maybeSingle();
      
      if (!parentCategory) {
        return NextResponse.json({ error: '父分类不存在' }, { status: 400 });
      }
    }
    
    const { data, error } = await client
      .from('categories')
      .insert({
        name,
        slug,
        description,
        parent_id: parent_id || null,
      })
      .select()
      .single();
    
    if (error) {
      return NextResponse.json({ error: error.message }, { status: 500 });
    }
    
    return NextResponse.json({ category: data });
  } catch (error) {
    console.error('Create category error:', error);
    return NextResponse.json({ error: '创建分类失败' }, { status: 500 });
  }
}
