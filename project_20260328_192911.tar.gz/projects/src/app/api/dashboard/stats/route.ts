import { NextResponse } from 'next/server';
import { getSupabaseClient } from '@/storage/database/supabase-client';
import { getCurrentUser } from '@/lib/auth';

export async function GET() {
  try {
    const user = await getCurrentUser();
    if (!user || user.role !== 'admin') {
      return NextResponse.json({ error: '权限不足' }, { status: 403 });
    }

    const client = getSupabaseClient();

    // 获取基础统计数据
    const [
      postsResult,
      usersResult,
      categoriesResult,
      tagsResult,
      ordersResult,
      membersResult,
      commentsResult,
      recentPostsResult,
      recentOrdersResult,
    ] = await Promise.all([
      // 文章统计
      client.from('posts').select('id, status, view_count', { count: 'exact' }),
      // 用户统计
      client.from('users').select('id', { count: 'exact' }),
      // 分类统计
      client.from('categories').select('id', { count: 'exact' }),
      // 标签统计
      client.from('tags').select('id', { count: 'exact' }),
      // 订单统计
      client.from('orders').select('amount, payment_status'),
      // 会员统计
      client.from('user_memberships').select('user_id, status'),
      // 评论统计
      client.from('comments').select('id, status', { count: 'exact' }),
      // 最近文章
      client.from('posts')
        .select('id, title, slug, status, view_count, created_at, published_at, categories(name)')
        .order('created_at', { ascending: false })
        .limit(5),
      // 最近订单
      client.from('orders')
        .select('id, order_no, amount, payment_status, created_at, users(username, display_name)')
        .order('created_at', { ascending: false })
        .limit(5),
    ]);

    // 计算文章统计
    const totalPosts = postsResult.count || 0;
    const publishedPosts = (postsResult.data || []).filter(p => p.status === 'published').length;
    const draftPosts = (postsResult.data || []).filter(p => p.status === 'draft').length;
    const totalViews = (postsResult.data || []).reduce((sum, p) => sum + (p.view_count || 0), 0);

    // 计算订单统计
    const orders = ordersResult.data || [];
    const totalOrders = orders.length;
    const paidOrders = orders.filter(o => o.payment_status === 'paid');
    const totalRevenue = paidOrders.reduce((sum, o) => sum + parseFloat(o.amount || '0'), 0);

    // 计算会员统计
    const memberships = membersResult.data || [];
    const activeMembers = memberships.filter(m => m.status === 'active').length;

    // 计算评论统计
    const totalComments = commentsResult.count || 0;
    const pendingComments = (commentsResult.data || []).filter(c => c.status === 'pending').length;

    // 获取最近30天的文章发布趋势
    const thirtyDaysAgo = new Date();
    thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);
    
    const { data: trendData } = await client
      .from('posts')
      .select('created_at')
      .eq('status', 'published')
      .gte('created_at', thirtyDaysAgo.toISOString());

    // 按日期统计
    const postsByDate: Record<string, number> = {};
    (trendData || []).forEach(post => {
      const date = new Date(post.created_at).toLocaleDateString('zh-CN');
      postsByDate[date] = (postsByDate[date] || 0) + 1;
    });

    // 生成最近7天的数据
    const last7Days = [];
    for (let i = 6; i >= 0; i--) {
      const date = new Date();
      date.setDate(date.getDate() - i);
      const dateStr = date.toLocaleDateString('zh-CN');
      last7Days.push({
        date: dateStr,
        count: postsByDate[dateStr] || 0,
      });
    }

    return NextResponse.json({
      overview: {
        totalPosts,
        publishedPosts,
        draftPosts,
        totalViews,
        totalUsers: usersResult.count || 0,
        totalCategories: categoriesResult.count || 0,
        totalTags: tagsResult.count || 0,
        totalOrders,
        totalRevenue: totalRevenue.toFixed(2),
        activeMembers,
        totalComments,
        pendingComments,
      },
      chart: {
        last7Days,
      },
      recentPosts: recentPostsResult.data || [],
      recentOrders: recentOrdersResult.data || [],
    });
  } catch (error) {
    console.error('Dashboard stats error:', error);
    return NextResponse.json({ error: '获取统计数据失败' }, { status: 500 });
  }
}
