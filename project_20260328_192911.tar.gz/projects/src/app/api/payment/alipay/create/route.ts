import { NextRequest, NextResponse } from 'next/server';
import { getSupabaseClient } from '@/storage/database/supabase-client';
import { getCurrentUser } from '@/lib/auth';
import { AlipaySdk } from 'alipay-sdk';

// 创建支付宝支付订单 - 当面付（生成二维码）
export async function POST(request: NextRequest) {
  try {
    const user = await getCurrentUser();
    if (!user) {
      return NextResponse.json({ error: '请先登录' }, { status: 401 });
    }

    const body = await request.json();
    const { orderId } = body;

    if (!orderId) {
      return NextResponse.json({ error: '缺少订单ID' }, { status: 400 });
    }

    // 获取支付宝配置
    const supabase = getSupabaseClient();
    const { data: alipayConfig, error: configError } = await supabase
      .from('payment_configs')
      .select('config, is_enabled')
      .eq('payment_method', 'alipay')
      .single();

    if (configError || !alipayConfig || !alipayConfig.is_enabled) {
      return NextResponse.json({ error: '支付宝支付未启用' }, { status: 400 });
    }

    const config = alipayConfig.config as Record<string, string>;
    const appId = config.app_id;
    const privateKey = config.private_key;
    const alipayPublicKey = config.public_key;
    const notifyUrl = config.notify_url;
    const mode = config.mode || 'sandbox';
    
    console.log('Alipay config mode:', mode, 'appId:', appId);

    if (!appId || !privateKey) {
      return NextResponse.json({ error: '支付宝配置不完整，请检查AppId和私钥' }, { status: 400 });
    }

    // 获取订单信息
    const { data: order, error: orderError } = await supabase
      .from('orders')
      .select('id, order_no, amount, metadata')
      .eq('id', orderId)
      .eq('user_id', user.userId)
      .eq('payment_status', 'pending')
      .single();

    if (orderError || !order) {
      return NextResponse.json({ error: '订单不存在或已支付' }, { status: 400 });
    }

    const metadata = order.metadata as Record<string, unknown> || {};
    const planName = metadata.plan_name as string | undefined;
    const postTitle = metadata.post_title as string | undefined;

    // 确定订单描述
    const subject = planName 
      ? `会员订阅 - ${planName}` 
      : postTitle 
        ? `文章购买 - ${postTitle}` 
        : '网站订阅服务';

    // 初始化支付宝SDK
    // 注意：如果不传 alipayPublicKey，SDK 会跳过验签（测试环境可用）
    // 生产环境请确保 alipayPublicKey 是最新的支付宝公钥
    const alipaySdk = new AlipaySdk({
      appId,
      privateKey,
      alipayPublicKey: alipayPublicKey || undefined, // 如果为空则跳过验签
      gateway: mode === 'live'
        ? 'https://openapi.alipay.com/gateway.do'
        : 'https://openapi-sandbox.dl.alipaydev.com/gateway.do',
    });

    // 使用 curl 方法调用当面付预创建接口 (API v3 协议)
    // 文档: https://opendocs.alipay.com/open-v3/08c7f9f8_alipay.trade.precreate
    let result;
    try {
      result = await alipaySdk.curl('POST', '/v3/alipay/trade/precreate', {
        body: {
          out_trade_no: order.order_no,
          total_amount: parseFloat(order.amount).toFixed(2),
          subject: subject,
          product_code: 'QR_CODE_OFFLINE', // 当面付产品码
          timeout_express: '30m', // 30分钟超时
          notify_url: notifyUrl, // 异步通知地址
        }
      });
    } catch (execError) {
      // 即使验签失败，接口可能已经成功返回了 qr_code
      // 检查错误信息中是否包含 qr_code
      const errorMsg = execError instanceof Error ? execError.message : '';
      console.error('Alipay curl error:', errorMsg);
      
      // 尝试从错误信息中提取 qr_code
      const qrCodeMatch = errorMsg.match(/"qr_code":"([^"]+)"/);
      if (qrCodeMatch) {
        const qrCode = qrCodeMatch[1];
        console.log('Extracted qr_code from error:', qrCode);
        return NextResponse.json({
          success: true,
          qrCode: qrCode,
          orderId: order.id,
          orderNo: order.order_no,
          amount: order.amount,
          mode,
          warning: '支付宝公钥可能需要更新，请检查后台配置',
        });
      }
      
      return NextResponse.json({ 
        error: `支付宝接口调用失败: ${errorMsg}` 
      }, { status: 500 });
    }

    console.log('Alipay precreate result:', JSON.stringify(result, null, 2));

    // 检查结果
    if (!result || !result.data) {
      return NextResponse.json({ error: '支付宝返回结果为空' }, { status: 500 });
    }

    const data = result.data;
    const qrCode = data.qr_code;
    
    // 检查是否有错误
    if (data.code && data.code !== '10000') {
      return NextResponse.json({ 
        error: data.sub_msg || data.msg || '创建支付订单失败',
        code: data.code 
      }, { status: 400 });
    }

    if (!qrCode) {
      console.error('No qr_code in result:', data);
      return NextResponse.json({ error: '未获取到支付二维码' }, { status: 500 });
    }

    // 返回二维码链接
    return NextResponse.json({
      success: true,
      qrCode: qrCode,
      orderId: order.id,
      orderNo: order.order_no,
      amount: order.amount,
      mode,
    });
  } catch (error) {
    console.error('Create alipay order error:', error);
    return NextResponse.json({ 
      error: error instanceof Error ? error.message : '创建支付订单失败' 
    }, { status: 500 });
  }
}
