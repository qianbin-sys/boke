import { NextRequest, NextResponse } from 'next/server';
import { getSupabaseClient } from '@/storage/database/supabase-client';
import { AlipaySdk } from 'alipay-sdk';
import { handlePaymentSuccess } from '@/lib/payment';

// 支付宝异步通知回调
export async function POST(request: NextRequest) {
  try {
    // 获取回调数据
    const formData = await request.formData();
    const params: Record<string, string> = {};
    
    formData.forEach((value, key) => {
      params[key] = value.toString();
    });

    // 获取支付宝配置
    const supabase = getSupabaseClient();
    const { data: alipayConfig } = await supabase
      .from('payment_configs')
      .select('config')
      .eq('payment_method', 'alipay')
      .single();

    if (!alipayConfig) {
      console.error('Alipay config not found');
      return new NextResponse('fail', { status: 400 });
    }

    const config = alipayConfig.config as Record<string, string>;
    
    // 初始化支付宝SDK验证签名
    const alipaySdk = new AlipaySdk({
      appId: config.app_id,
      privateKey: config.private_key,
      alipayPublicKey: config.public_key,
    });

    // 验证签名
    const signVerified = alipaySdk.checkNotifySign(params);
    
    if (!signVerified) {
      console.error('Alipay sign verification failed');
      return new NextResponse('fail', { status: 400 });
    }

    // 获取订单号和交易状态
    const outTradeNo = params.out_trade_no;
    const tradeStatus = params.trade_status;
    const tradeNo = params.trade_no;

    if (!outTradeNo) {
      console.error('Missing out_trade_no');
      return new NextResponse('fail', { status: 400 });
    }

    // 获取订单
    const { data: order, error: orderError } = await supabase
      .from('orders')
      .select('id')
      .eq('order_no', outTradeNo)
      .single();

    if (orderError || !order) {
      console.error('Order not found:', outTradeNo);
      return new NextResponse('fail', { status: 400 });
    }

    // 检查交易状态
    if (tradeStatus === 'TRADE_SUCCESS' || tradeStatus === 'TRADE_FINISHED') {
      // 使用统一的支付成功处理函数
      const result = await handlePaymentSuccess(order.id, tradeNo, 'alipay');
      
      if (!result.success) {
        console.error('Handle payment success error:', result.error);
        return new NextResponse('fail', { status: 500 });
      }
    }

    return new NextResponse('success');
  } catch (error) {
    console.error('Alipay notify error:', error);
    return new NextResponse('fail', { status: 500 });
  }
}
