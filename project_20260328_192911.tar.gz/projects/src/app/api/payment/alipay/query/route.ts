import { NextRequest, NextResponse } from 'next/server';
import { getSupabaseClient } from '@/storage/database/supabase-client';
import { getCurrentUser } from '@/lib/auth';
import { AlipaySdk } from 'alipay-sdk';
import { handlePaymentSuccess } from '@/lib/payment';

// 主动查询支付宝订单状态
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { orderNo, orderId } = body;

    console.log('Alipay query request:', { orderNo, orderId });

    // 支持通过订单ID或订单号查询
    let targetOrderNo = orderNo;
    let targetOrderId = orderId;

    // 如果只传了订单ID，先查询订单号
    if (!targetOrderNo && targetOrderId) {
      const client = getSupabaseClient();
      const { data: order, error } = await client
        .from('orders')
        .select('id, order_no, payment_status')
        .eq('id', targetOrderId)
        .single();

      if (error || !order) {
        return NextResponse.json({ error: '订单不存在' }, { status: 400 });
      }

      // 如果订单已支付，直接返回成功
      if (order.payment_status === 'paid') {
        return NextResponse.json({ 
          success: true, 
          paid: true,
          message: '订单已支付' 
        });
      }

      targetOrderNo = order.order_no;
    }

    if (!targetOrderNo) {
      return NextResponse.json({ error: '缺少订单号或订单ID' }, { status: 400 });
    }

    // 验证用户（可选，不强制要求登录以支持轮询）
    const user = await getCurrentUser().catch(() => null);

    // 获取支付宝配置
    const supabase = getSupabaseClient();
    const { data: alipayConfig, error: configError } = await supabase
      .from('payment_configs')
      .select('config, is_enabled')
      .eq('payment_method', 'alipay')
      .single();

    if (configError || !alipayConfig || !alipayConfig.is_enabled) {
      return NextResponse.json({ error: '支付宝支付未启用' }, { status: 400 });
    }

    const config = alipayConfig.config as Record<string, string>;
    const appId = config.app_id;
    const privateKey = config.private_key;
    const alipayPublicKey = config.public_key;
    const mode = config.mode || 'sandbox';

    if (!appId || !privateKey) {
      return NextResponse.json({ error: '支付宝配置不完整' }, { status: 400 });
    }

    // 获取订单信息（不强制要求用户登录匹配，只通过订单号查询）
    const { data: order, error: orderError } = await supabase
      .from('orders')
      .select('id, order_no, payment_status, user_id')
      .eq('order_no', targetOrderNo)
      .single();

    if (orderError || !order) {
      console.error('Order not found:', targetOrderNo, orderError);
      return NextResponse.json({ error: '订单不存在' }, { status: 400 });
    }

    // 如果订单已经支付成功，直接返回
    if (order.payment_status === 'paid') {
      return NextResponse.json({ 
        success: true, 
        paid: true,
        message: '订单已支付' 
      });
    }

    // 初始化支付宝SDK
    const alipaySdk = new AlipaySdk({
      appId,
      privateKey,
      alipayPublicKey: alipayPublicKey || undefined,
      gateway: mode === 'live'
        ? 'https://openapi.alipay.com/gateway.do'
        : 'https://openapi-sandbox.dl.alipaydev.com/gateway.do',
    });

    // 调用支付宝交易查询接口
    let result;
    try {
      result = await alipaySdk.curl('GET', '/v3/alipay/trade/query', {
        query: {
          out_trade_no: targetOrderNo,
        }
      });
    } catch (queryError) {
      const errorMsg = queryError instanceof Error ? queryError.message : '';
      console.error('Alipay query error:', errorMsg);
      
      // 尝试从错误信息中提取交易状态
      const tradeStatusMatch = errorMsg.match(/"trade_status":"([^"]+)"/);
      if (tradeStatusMatch) {
        const tradeStatus = tradeStatusMatch[1];
        console.log('Extracted trade_status from error:', tradeStatus);
        
        if (tradeStatus === 'TRADE_SUCCESS' || tradeStatus === 'TRADE_FINISHED') {
          // 支付成功，更新订单状态
          const tradeNoMatch = errorMsg.match(/"trade_no":"([^"]+)"/);
          const tradeNo = tradeNoMatch ? tradeNoMatch[1] : '';
          
          await handlePaymentSuccess(order.id, tradeNo, 'alipay');
          
          return NextResponse.json({ 
            success: true, 
            paid: true,
            message: '支付成功' 
          });
        }
      }
      
      return NextResponse.json({ 
        success: false, 
        paid: false,
        error: errorMsg 
      }, { status: 500 });
    }

    console.log('Alipay query result:', JSON.stringify(result, null, 2));

    // 检查查询结果
    if (!result || !result.data) {
      return NextResponse.json({ 
        success: false, 
        paid: false,
        error: '查询结果为空' 
      });
    }

    const data = result.data;
    const tradeStatus = data.trade_status;

    // 检查交易状态
    if (tradeStatus === 'TRADE_SUCCESS' || tradeStatus === 'TRADE_FINISHED') {
      // 支付成功，更新订单状态
      await handlePaymentSuccess(order.id, data.trade_no, 'alipay');
      
      return NextResponse.json({ 
        success: true, 
        paid: true,
        message: '支付成功' 
      });
    }

    // 其他状态（如 WAIT_BUYER_PAY）返回未支付
    return NextResponse.json({ 
      success: true, 
      paid: false,
      tradeStatus: tradeStatus,
      message: data.sub_msg || data.msg || '等待支付' 
    });

  } catch (error) {
    console.error('Alipay query error:', error);
    return NextResponse.json({ 
      error: error instanceof Error ? error.message : '查询失败' 
    }, { status: 500 });
  }
}
