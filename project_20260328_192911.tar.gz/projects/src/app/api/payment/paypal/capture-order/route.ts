import { NextRequest, NextResponse } from 'next/server';
import { getSupabaseClient } from '@/storage/database/supabase-client';
import { getCurrentUser } from '@/lib/auth';
import { handlePaymentSuccess } from '@/lib/payment';

// 获取PayPal Access Token
async function getPayPalAccessToken(clientId: string, clientSecret: string, mode: string): Promise<string> {
  const baseUrl = mode === 'live' 
    ? 'https://api-m.paypal.com' 
    : 'https://api-m.sandbox.paypal.com';
  
  const auth = Buffer.from(`${clientId}:${clientSecret}`).toString('base64');
  
  const response = await fetch(`${baseUrl}/v1/oauth2/token`, {
    method: 'POST',
    headers: {
      'Authorization': `Basic ${auth}`,
      'Content-Type': 'application/x-www-form-urlencoded',
    },
    body: 'grant_type=client_credentials',
  });

  if (!response.ok) {
    const errorText = await response.text();
    throw new Error(`Failed to get PayPal access token: ${errorText}`);
  }

  const data = await response.json();
  return data.access_token;
}

// 捕获PayPal支付
export async function POST(request: NextRequest) {
  try {
    const user = await getCurrentUser();
    if (!user) {
      return NextResponse.json({ error: '请先登录' }, { status: 401 });
    }

    const body = await request.json();
    const { paypalOrderId, orderId } = body;

    if (!paypalOrderId || !orderId) {
      return NextResponse.json({ error: '缺少订单信息' }, { status: 400 });
    }

    // 获取PayPal配置
    const supabase = getSupabaseClient();
    const { data: paypalConfig, error: configError } = await supabase
      .from('payment_configs')
      .select('config, is_enabled')
      .eq('payment_method', 'paypal')
      .single();

    if (configError || !paypalConfig || !paypalConfig.is_enabled) {
      return NextResponse.json({ error: 'PayPal支付未启用' }, { status: 400 });
    }

    const config = paypalConfig.config as Record<string, string>;
    const clientId = config.client_id;
    const clientSecret = config.client_secret;
    const mode = config.mode || 'sandbox';

    if (!clientId || !clientSecret) {
      return NextResponse.json({ error: 'PayPal配置不完整' }, { status: 400 });
    }

    // 获取Access Token
    const accessToken = await getPayPalAccessToken(clientId, clientSecret, mode);
    
    // 捕获PayPal订单
    const baseUrl = mode === 'live' 
      ? 'https://api-m.paypal.com' 
      : 'https://api-m.sandbox.paypal.com';

    const response = await fetch(`${baseUrl}/v2/checkout/orders/${paypalOrderId}/capture`, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${accessToken}`,
        'Content-Type': 'application/json',
      },
    });

    if (!response.ok) {
      const errorText = await response.text();
      console.error('PayPal capture order error:', errorText);
      return NextResponse.json({ error: '支付捕获失败' }, { status: 500 });
    }

    const captureResult = await response.json();

    // 验证支付状态
    if (captureResult.status !== 'COMPLETED') {
      return NextResponse.json({ error: '支付未完成', status: captureResult.status }, { status: 400 });
    }

    // 使用统一的支付成功处理函数
    const result = await handlePaymentSuccess(orderId, paypalOrderId, 'paypal');

    if (!result.success) {
      return NextResponse.json({ error: result.error || '处理支付失败' }, { status: 500 });
    }

    return NextResponse.json({
      success: true,
      status: 'COMPLETED',
    });
  } catch (error) {
    console.error('Capture PayPal order error:', error);
    return NextResponse.json({ 
      error: error instanceof Error ? error.message : '支付处理失败' 
    }, { status: 500 });
  }
}
