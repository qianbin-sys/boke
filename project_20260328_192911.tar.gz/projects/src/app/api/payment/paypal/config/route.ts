import { NextResponse } from 'next/server';
import { getSupabaseClient } from '@/storage/database/supabase-client';

// 获取PayPal配置（仅返回Client ID，不返回Secret）
export async function GET() {
  try {
    const client = getSupabaseClient();
    
    const { data, error } = await client
      .from('payment_configs')
      .select('config, is_enabled')
      .eq('payment_method', 'paypal')
      .single();
    
    if (error || !data) {
      return NextResponse.json({ 
        enabled: false,
        clientId: null 
      });
    }

    const config = data.config as Record<string, string>;
    
    return NextResponse.json({
      enabled: data.is_enabled,
      clientId: config?.client_id || null,
      mode: config?.mode || 'sandbox',
    });
  } catch (error) {
    console.error('Get PayPal config error:', error);
    return NextResponse.json({ 
      enabled: false,
      clientId: null 
    });
  }
}
