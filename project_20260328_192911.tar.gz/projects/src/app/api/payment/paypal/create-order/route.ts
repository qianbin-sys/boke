import { NextRequest, NextResponse } from 'next/server';
import { getSupabaseClient } from '@/storage/database/supabase-client';
import { getCurrentUser } from '@/lib/auth';

// 获取PayPal Access Token
async function getPayPalAccessToken(clientId: string, clientSecret: string, mode: string): Promise<string> {
  const baseUrl = mode === 'live' 
    ? 'https://api-m.paypal.com' 
    : 'https://api-m.sandbox.paypal.com';
  
  const auth = Buffer.from(`${clientId}:${clientSecret}`).toString('base64');
  
  const response = await fetch(`${baseUrl}/v1/oauth2/token`, {
    method: 'POST',
    headers: {
      'Authorization': `Basic ${auth}`,
      'Content-Type': 'application/x-www-form-urlencoded',
    },
    body: 'grant_type=client_credentials',
  });

  if (!response.ok) {
    const errorText = await response.text();
    throw new Error(`Failed to get PayPal access token: ${errorText}`);
  }

  const data = await response.json();
  return data.access_token;
}

// 创建PayPal订单
export async function POST(request: NextRequest) {
  try {
    const user = await getCurrentUser();
    if (!user) {
      return NextResponse.json({ error: '请先登录' }, { status: 401 });
    }

    const body = await request.json();
    const { orderId } = body; // 我们系统中的订单ID

    if (!orderId) {
      return NextResponse.json({ error: '缺少订单ID' }, { status: 400 });
    }

    // 获取PayPal配置
    const supabase = getSupabaseClient();
    const { data: paypalConfig, error: configError } = await supabase
      .from('payment_configs')
      .select('config, is_enabled')
      .eq('payment_method', 'paypal')
      .single();

    if (configError || !paypalConfig || !paypalConfig.is_enabled) {
      return NextResponse.json({ error: 'PayPal支付未启用' }, { status: 400 });
    }

    const config = paypalConfig.config as Record<string, string>;
    const clientId = config.client_id;
    const clientSecret = config.client_secret;
    const mode = config.mode || 'sandbox';

    if (!clientId || !clientSecret) {
      return NextResponse.json({ error: 'PayPal配置不完整' }, { status: 400 });
    }

    // 获取订单信息
    const { data: order, error: orderError } = await supabase
      .from('orders')
      .select('id, amount, metadata')
      .eq('id', orderId)
      .eq('user_id', user.userId)
      .eq('payment_status', 'pending')
      .single();

    if (orderError || !order) {
      console.error('Order not found:', orderError);
      return NextResponse.json({ error: '订单不存在或已支付' }, { status: 400 });
    }

    const metadata = order.metadata as Record<string, unknown> || {};
    const planName = metadata.plan_name as string | undefined;
    const postTitle = metadata.post_title as string | undefined;

    // 获取Access Token
    const accessToken = await getPayPalAccessToken(clientId, clientSecret, mode);
    
    // 创建PayPal订单
    const baseUrl = mode === 'live' 
      ? 'https://api-m.paypal.com' 
      : 'https://api-m.sandbox.paypal.com';

    // PayPal不支持CNY，使用USD（汇率约7.2）
    const cnyAmount = parseFloat(order.amount);
    const exchangeRate = 0.14; // 1 CNY ≈ 0.14 USD (汇率可配置)
    const usdAmount = (cnyAmount * exchangeRate).toFixed(2);

    // 确定订单描述
    const description = planName 
      ? `会员订阅 - ${planName}` 
      : postTitle 
        ? `文章购买 - ${postTitle}` 
        : '网站订阅服务';

    const paypalOrderData = {
      intent: 'CAPTURE',
      purchase_units: [
        {
          reference_id: order.id,
          description,
          amount: {
            currency_code: 'USD',
            value: usdAmount,
          },
        },
      ],
    };

    const response = await fetch(`${baseUrl}/v2/checkout/orders`, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${accessToken}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(paypalOrderData),
    });

    if (!response.ok) {
      const errorText = await response.text();
      console.error('PayPal create order error:', errorText);
      return NextResponse.json({ error: '创建PayPal订单失败' }, { status: 500 });
    }

    const paypalOrder = await response.json();

    return NextResponse.json({
      paypalOrderId: paypalOrder.id,
      status: paypalOrder.status,
    });
  } catch (error) {
    console.error('Create PayPal order error:', error);
    return NextResponse.json({ 
      error: error instanceof Error ? error.message : '创建订单失败' 
    }, { status: 500 });
  }
}
