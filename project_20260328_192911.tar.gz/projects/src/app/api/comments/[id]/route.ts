import { NextRequest, NextResponse } from 'next/server';
import { getSupabaseClient } from '@/storage/database/supabase-client';
import { getCurrentUser } from '@/lib/auth';

// 获取单条评论
export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const client = getSupabaseClient();

    const { data, error } = await client
      .from('comments')
      .select(`
        id,
        content,
        status,
        created_at,
        user_id,
        post_id,
        parent_id,
        users (id, username, display_name, avatar_url),
        posts (id, title, slug)
      `)
      .eq('id', id)
      .single();

    if (error) {
      return NextResponse.json({ error: '评论不存在' }, { status: 404 });
    }

    return NextResponse.json({ comment: data });
  } catch (error) {
    console.error('Get comment error:', error);
    return NextResponse.json({ error: '获取评论失败' }, { status: 500 });
  }
}

// 更新评论状态（审核）
export async function PATCH(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const user = await getCurrentUser();
    if (!user || user.role !== 'admin') {
      return NextResponse.json({ error: '权限不足' }, { status: 403 });
    }

    const { id } = await params;
    const body = await request.json();
    const { status } = body;

    if (!['pending', 'approved', 'rejected', 'spam'].includes(status)) {
      return NextResponse.json({ error: '无效的评论状态' }, { status: 400 });
    }

    const client = getSupabaseClient();

    const { data, error } = await client
      .from('comments')
      .update({ status })
      .eq('id', id)
      .select()
      .single();

    if (error) {
      return NextResponse.json({ error: '更新失败' }, { status: 500 });
    }

    return NextResponse.json({ comment: data });
  } catch (error) {
    console.error('Update comment error:', error);
    return NextResponse.json({ error: '更新失败' }, { status: 500 });
  }
}

// 删除评论
export async function DELETE(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const user = await getCurrentUser();
    if (!user || user.role !== 'admin') {
      return NextResponse.json({ error: '权限不足' }, { status: 403 });
    }

    const { id } = await params;
    const client = getSupabaseClient();

    const { error } = await client
      .from('comments')
      .delete()
      .eq('id', id);

    if (error) {
      return NextResponse.json({ error: '删除失败' }, { status: 500 });
    }

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('Delete comment error:', error);
    return NextResponse.json({ error: '删除失败' }, { status: 500 });
  }
}
