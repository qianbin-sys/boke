import { NextRequest, NextResponse } from 'next/server';
import { getSupabaseClient } from '@/storage/database/supabase-client';
import { getCurrentUser } from '@/lib/auth';

// 获取评论列表
export async function GET(request: NextRequest) {
  try {
    const client = getSupabaseClient();
    const searchParams = request.nextUrl.searchParams;
    
    const postId = searchParams.get('post_id');
    const status = searchParams.get('status');
    const page = parseInt(searchParams.get('page') || '1');
    const limit = parseInt(searchParams.get('limit') || '20');
    const offset = (page - 1) * limit;

    let query = client
      .from('comments')
      .select(`
        id,
        content,
        status,
        created_at,
        user_id,
        post_id,
        parent_id,
        users (id, username, display_name, avatar_url),
        posts (id, title, slug)
      `)
      .order('created_at', { ascending: false })
      .range(offset, offset + limit - 1);

    if (postId) {
      query = query.eq('post_id', postId);
    }

    if (status) {
      query = query.eq('status', status);
    }

    const { data, error, count } = await query;

    if (error) {
      return NextResponse.json({ error: '获取评论失败' }, { status: 500 });
    }

    return NextResponse.json({
      comments: data,
      total: count,
      page,
      limit,
    });
  } catch (error) {
    console.error('Get comments error:', error);
    return NextResponse.json({ error: '获取评论失败' }, { status: 500 });
  }
}

// 创建评论
export async function POST(request: NextRequest) {
  try {
    const user = await getCurrentUser();
    if (!user) {
      return NextResponse.json({ error: '请先登录' }, { status: 401 });
    }

    const body = await request.json();
    const { post_id, content, parent_id } = body;

    if (!post_id || !content || !content.trim()) {
      return NextResponse.json({ error: '文章ID和评论内容不能为空' }, { status: 400 });
    }

    const client = getSupabaseClient();

    // 检查文章是否存在
    const { data: post } = await client
      .from('posts')
      .select('id')
      .eq('id', post_id)
      .single();

    if (!post) {
      return NextResponse.json({ error: '文章不存在' }, { status: 404 });
    }

    // 如果是回复，检查父评论是否存在
    if (parent_id) {
      const { data: parent } = await client
        .from('comments')
        .select('id')
        .eq('id', parent_id)
        .single();

      if (!parent) {
        return NextResponse.json({ error: '父评论不存在' }, { status: 404 });
      }
    }

    // 创建评论（默认需要审核）
    const { data, error } = await client
      .from('comments')
      .insert({
        post_id,
        user_id: user.userId,
        content: content.trim(),
        parent_id,
        status: 'pending', // 默认待审核
      })
      .select(`
        id,
        content,
        status,
        created_at,
        users (id, username, display_name, avatar_url)
      `)
      .single();

    if (error) {
      console.error('Create comment error:', error);
      return NextResponse.json({ error: '评论失败' }, { status: 500 });
    }

    return NextResponse.json({ comment: data });
  } catch (error) {
    console.error('Create comment error:', error);
    return NextResponse.json({ error: '评论失败' }, { status: 500 });
  }
}
