import { getSupabaseClient } from '@/storage/database/supabase-client';
import Link from 'next/link';
import { notFound } from 'next/navigation';
import { Hash, ChevronRight } from 'lucide-react';

interface Props {
  params: Promise<{ slug: string }>;
  searchParams: Promise<{ page?: string }>;
}

interface PostCategory {
  id: string;
  name: string;
  slug: string;
}

interface PostListItem {
  id: string;
  title: string;
  slug: string;
  excerpt: string | null;
  featured_image: string | null;
  view_count: number;
  published_at: string | null;
  created_at: string;
  categories: PostCategory | null;
  users: {
    id: string;
    username: string;
    display_name: string | null;
  } | null;
}

async function getTag(slug: string) {
  const client = getSupabaseClient();
  
  const { data: tag, error } = await client
    .from('tags')
    .select('id, name, slug')
    .eq('slug', slug)
    .maybeSingle();

  if (error || !tag) return null;
  return tag;
}

async function getPostsByTag(tagId: string, page: number = 1): Promise<{ posts: PostListItem[]; total: number; totalPages: number }> {
  const client = getSupabaseClient();
  const pageSize = 10;

  // 获取文章ID列表
  const { data: postTags } = await client
    .from('post_tags')
    .select('post_id')
    .eq('tag_id', tagId);

  if (!postTags || postTags.length === 0) {
    return { posts: [], total: 0, totalPages: 0 };
  }

  const postIds = postTags.map(pt => pt.post_id);

  const { data: posts, error, count } = await client
    .from('posts')
    .select(`
      id,
      title,
      slug,
      excerpt,
      featured_image,
      view_count,
      published_at,
      created_at,
      categories(id, name, slug),
      users!posts_author_id_users_id_fk(id, username, display_name)
    `, { count: 'exact' })
    .eq('status', 'published')
    .in('id', postIds)
    .order('published_at', { ascending: false })
    .range((page - 1) * pageSize, page * pageSize - 1);

  if (error) {
    console.error('Failed to fetch posts:', error);
    return { posts: [], total: 0, totalPages: 0 };
  }

  // 格式化数据
  const formattedPosts: PostListItem[] = (posts || []).map(post => ({
    ...post,
    categories: Array.isArray(post.categories) ? post.categories[0] || null : post.categories,
    users: Array.isArray(post.users) ? post.users[0] || null : post.users,
  }));

  return {
    posts: formattedPosts,
    total: count || 0,
    totalPages: Math.ceil((count || 0) / pageSize),
  };
}

export default async function TagPage({ params, searchParams }: Props) {
  const { slug } = await params;
  const { page } = await searchParams;
  const currentPage = parseInt(page || '1');

  const tag = await getTag(slug);
  if (!tag) {
    notFound();
  }

  const { posts, total, totalPages } = await getPostsByTag(tag.id, currentPage);

  return (
    <div className="max-w-4xl mx-auto">
      {/* Header */}
      <div className="mb-8">
        <nav className="flex items-center gap-2 text-sm text-[#64748b] dark:text-[#94a3b8] mb-4">
          <Link href="/" className="hover:text-[#0ea5e9] transition-colors">首页</Link>
          <ChevronRight className="w-4 h-4" />
          <Link href="/tags" className="hover:text-[#0ea5e9] transition-colors">标签</Link>
          <ChevronRight className="w-4 h-4" />
          <span className="text-[#1e293b] dark:text-white">{tag.name}</span>
        </nav>
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 bg-[#0ea5e9]/10 dark:bg-[#0ea5e9]/20 rounded-xl flex items-center justify-center">
            <Hash className="w-6 h-6 text-[#0ea5e9]" />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-[#1e293b] dark:text-white">
              {tag.name}
            </h1>
            <p className="text-sm text-[#64748b] dark:text-[#94a3b8]">
              共 {total} 篇文章
            </p>
          </div>
        </div>
      </div>

      {/* Posts List */}
      {posts.length === 0 ? (
        <div className="text-center py-16 bg-white dark:bg-[#1e293b] rounded-xl border border-[#e2e8f0] dark:border-[#334155]">
          <p className="text-gray-500 dark:text-gray-400">该标签下暂无文章</p>
        </div>
      ) : (
        <div className="space-y-4">
          {posts.map((post) => (
            <Link
              key={post.id}
              href={`/post/${post.slug}`}
              className="block bg-white dark:bg-[#1e293b] border border-[#e2e8f0] dark:border-[#334155] rounded-xl overflow-hidden hover:border-[#0ea5e9]/50 hover:shadow-lg transition-all"
            >
              <div className="flex gap-4 p-4">
                {post.featured_image ? (
                  <div className="w-32 h-24 flex-shrink-0 rounded-lg overflow-hidden">
                    <img
                      src={post.featured_image}
                      alt={post.title}
                      className="w-full h-full object-cover"
                    />
                  </div>
                ) : (
                  <div className="w-32 h-24 flex-shrink-0 rounded-lg bg-gradient-to-br from-[#f1f5f9] to-[#e2e8f0] dark:from-[#334155] dark:to-[#1e293b] flex items-center justify-center">
                    <svg className="w-8 h-8 text-gray-300" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1} d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" />
                    </svg>
                  </div>
                )}
                <div className="flex-1 min-w-0">
                  <h2 className="text-lg font-semibold text-[#1e293b] dark:text-white hover:text-[#0ea5e9] transition-colors line-clamp-1 mb-2">
                    {post.title}
                  </h2>
                  <p className="text-sm text-[#64748b] dark:text-[#94a3b8] line-clamp-2 mb-2">
                    {post.excerpt || '暂无摘要'}
                  </p>
                  <div className="flex items-center gap-3 text-xs text-[#94a3b8]">
                    <span>{new Date(post.published_at || post.created_at).toLocaleDateString('zh-CN')}</span>
                    <span>·</span>
                    <span>{post.view_count} 阅读</span>
                    {post.categories && (
                      <>
                        <span>·</span>
                        <span className="text-[#0ea5e9]">{post.categories.name}</span>
                      </>
                    )}
                  </div>
                </div>
              </div>
            </Link>
          ))}
        </div>
      )}

      {/* Pagination */}
      {totalPages > 1 && (
        <div className="flex items-center justify-center gap-2 mt-8">
          {currentPage > 1 && (
            <Link
              href={`/tag/${slug}?page=${currentPage - 1}`}
              className="px-4 py-2 text-sm rounded-lg bg-gray-100 dark:bg-gray-800 text-gray-600 dark:text-gray-400 hover:bg-gray-200 dark:hover:bg-gray-700"
            >
              上一页
            </Link>
          )}
          <span className="text-sm text-[#64748b]">
            第 {currentPage} / {totalPages} 页
          </span>
          {currentPage < totalPages && (
            <Link
              href={`/tag/${slug}?page=${currentPage + 1}`}
              className="px-4 py-2 text-sm rounded-lg bg-gray-100 dark:bg-gray-800 text-gray-600 dark:text-gray-400 hover:bg-gray-200 dark:hover:bg-gray-700"
            >
              下一页
            </Link>
          )}
        </div>
      )}
    </div>
  );
}
