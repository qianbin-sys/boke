import { getSupabaseClient } from '@/storage/database/supabase-client';
import { MembershipPricing } from '@/components/membership-pricing';
import Link from 'next/link';

async function getPlans() {
  const client = getSupabaseClient();
  
  const { data, error } = await client
    .from('membership_plans')
    .select('*')
    .eq('is_active', true)
    .order('sort_order', { ascending: true });
  
  if (error) {
    console.error('Failed to fetch plans:', error);
    return [];
  }
  
  return data || [];
}

async function getSettings() {
  const client = getSupabaseClient();
  const { data } = await client.from('settings').select('*');
  
  const settings: Record<string, string> = {};
  data?.forEach((item) => {
    settings[item.key] = item.value || '';
  });
  
  return settings;
}

export const metadata = {
  title: '会员订阅',
  description: '订阅会员，畅享全部付费内容',
};

export default async function MembershipPage() {
  const plans = await getPlans();
  const settings = await getSettings();

  return (
    <div className="max-w-5xl mx-auto">
      {/* Breadcrumb */}
      <nav className="flex items-center gap-2 text-sm text-[#64748b] dark:text-[#94a3b8] mb-6">
        <Link href="/" className="hover:text-[#0ea5e9] transition-colors">首页</Link>
        <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
        </svg>
        <span className="text-[#1e293b] dark:text-white">会员订阅</span>
      </nav>

      {/* Header */}
      <div className="text-center mb-12">
        <div className="inline-flex items-center gap-2 px-4 py-2 bg-amber-50 dark:bg-amber-900/20 rounded-full mb-6">
          <svg className="w-5 h-5 text-amber-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 3v4M3 5h4M6 17v4m-2-2h4m5-16l2.286 6.857L21 12l-5.714 2.143L13 21l-2.286-6.857L5 12l5.714-2.143L13 3z" />
          </svg>
          <span className="text-sm font-medium text-amber-600 dark:text-amber-400">解锁专属权益</span>
        </div>
        <h1 className="text-4xl font-bold text-[#1e293b] dark:text-white mb-4">
          成为{settings.site_name || '本站'}会员
        </h1>
        <p className="text-lg text-[#64748b] dark:text-[#94a3b8] max-w-2xl mx-auto">
          订阅会员，畅享全部付费内容，支持作者持续创作优质内容
        </p>
      </div>

      {/* Benefits */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
        <div className="p-6 bg-white dark:bg-[#1e293b] border border-[#e2e8f0] dark:border-[#334155] rounded-xl text-center">
          <div className="w-12 h-12 bg-blue-100 dark:bg-blue-900/30 rounded-xl flex items-center justify-center mx-auto mb-4">
            <svg className="w-6 h-6 text-blue-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253" />
            </svg>
          </div>
          <h3 className="font-semibold text-[#1e293b] dark:text-white mb-2">无限阅读</h3>
          <p className="text-sm text-[#64748b] dark:text-[#94a3b8]">
            畅享全站所有付费文章，不限阅读次数
          </p>
        </div>
        <div className="p-6 bg-white dark:bg-[#1e293b] border border-[#e2e8f0] dark:border-[#334155] rounded-xl text-center">
          <div className="w-12 h-12 bg-purple-100 dark:bg-purple-900/30 rounded-xl flex items-center justify-center mx-auto mb-4">
            <svg className="w-6 h-6 text-purple-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 3v4M3 5h4M6 17v4m-2-2h4m5-16l2.286 6.857L21 12l-5.714 2.143L13 21l-2.286-6.857L5 12l5.714-2.143L13 3z" />
            </svg>
          </div>
          <h3 className="font-semibold text-[#1e293b] dark:text-white mb-2">专属标识</h3>
          <p className="text-sm text-[#64748b] dark:text-[#94a3b8]">
            显示尊贵会员标识，彰显独特身份
          </p>
        </div>
        <div className="p-6 bg-white dark:bg-[#1e293b] border border-[#e2e8f0] dark:border-[#334155] rounded-xl text-center">
          <div className="w-12 h-12 bg-green-100 dark:bg-green-900/30 rounded-xl flex items-center justify-center mx-auto mb-4">
            <svg className="w-6 h-6 text-green-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M18.364 5.636l-3.536 3.536m0 5.656l3.536 3.536M9.172 9.172L5.636 5.636m3.536 9.192l-3.536 3.536M21 12a9 9 0 11-18 0 9 9 0 0118 0zm-5 0a4 4 0 11-8 0 4 4 0 018 0z" />
            </svg>
          </div>
          <h3 className="font-semibold text-[#1e293b] dark:text-white mb-2">优先支持</h3>
          <p className="text-sm text-[#64748b] dark:text-[#94a3b8]">
            享受专属客服，问题优先响应
          </p>
        </div>
      </div>

      {/* Pricing */}
      <MembershipPricing plans={plans} />

      {/* FAQ */}
      <div className="mt-16">
        <h2 className="text-2xl font-bold text-[#1e293b] dark:text-white mb-8 text-center">
          常见问题
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="p-6 bg-white dark:bg-[#1e293b] border border-[#e2e8f0] dark:border-[#334155] rounded-xl">
            <h3 className="font-semibold text-[#1e293b] dark:text-white mb-2">
              会员可以阅读所有付费文章吗？
            </h3>
            <p className="text-sm text-[#64748b] dark:text-[#94a3b8]">
              是的，成为会员后可以无限次阅读全站所有付费文章内容，无任何限制。
            </p>
          </div>
          <div className="p-6 bg-white dark:bg-[#1e293b] border border-[#e2e8f0] dark:border-[#334155] rounded-xl">
            <h3 className="font-semibold text-[#1e293b] dark:text-white mb-2">
              会员到期后还能阅读已解锁的文章吗？
            </h3>
            <p className="text-sm text-[#64748b] dark:text-[#94a3b8]">
              会员到期后将无法阅读付费文章，需要续费才能继续享受会员权益。
            </p>
          </div>
          <div className="p-6 bg-white dark:bg-[#1e293b] border border-[#e2e8f0] dark:border-[#334155] rounded-xl">
            <h3 className="font-semibold text-[#1e293b] dark:text-white mb-2">
              如何申请退款？
            </h3>
            <p className="text-sm text-[#64748b] dark:text-[#94a3b8]">
              如有特殊情况需要退款，请联系客服处理，我们会在1-3个工作日内处理。
            </p>
          </div>
          <div className="p-6 bg-white dark:bg-[#1e293b] border border-[#e2e8f0] dark:border-[#334155] rounded-xl">
            <h3 className="font-semibold text-[#1e293b] dark:text-white mb-2">
              永久会员是什么意思？
            </h3>
            <p className="text-sm text-[#64748b] dark:text-[#94a3b8]">
              永久会员一次付费，终身有效，无需续费，享受所有会员权益。
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
