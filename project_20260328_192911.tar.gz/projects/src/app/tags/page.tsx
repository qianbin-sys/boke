import { getSupabaseClient } from '@/storage/database/supabase-client';
import Link from 'next/link';
import { Hash } from 'lucide-react';

async function getTags() {
  const client = getSupabaseClient();
  
  const { data: tags, error } = await client
    .from('tags')
    .select(`
      id,
      name,
      slug,
      post_tags(count)
    `)
    .order('name', { ascending: true });

  if (error) {
    console.error('Failed to fetch tags:', error);
    return [];
  }

  return (tags || []).map(tag => ({
    id: tag.id,
    name: tag.name,
    slug: tag.slug,
    post_count: (tag.post_tags as any[])?.length || 0,
  }));
}

export default async function TagsPage() {
  const tags = await getTags();

  return (
    <div className="max-w-4xl mx-auto">
      {/* Header */}
      <div className="mb-8">
        <nav className="flex items-center gap-2 text-sm text-[#64748b] dark:text-[#94a3b8] mb-4">
          <Link href="/" className="hover:text-[#0ea5e9] transition-colors">首页</Link>
          <span>/</span>
          <span className="text-[#1e293b] dark:text-white">标签</span>
        </nav>
        <h1 className="text-3xl font-bold text-[#1e293b] dark:text-white mb-2">
          标签云
        </h1>
        <p className="text-[#64748b] dark:text-[#94a3b8]">
          共 {tags.length} 个标签
        </p>
      </div>

      {/* Tags Cloud */}
      {tags.length === 0 ? (
        <div className="text-center py-16 bg-white dark:bg-[#1e293b] rounded-xl border border-[#e2e8f0] dark:border-[#334155]">
          <Hash className="w-12 h-12 mx-auto text-gray-400 mb-4" />
          <p className="text-gray-500 dark:text-gray-400">暂无标签</p>
        </div>
      ) : (
        <div className="flex flex-wrap gap-3 p-6 bg-white dark:bg-[#1e293b] rounded-xl border border-[#e2e8f0] dark:border-[#334155]">
          {tags.map((tag) => {
            // 根据文章数量决定标签大小
            const sizeClass = tag.post_count > 10 
              ? 'text-lg px-4 py-2' 
              : tag.post_count > 5 
                ? 'text-base px-3 py-1.5' 
                : 'text-sm px-2.5 py-1';
            
            return (
              <Link
                key={tag.id}
                href={`/tag/${tag.slug}`}
                className={`inline-flex items-center gap-1.5 ${sizeClass} rounded-full font-medium transition-all hover:shadow-md hover:scale-105 ${
                  tag.post_count > 0
                    ? 'bg-[#0ea5e9]/10 text-[#0ea5e9] hover:bg-[#0ea5e9]/20 dark:bg-[#0ea5e9]/20 dark:text-[#38bdf8]'
                    : 'bg-gray-100 text-gray-400 dark:bg-gray-800 dark:text-gray-500'
                }`}
              >
                <Hash className="w-3.5 h-3.5" />
                {tag.name}
                {tag.post_count > 0 && (
                  <span className="text-xs opacity-60">({tag.post_count})</span>
                )}
              </Link>
            );
          })}
        </div>
      )}
    </div>
  );
}
