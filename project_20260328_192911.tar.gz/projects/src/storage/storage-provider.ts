import { S3Storage } from 'coze-coding-dev-sdk';

export interface StorageProvider {
  uploadFile(options: {
    fileContent: Buffer;
    fileName: string;
    contentType: string;
  }): Promise<string>;
  
  deleteFile(key: string): Promise<void>;
  
  generatePresignedUrl(options: {
    key: string;
    expireTime?: number;
  }): Promise<string>;
}

class S3StorageProvider implements StorageProvider {
  private storage: S3Storage;

  constructor() {
    this.storage = new S3Storage({
      endpointUrl: process.env.COZE_BUCKET_ENDPOINT_URL,
      accessKey: '',
      secretKey: '',
      bucketName: process.env.COZE_BUCKET_NAME,
      region: 'cn-beijing',
    });
  }

  async uploadFile(options: {
    fileContent: Buffer;
    fileName: string;
    contentType: string;
  }): Promise<string> {
    return this.storage.uploadFile(options);
  }

  async deleteFile(key: string): Promise<void> {
    await this.storage.deleteFile({ fileKey: key });
  }

  async generatePresignedUrl(options: {
    key: string;
    expireTime?: number;
  }): Promise<string> {
    return this.storage.generatePresignedUrl(options);
  }
}

let storageInstance: StorageProvider | null = null;

export function getStorage(): StorageProvider {
  if (!storageInstance) {
    storageInstance = new S3StorageProvider();
  }
  return storageInstance;
}
