import { sql } from "drizzle-orm";
import { pgTable, text, varchar, timestamp, boolean, integer, jsonb, index, serial, numeric } from "drizzle-orm/pg-core";
import { createSchemaFactory } from "drizzle-zod";
import { z } from "zod";

// 系统表 - 必须保留
export const healthCheck = pgTable("health_check", {
	id: serial().notNull(),
	updatedAt: timestamp("updated_at", { withTimezone: true, mode: 'string' }).defaultNow(),
});

// 用户表
export const users = pgTable(
  "users",
  {
    id: varchar("id", { length: 36 }).primaryKey().default(sql`gen_random_uuid()`),
    username: varchar("username", { length: 50 }).notNull().unique(),
    email: varchar("email", { length: 255 }).notNull().unique(),
    password_hash: varchar("password_hash", { length: 255 }).notNull(),
    display_name: varchar("display_name", { length: 100 }),
    avatar_url: varchar("avatar_url", { length: 500 }),
    role: varchar("role", { length: 20 }).notNull().default("subscriber"), // admin, editor, author, subscriber
    is_active: boolean("is_active").default(true).notNull(),
    created_at: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
    updated_at: timestamp("updated_at", { withTimezone: true }),
  },
  (table) => [
    index("users_email_idx").on(table.email),
    index("users_username_idx").on(table.username),
    index("users_role_idx").on(table.role),
  ]
);

// 分类表
export const categories = pgTable(
  "categories",
  {
    id: varchar("id", { length: 36 }).primaryKey().default(sql`gen_random_uuid()`),
    name: varchar("name", { length: 100 }).notNull(),
    slug: varchar("slug", { length: 100 }).notNull().unique(),
    description: text("description"),
    parent_id: varchar("parent_id", { length: 36 }),
    sort_order: integer("sort_order").default(0).notNull(),
    created_at: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
    updated_at: timestamp("updated_at", { withTimezone: true }),
  },
  (table) => [
    index("categories_slug_idx").on(table.slug),
    index("categories_parent_id_idx").on(table.parent_id),
  ]
);

// 标签表
export const tags = pgTable(
  "tags",
  {
    id: varchar("id", { length: 36 }).primaryKey().default(sql`gen_random_uuid()`),
    name: varchar("name", { length: 50 }).notNull(),
    slug: varchar("slug", { length: 50 }).notNull().unique(),
    created_at: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (table) => [
    index("tags_slug_idx").on(table.slug),
  ]
);

// 文章表
export const posts = pgTable(
  "posts",
  {
    id: varchar("id", { length: 36 }).primaryKey().default(sql`gen_random_uuid()`),
    title: varchar("title", { length: 255 }).notNull(),
    slug: varchar("slug", { length: 255 }).notNull().unique(),
    content: text("content").notNull(),
    excerpt: text("excerpt"),
    featured_image: varchar("featured_image", { length: 500 }),
    author_id: varchar("author_id", { length: 36 }).notNull().references(() => users.id),
    category_id: varchar("category_id", { length: 36 }).references(() => categories.id),
    status: varchar("status", { length: 20 }).notNull().default("draft"), // draft, published, private
    view_count: integer("view_count").default(0).notNull(),
    published_at: timestamp("published_at", { withTimezone: true }),
    created_at: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
    updated_at: timestamp("updated_at", { withTimezone: true }),
    // 付费阅读相关字段
    is_paid: boolean("is_paid").default(false).notNull(),
    price: numeric("price", { precision: 10, scale: 2 }).default("0"),
    payment_methods: jsonb("payment_methods").default(sql`'[]'::jsonb`), // 存储支持的支付方式数组 ["alipay", "wechat"]
    free_content: text("free_content"), // 免费预览内容
  },
  (table) => [
    index("posts_slug_idx").on(table.slug),
    index("posts_author_id_idx").on(table.author_id),
    index("posts_category_id_idx").on(table.category_id),
    index("posts_status_idx").on(table.status),
    index("posts_published_at_idx").on(table.published_at),
    index("posts_is_paid_idx").on(table.is_paid),
  ]
);

// 文章-标签关联表
export const postTags = pgTable(
  "post_tags",
  {
    id: varchar("id", { length: 36 }).primaryKey().default(sql`gen_random_uuid()`),
    post_id: varchar("post_id", { length: 36 }).notNull().references(() => posts.id, { onDelete: "cascade" }),
    tag_id: varchar("tag_id", { length: 36 }).notNull().references(() => tags.id, { onDelete: "cascade" }),
    created_at: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (table) => [
    index("post_tags_post_id_idx").on(table.post_id),
    index("post_tags_tag_id_idx").on(table.tag_id),
  ]
);

// 评论表
export const comments = pgTable(
  "comments",
  {
    id: varchar("id", { length: 36 }).primaryKey().default(sql`gen_random_uuid()`),
    post_id: varchar("post_id", { length: 36 }).notNull().references(() => posts.id, { onDelete: "cascade" }),
    user_id: varchar("user_id", { length: 36 }).references(() => users.id),
    parent_id: varchar("parent_id", { length: 36 }),
    author_name: varchar("author_name", { length: 100 }),
    author_email: varchar("author_email", { length: 255 }),
    content: text("content").notNull(),
    status: varchar("status", { length: 20 }).notNull().default("pending"), // pending, approved, spam
    created_at: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (table) => [
    index("comments_post_id_idx").on(table.post_id),
    index("comments_user_id_idx").on(table.user_id),
    index("comments_parent_id_idx").on(table.parent_id),
    index("comments_status_idx").on(table.status),
  ]
);

// 媒体文件表
export const media = pgTable(
  "media",
  {
    id: varchar("id", { length: 36 }).primaryKey().default(sql`gen_random_uuid()`),
    filename: varchar("filename", { length: 255 }).notNull(),
    original_name: varchar("original_name", { length: 255 }).notNull(),
    mime_type: varchar("mime_type", { length: 100 }).notNull(),
    size: integer("size").notNull(),
    url: varchar("url", { length: 500 }).notNull(),
    uploader_id: varchar("uploader_id", { length: 36 }).notNull().references(() => users.id),
    alt_text: varchar("alt_text", { length: 255 }),
    created_at: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (table) => [
    index("media_uploader_id_idx").on(table.uploader_id),
  ]
);

// 网站设置表
export const settings = pgTable(
  "settings",
  {
    id: varchar("id", { length: 36 }).primaryKey().default(sql`gen_random_uuid()`),
    key: varchar("key", { length: 100 }).notNull().unique(),
    value: text("value"),
    description: text("description"),
    created_at: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
    updated_at: timestamp("updated_at", { withTimezone: true }),
  },
  (table) => [
    index("settings_key_idx").on(table.key),
  ]
);

// 支付配置表
export const paymentConfigs = pgTable(
  "payment_configs",
  {
    id: varchar("id", { length: 36 }).primaryKey().default(sql`gen_random_uuid()`),
    payment_method: varchar("payment_method", { length: 50 }).notNull(), // alipay, wechat, paypal
    display_name: varchar("display_name", { length: 100 }).notNull(),
    is_enabled: boolean("is_enabled").default(false).notNull(),
    config: jsonb("config"), // 存储API密钥等配置信息
    description: text("description"),
    created_at: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
    updated_at: timestamp("updated_at", { withTimezone: true }),
  },
  (table) => [
    index("payment_configs_payment_method_idx").on(table.payment_method),
  ]
);

// 会员套餐表
export const membershipPlans = pgTable(
  "membership_plans",
  {
    id: varchar("id", { length: 36 }).primaryKey().default(sql`gen_random_uuid()`),
    name: varchar("name", { length: 100 }).notNull(),
    slug: varchar("slug", { length: 100 }).notNull().unique(),
    description: text("description"),
    price: numeric("price", { precision: 10, scale: 2 }).notNull(),
    original_price: numeric("original_price", { precision: 10, scale: 2 }),
    duration_days: integer("duration_days").notNull(), // 有效期天数，0表示永久
    features: jsonb("features").default(sql`'[]'::jsonb`), // 套餐权益列表
    is_active: boolean("is_active").default(true).notNull(),
    sort_order: integer("sort_order").default(0).notNull(),
    created_at: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
    updated_at: timestamp("updated_at", { withTimezone: true }),
  },
  (table) => [
    index("membership_plans_slug_idx").on(table.slug),
    index("membership_plans_is_active_idx").on(table.is_active),
  ]
);

// 用户会员关系表
export const userMemberships = pgTable(
  "user_memberships",
  {
    id: varchar("id", { length: 36 }).primaryKey().default(sql`gen_random_uuid()`),
    user_id: varchar("user_id", { length: 36 }).notNull().references(() => users.id, { onDelete: "cascade" }),
    plan_id: varchar("plan_id", { length: 36 }).notNull().references(() => membershipPlans.id),
    order_id: varchar("order_id", { length: 36 }).references(() => orders.id),
    status: varchar("status", { length: 20 }).notNull().default("active"), // active, expired, cancelled
    started_at: timestamp("started_at", { withTimezone: true }).defaultNow().notNull(),
    expired_at: timestamp("expired_at", { withTimezone: true }), // NULL表示永久有效
    created_at: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
    updated_at: timestamp("updated_at", { withTimezone: true }),
  },
  (table) => [
    index("user_memberships_user_id_idx").on(table.user_id),
    index("user_memberships_plan_id_idx").on(table.plan_id),
    index("user_memberships_status_idx").on(table.status),
    index("user_memberships_expired_at_idx").on(table.expired_at),
  ]
);

// 订单表
export const orders = pgTable(
  "orders",
  {
    id: varchar("id", { length: 36 }).primaryKey().default(sql`gen_random_uuid()`),
    order_no: varchar("order_no", { length: 100 }).notNull().unique(),
    user_id: varchar("user_id", { length: 36 }).references(() => users.id),
    amount: numeric("amount", { precision: 10, scale: 2 }).notNull(),
    currency: varchar("currency", { length: 10 }).notNull().default("CNY"),
    payment_method: varchar("payment_method", { length: 50 }),
    payment_status: varchar("payment_status", { length: 20 }).notNull().default("pending"), // pending, paid, failed, refunded
    transaction_id: varchar("transaction_id", { length: 255 }),
    metadata: jsonb("metadata"),
    paid_at: timestamp("paid_at", { withTimezone: true }),
    created_at: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
    updated_at: timestamp("updated_at", { withTimezone: true }),
  },
  (table) => [
    index("orders_order_no_idx").on(table.order_no),
    index("orders_user_id_idx").on(table.user_id),
    index("orders_payment_status_idx").on(table.payment_status),
    index("orders_created_at_idx").on(table.created_at),
  ]
);

// Zod Schemas
const { createInsertSchema: createCoercedInsertSchema } = createSchemaFactory({ coerce: { date: true } });

export const insertUserSchema = createCoercedInsertSchema(users).pick({ 
  username: true, 
  email: true, 
  password_hash: true,
  display_name: true,
  role: true,
});
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;

export const insertPostSchema = createCoercedInsertSchema(posts).pick({
  title: true,
  slug: true,
  content: true,
  excerpt: true,
  author_id: true,
  category_id: true,
  status: true,
});
export type Post = typeof posts.$inferSelect;
export type InsertPost = z.infer<typeof insertPostSchema>;

export const insertCategorySchema = createCoercedInsertSchema(categories).pick({
  name: true,
  slug: true,
  description: true,
  parent_id: true,
});
export type Category = typeof categories.$inferSelect;
export type InsertCategory = z.infer<typeof insertCategorySchema>;

export const insertTagSchema = createCoercedInsertSchema(tags).pick({
  name: true,
  slug: true,
});
export type Tag = typeof tags.$inferSelect;
export type InsertTag = z.infer<typeof insertTagSchema>;

export const insertCommentSchema = createCoercedInsertSchema(comments).pick({
  post_id: true,
  user_id: true,
  parent_id: true,
  author_name: true,
  author_email: true,
  content: true,
});
export type Comment = typeof comments.$inferSelect;
export type InsertComment = z.infer<typeof insertCommentSchema>;

export const insertSettingSchema = createCoercedInsertSchema(settings).pick({
  key: true,
  value: true,
  description: true,
});
export type Setting = typeof settings.$inferSelect;
export type InsertSetting = z.infer<typeof insertSettingSchema>;

export const insertPaymentConfigSchema = createCoercedInsertSchema(paymentConfigs).pick({
  payment_method: true,
  display_name: true,
  is_enabled: true,
  config: true,
  description: true,
});
export type PaymentConfig = typeof paymentConfigs.$inferSelect;
export type InsertPaymentConfig = z.infer<typeof insertPaymentConfigSchema>;

export const insertOrderSchema = createCoercedInsertSchema(orders).pick({
  order_no: true,
  user_id: true,
  amount: true,
  currency: true,
  payment_method: true,
  metadata: true,
});
export type Order = typeof orders.$inferSelect;
export type InsertOrder = z.infer<typeof insertOrderSchema>;

export const insertMembershipPlanSchema = createCoercedInsertSchema(membershipPlans).pick({
  name: true,
  slug: true,
  description: true,
  price: true,
  original_price: true,
  duration_days: true,
  features: true,
  is_active: true,
  sort_order: true,
});
export type MembershipPlan = typeof membershipPlans.$inferSelect;
export type InsertMembershipPlan = z.infer<typeof insertMembershipPlanSchema>;

export const insertUserMembershipSchema = createCoercedInsertSchema(userMemberships).pick({
  user_id: true,
  plan_id: true,
  order_id: true,
  status: true,
  started_at: true,
  expired_at: true,
});
export type UserMembership = typeof userMemberships.$inferSelect;
export type InsertUserMembership = z.infer<typeof insertUserMembershipSchema>;
