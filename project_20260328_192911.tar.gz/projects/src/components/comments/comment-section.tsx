'use client';

import { useState, useEffect } from 'react';
import { MessageSquare, Send, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';

interface Comment {
  id: string;
  content: string;
  status: string;
  created_at: string;
  user_id: string;
  parent_id: string | null;
  users: {
    id: string;
    username: string;
    display_name: string | null;
    avatar_url: string | null;
  } | null;
  children?: Comment[];
}

interface CommentsProps {
  postId: string;
}

interface CurrentUser {
  id: string;
  username: string;
  display_name: string | null;
}

export default function Comments({ postId }: CommentsProps) {
  const [user, setUser] = useState<CurrentUser | null>(null);
  const [userLoading, setUserLoading] = useState(true);
  const [comments, setComments] = useState<Comment[]>([]);
  const [loading, setLoading] = useState(true);
  const [content, setContent] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [replyTo, setReplyTo] = useState<string | null>(null);
  const [replyContent, setReplyContent] = useState('');

  useEffect(() => {
    // 获取当前用户
    fetch('/api/auth/me')
      .then(res => res.ok ? res.json() : null)
      .then(data => {
        setUser(data?.user || null);
        setUserLoading(false);
      })
      .catch(() => setUserLoading(false));
  }, []);

  useEffect(() => {
    fetchComments();
  }, [postId]);

  const fetchComments = async () => {
    try {
      const response = await fetch(`/api/comments?post_id=${postId}&status=approved`);
      const data = await response.json();
      
      // 组织成树形结构
      const commentMap: Record<string, Comment> = {};
      const rootComments: Comment[] = [];
      
      (data.comments || []).forEach((comment: Comment) => {
        commentMap[comment.id] = { ...comment, children: [] };
      });
      
      (data.comments || []).forEach((comment: Comment) => {
        const node = commentMap[comment.id];
        if (comment.parent_id && commentMap[comment.parent_id]) {
          commentMap[comment.parent_id].children!.push(node);
        } else {
          rootComments.push(node);
        }
      });
      
      setComments(rootComments);
    } catch (error) {
      console.error('Failed to fetch comments:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (parentId: string | null = null) => {
    const text = parentId ? replyContent : content;
    if (!text.trim()) return;

    setSubmitting(true);
    try {
      const response = await fetch('/api/comments', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          post_id: postId,
          content: text.trim(),
          parent_id: parentId,
        }),
      });

      if (response.ok) {
        if (parentId) {
          setReplyContent('');
          setReplyTo(null);
        } else {
          setContent('');
        }
        alert('评论已提交，等待审核');
      } else {
        const data = await response.json();
        alert(data.error || '评论失败');
      }
    } catch (error) {
      console.error('Failed to submit comment:', error);
      alert('评论失败');
    } finally {
      setSubmitting(false);
    }
  };

  const CommentItem = ({ comment, depth = 0 }: { comment: Comment; depth?: number }) => (
    <div className={`${depth > 0 ? 'ml-8 pl-4 border-l-2 border-gray-100 dark:border-gray-800' : ''}`}>
      <div className="py-4">
        <div className="flex items-start gap-3">
          {/* 头像 */}
          <div className="w-10 h-10 rounded-full bg-gradient-to-br from-[#0ea5e9] to-[#06b6d4] flex items-center justify-center text-white font-medium shrink-0">
            {comment.users?.display_name?.[0] || comment.users?.username?.[0] || '?'}
          </div>
          
          <div className="flex-1 min-w-0">
            {/* 用户名和时间 */}
            <div className="flex items-center gap-2 mb-1">
              <span className="font-medium text-gray-900 dark:text-white">
                {comment.users?.display_name || comment.users?.username || '未知用户'}
              </span>
              <span className="text-sm text-gray-500">
                {new Date(comment.created_at).toLocaleDateString('zh-CN', {
                  year: 'numeric',
                  month: 'long',
                  day: 'numeric',
                })}
              </span>
            </div>
            
            {/* 评论内容 */}
            <p className="text-gray-700 dark:text-gray-300 whitespace-pre-wrap">
              {comment.content}
            </p>
            
            {/* 回复按钮 */}
            {user && (
              <button
                onClick={() => setReplyTo(replyTo === comment.id ? null : comment.id)}
                className="text-sm text-[#0ea5e9] hover:underline mt-2"
              >
                回复
              </button>
            )}

            {/* 回复框 */}
            {replyTo === comment.id && (
              <div className="mt-3 space-y-2">
                <Textarea
                  value={replyContent}
                  onChange={(e) => setReplyContent(e.target.value)}
                  placeholder={`回复 ${comment.users?.display_name || comment.users?.username}...`}
                  rows={3}
                />
                <div className="flex gap-2">
                  <Button
                    size="sm"
                    onClick={() => handleSubmit(comment.id)}
                    disabled={submitting || !replyContent.trim()}
                  >
                    {submitting ? (
                      <Loader2 className="w-4 h-4 animate-spin" />
                    ) : (
                      <>
                        <Send className="w-4 h-4 mr-1" />
                        发送
                      </>
                    )}
                  </Button>
                  <Button size="sm" variant="ghost" onClick={() => setReplyTo(null)}>
                    取消
                  </Button>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* 子评论 */}
      {comment.children && comment.children.length > 0 && (
        <div>
          {comment.children.map((child) => (
            <CommentItem key={child.id} comment={child} depth={depth + 1} />
          ))}
        </div>
      )}
    </div>
  );

  return (
    <div className="mt-12">
      <h3 className="text-xl font-bold text-gray-900 dark:text-white flex items-center gap-2 mb-6">
        <MessageSquare className="w-5 h-5 text-[#0ea5e9]" />
        评论 ({comments.length})
      </h3>

      {/* 发表评论 */}
      {user ? (
        <div className="bg-gray-50 dark:bg-gray-800/50 rounded-lg p-4 mb-6">
          <Textarea
            value={content}
            onChange={(e) => setContent(e.target.value)}
            placeholder="发表你的看法..."
            rows={4}
            className="mb-3"
          />
          <Button
            onClick={() => handleSubmit()}
            disabled={submitting || !content.trim()}
          >
            {submitting ? (
              <Loader2 className="w-4 h-4 animate-spin" />
            ) : (
              <>
                <Send className="w-4 h-4 mr-2" />
                发表评论
              </>
            )}
          </Button>
        </div>
      ) : (
        <div className="bg-gray-50 dark:bg-gray-800/50 rounded-lg p-4 mb-6 text-center text-gray-500">
          <a href="/login" className="text-[#0ea5e9] hover:underline">登录</a> 后参与评论
        </div>
      )}

      {/* 评论列表 */}
      {loading ? (
        <div className="text-center text-gray-500 py-8">加载中...</div>
      ) : comments.length === 0 ? (
        <div className="text-center text-gray-500 py-8">暂无评论，快来抢沙发吧~</div>
      ) : (
        <div className="divide-y divide-gray-100 dark:divide-gray-800">
          {comments.map((comment) => (
            <CommentItem key={comment.id} comment={comment} />
          ))}
        </div>
      )}
    </div>
  );
}
