'use client';

import { useState, useRef, useEffect } from 'react';
import Link from 'next/link';
import { LogOut, User, Settings, Crown } from 'lucide-react';

interface UserMenuProps {
  user: {
    userId: string;
    username: string;
    email?: string;
    role: string;
    display_name?: string;
  };
}

export function UserMenu({ user }: UserMenuProps) {
  const [isOpen, setIsOpen] = useState(false);
  const menuRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (menuRef.current && !menuRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    }

    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const handleLogout = async () => {
    try {
      await fetch('/api/auth/logout', { method: 'POST' });
      window.location.href = '/';
    } catch (error) {
      console.error('Logout failed:', error);
    }
  };

  const displayName = user.display_name || user.username || 'U';
  const initial = displayName[0].toUpperCase();

  return (
    <div className="relative" ref={menuRef}>
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="flex items-center gap-2 px-3 py-2 text-sm font-medium text-[#1e293b] dark:text-white hover:bg-[#f1f5f9] dark:hover:bg-[#334155] rounded-lg transition-colors"
      >
        <div className="w-7 h-7 bg-gradient-to-br from-[#0ea5e9] to-[#06b6d4] rounded-full flex items-center justify-center">
          <span className="text-white text-xs font-bold">{initial}</span>
        </div>
        <span className="hidden sm:inline">{displayName}</span>
        <svg
          className={`w-4 h-4 transition-transform ${isOpen ? 'rotate-180' : ''}`}
          fill="none"
          viewBox="0 0 24 24"
          stroke="currentColor"
        >
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
        </svg>
      </button>

      {isOpen && (
        <div className="absolute right-0 mt-2 w-48 bg-white dark:bg-[#1e293b] border border-[#e2e8f0] dark:border-[#334155] rounded-lg shadow-lg py-1 z-50">
          {/* 管理员入口 */}
          {user.role === 'admin' && (
            <Link
              href="/admin"
              className="flex items-center gap-2 px-4 py-2 text-sm text-[#1e293b] dark:text-white hover:bg-[#f1f5f9] dark:hover:bg-[#334155]"
              onClick={() => setIsOpen(false)}
            >
              <Settings className="w-4 h-4" />
              管理后台
            </Link>
          )}

          {/* 会员中心 */}
          <Link
            href="/account/membership"
            className="flex items-center gap-2 px-4 py-2 text-sm text-[#1e293b] dark:text-white hover:bg-[#f1f5f9] dark:hover:bg-[#334155]"
            onClick={() => setIsOpen(false)}
          >
            <Crown className="w-4 h-4" />
            会员中心
          </Link>

          {/* 我的订单 */}
          <Link
            href="/account/orders"
            className="flex items-center gap-2 px-4 py-2 text-sm text-[#1e293b] dark:text-white hover:bg-[#f1f5f9] dark:hover:bg-[#334155]"
            onClick={() => setIsOpen(false)}
          >
            <User className="w-4 h-4" />
            我的订单
          </Link>

          {/* 分割线 */}
          <div className="border-t border-[#e2e8f0] dark:border-[#334155] my-1" />

          {/* 退出登录 */}
          <button
            onClick={handleLogout}
            className="flex items-center gap-2 px-4 py-2 text-sm text-red-500 hover:bg-red-50 dark:hover:bg-red-900/20 w-full text-left"
          >
            <LogOut className="w-4 h-4" />
            退出登录
          </button>
        </div>
      )}
    </div>
  );
}
