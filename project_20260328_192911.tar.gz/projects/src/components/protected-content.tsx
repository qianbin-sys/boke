'use client';

import { useState, useEffect } from 'react';
import Link from 'next/link';
import { Crown, Lock, CheckCircle, Loader2, CreditCard, X } from 'lucide-react';

interface ProtectedContentProps {
  postId: string;
  content: string;
  price: number;
  paymentMethods: string[];
  freeContent?: string;
}

interface AccessInfo {
  hasAccess: boolean;
  reason?: string;
  price?: number;
}

export function ProtectedContent({ 
  postId, 
  content, 
  price, 
  paymentMethods, 
  freeContent 
}: ProtectedContentProps) {
  const [isLoading, setIsLoading] = useState(true);
  const [isMember, setIsMember] = useState(false);
  const [hasAccess, setHasAccess] = useState(false);
  const [accessReason, setAccessReason] = useState<string | null>(null);
  const [isPaying, setIsPaying] = useState(false);
  const [error, setError] = useState('');

  // 支付宝支付状态
  const [showAlipayModal, setShowAlipayModal] = useState(false);
  const [alipayQRCode, setAlipayQRCode] = useState<string | null>(null);
  const [alipayLoading, setAlipayLoading] = useState(false);
  const [pendingOrderId, setPendingOrderId] = useState<string | null>(null);
  const [polling, setPolling] = useState(false);
  const [paid, setPaid] = useState(false);

  useEffect(() => {
    checkAccess();
  }, [postId]);

  // 轮询检查支付状态
  useEffect(() => {
    if (!polling || !pendingOrderId) return;

    const pollPaymentStatus = async () => {
      try {
        // 先检查本地订单状态
        const orderResponse = await fetch(`/api/orders/${pendingOrderId}`);
        const orderData = await orderResponse.json();
        
        console.log('Poll post order status:', orderData.order?.payment_status);
        
        if (orderData.order?.payment_status === 'paid') {
          setPaid(true);
          setPolling(false);
          setTimeout(() => {
            setShowAlipayModal(false);
            setHasAccess(true);
            setAccessReason('purchased');
          }, 1500);
          return;
        }

        // 主动查询支付宝订单状态
        const queryResponse = await fetch('/api/payment/alipay/query', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ orderId: pendingOrderId }),
        });
        const queryData = await queryResponse.json();

        console.log('Alipay query result:', queryData);

        if (queryData.paid) {
          setPaid(true);
          setPolling(false);
          setTimeout(() => {
            setShowAlipayModal(false);
            setHasAccess(true);
            setAccessReason('purchased');
          }, 1500);
        }
      } catch (err) {
        console.error('Poll payment status error:', err);
      }
    };

    const interval = setInterval(pollPaymentStatus, 3000);
    pollPaymentStatus(); // 立即执行一次

    return () => clearInterval(interval);
  }, [polling, pendingOrderId]);

  const checkAccess = async () => {
    try {
      // 并行检查会员状态和文章访问权限
      const [membershipRes, accessRes] = await Promise.all([
        fetch('/api/user/membership'),
        fetch(`/api/posts/${postId}/access`)
      ]);

      if (membershipRes.ok) {
        const data = await membershipRes.json();
        setIsMember(data.isMember || false);
      }

      if (accessRes.ok) {
        const accessData: AccessInfo = await accessRes.json();
        setHasAccess(accessData.hasAccess);
        setAccessReason(accessData.reason || null);
      }
    } catch (error) {
      console.error('Failed to check access:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const handlePurchase = async () => {
    setIsPaying(true);
    setError('');

    try {
      // 1. 创建订单
      const createRes = await fetch('/api/orders', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          type: 'post',
          post_id: postId,
          payment_method: 'alipay',
        }),
      });

      const createData = await createRes.json();
      if (!createRes.ok) {
        setError(createData.error || '创建订单失败');
        setIsPaying(false);
        return;
      }

      const orderId = createData.order.id;
      setPendingOrderId(orderId);
      setAlipayLoading(true);
      setShowAlipayModal(true);
      setPaid(false);
      setAlipayQRCode(null);

      // 2. 获取支付宝二维码
      const alipayRes = await fetch('/api/payment/alipay/create', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ orderId }),
      });

      const alipayData = await alipayRes.json();
      if (!alipayRes.ok) {
        setShowAlipayModal(false);
        setError(alipayData.error || '创建支付宝订单失败');
        setAlipayLoading(false);
        setIsPaying(false);
        return;
      }

      setAlipayQRCode(alipayData.qrCode);
      setPolling(true);
      setAlipayLoading(false);
      setIsPaying(false);
    } catch (error) {
      console.error('Purchase error:', error);
      setError('支付失败，请稍后重试');
      setIsPaying(false);
    }
  };

  const handleCloseAlipayModal = () => {
    setShowAlipayModal(false);
    setPolling(false);
    setAlipayQRCode(null);
    setPendingOrderId(null);
  };

  // 如果用户有权限，显示完整内容
  if (!isLoading && hasAccess) {
    return (
      <>
        {/* 访问来源提示 */}
        {accessReason && (
          <div className={`flex items-center gap-2 p-3 mb-6 rounded-xl ${
            accessReason === 'membership' 
              ? 'bg-gradient-to-r from-amber-50 to-orange-50 dark:from-amber-900/20 dark:to-orange-900/20 border border-amber-200 dark:border-amber-800'
              : 'bg-green-50 dark:bg-green-900/20 border border-green-200 dark:border-green-800'
          }`}>
            {accessReason === 'membership' ? (
              <>
                <Crown className="w-5 h-5 text-amber-500" />
                <span className="text-sm text-amber-700 dark:text-amber-300">
                  尊贵的会员，畅享全文阅读
                </span>
              </>
            ) : (
              <>
                <CheckCircle className="w-5 h-5 text-green-500" />
                <span className="text-sm text-green-700 dark:text-green-300">
                  您已购买此文章
                </span>
              </>
            )}
          </div>
        )}
        <div className="prose prose-lg dark:prose-invert max-w-none mb-12
          prose-headings:text-[#1e293b] dark:prose-headings:text-white
          prose-p:text-[#475569] dark:prose-p:text-[#cbd5e1]
          prose-a:text-[#0ea5e9] prose-a:no-underline hover:prose-a:underline
          prose-code:bg-[#f1f5f9] dark:prose-code:bg-[#334155] prose-code:px-1.5 prose-code:py-0.5 prose-code:rounded
          prose-pre:bg-[#1e293b] prose-pre:border prose-pre:border-[#334155]
          prose-blockquote:border-l-[#0ea5e9] prose-blockquote:bg-[#f0f9ff] dark:prose-blockquote:bg-[#0c4a6e]/20 prose-blockquote:py-1
        ">
          <div className="whitespace-pre-wrap leading-relaxed">
            {content}
          </div>
        </div>
      </>
    );
  }

  // 显示预览内容和付费卡片
  const previewContent = freeContent || content?.substring(0, 500) + '...';

  return (
    <>
      {/* 预览内容 */}
      <div className="prose prose-lg dark:prose-invert max-w-none mb-6
        prose-headings:text-[#1e293b] dark:prose-headings:text-white
        prose-p:text-[#475569] dark:prose-p:text-[#cbd5e1]
        prose-a:text-[#0ea5e9] prose-a:no-underline hover:prose-a:underline
        prose-code:bg-[#f1f5f9] dark:prose-code:bg-[#334155] prose-code:px-1.5 prose-code:py-0.5 prose-code:rounded
      ">
        <div className="whitespace-pre-wrap leading-relaxed">
          {previewContent}
        </div>
      </div>

      {/* 渐变遮罩 */}
      <div className="relative">
        <div className="h-32 bg-gradient-to-b from-transparent to-white dark:to-[#0f172a] absolute -top-32 left-0 right-0 pointer-events-none" />
      </div>

      {/* 购买卡片 */}
      <div className="bg-gradient-to-br from-[#0ea5e9]/10 to-[#06b6d4]/10 dark:from-[#0ea5e9]/20 dark:to-[#06b6d4]/20 border-2 border-[#0ea5e9]/30 rounded-2xl p-6 my-8">
        {/* Header */}
        <div className="flex items-center gap-3 mb-4">
          <div className="w-12 h-12 bg-[#0ea5e9] rounded-xl flex items-center justify-center">
            <Lock className="w-6 h-6 text-white" />
          </div>
          <div>
            <h3 className="text-lg font-bold text-[#1e293b] dark:text-white">
              付费内容
            </h3>
            <p className="text-sm text-[#64748b] dark:text-[#94a3b8]">
              解锁完整文章内容
            </p>
          </div>
        </div>

        {/* Price */}
        <div className="flex items-baseline gap-1 mb-4">
          <span className="text-3xl font-bold text-[#0ea5e9]">
            ¥{price.toFixed(2)}
          </span>
          <span className="text-[#94a3b8] text-sm">/ 永久阅读</span>
        </div>

        {/* 会员优惠提示 */}
        <div className="p-3 bg-amber-50 dark:bg-amber-900/20 border border-amber-200 dark:border-amber-800 rounded-lg mb-4">
          <div className="flex items-center gap-2">
            <Crown className="w-4 h-4 text-amber-500" />
            <span className="text-sm text-amber-700 dark:text-amber-300">
              成为<Link href="/membership" className="font-medium underline">会员</Link>可免费阅读全站付费内容
            </span>
          </div>
        </div>

        {/* Error Message */}
        {error && (
          <div className="p-3 mb-4 bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 rounded-lg text-red-700 dark:text-red-300 text-sm">
            {error}
          </div>
        )}

        {/* Pay Button - 支付宝 */}
        <button
          onClick={handlePurchase}
          disabled={isPaying}
          className="w-full py-3 rounded-xl font-medium transition-all flex items-center justify-center gap-2 bg-[#1677ff] text-white hover:bg-[#0958d9] shadow-lg disabled:opacity-50 disabled:cursor-not-allowed"
        >
          {isPaying ? (
            <>
              <Loader2 className="w-5 h-5 animate-spin" />
              创建订单中...
            </>
          ) : (
            <>
              <CreditCard className="w-5 h-5" />
              支付宝扫码支付 ¥{price.toFixed(2)}
            </>
          )}
        </button>

        {/* Benefits */}
        <div className="mt-4 pt-4 border-t border-[#e2e8f0] dark:border-[#334155]">
          <ul className="space-y-1">
            <li className="flex items-center gap-2 text-sm text-[#64748b] dark:text-[#94a3b8]">
              <CheckCircle className="w-4 h-4 text-green-500" />
              完整文章内容永久阅读权限
            </li>
            <li className="flex items-center gap-2 text-sm text-[#64748b] dark:text-[#94a3b8]">
              <CheckCircle className="w-4 h-4 text-green-500" />
              支持作者持续创作优质内容
            </li>
          </ul>
        </div>
      </div>

      {/* 支付宝二维码弹窗 */}
      {showAlipayModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm">
          <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-2xl p-6 max-w-sm w-full mx-4 relative">
            <button
              onClick={handleCloseAlipayModal}
              className="absolute top-4 right-4 p-1 rounded-full hover:bg-gray-100 dark:hover:bg-gray-700"
            >
              <X className="w-5 h-5 text-gray-500" />
            </button>

            {paid ? (
              <div className="flex flex-col items-center py-8">
                <CheckCircle className="w-16 h-16 text-green-500 mb-4" />
                <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-2">支付成功</h3>
                <p className="text-gray-500">正在解锁文章内容...</p>
              </div>
            ) : (
              <>
                <div className="text-center mb-4">
                  <h3 className="text-lg font-bold text-gray-900 dark:text-white flex items-center justify-center gap-2">
                    <CreditCard className="w-5 h-5 text-[#1677ff]" />
                    支付宝扫码支付
                  </h3>
                  <p className="text-2xl font-bold text-[#1677ff] mt-2">
                    ¥{price.toFixed(2)}
                  </p>
                  <p className="text-xs text-gray-500 mt-1">
                    文章购买 - 永久阅读
                  </p>
                </div>

                {alipayLoading ? (
                  <div className="flex flex-col items-center py-8">
                    <Loader2 className="w-12 h-12 animate-spin text-[#1677ff] mb-4" />
                    <p className="text-gray-500">正在生成支付二维码...</p>
                  </div>
                ) : alipayQRCode ? (
                  <div className="flex flex-col items-center">
                    <div className="bg-white p-4 rounded-lg shadow-inner">
                      <img 
                        src={`https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=${encodeURIComponent(alipayQRCode)}`}
                        alt="支付二维码"
                        width={200}
                        height={200}
                        className="rounded"
                      />
                    </div>
                    <p className="mt-3 text-sm text-gray-500">请使用支付宝扫码支付</p>
                  </div>
                ) : (
                  <div className="text-center py-8 text-gray-500">
                    获取二维码失败，请重试
                  </div>
                )}

                {!alipayLoading && alipayQRCode && (
                  <div className="mt-4 flex items-center justify-center gap-2 text-sm text-gray-500">
                    <Loader2 className="w-4 h-4 animate-spin" />
                    <span>等待支付中...</span>
                  </div>
                )}

                <p className="text-xs text-gray-400 text-center mt-3">
                  请在30分钟内完成支付，支付成功后将自动解锁
                </p>
              </>
            )}
          </div>
        </div>
      )}
    </>
  );
}
