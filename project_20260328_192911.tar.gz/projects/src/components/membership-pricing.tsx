'use client';

import { useState, useEffect } from 'react';
import { Crown, Check, Loader2, CreditCard, X, CheckCircle2, ShieldCheck } from 'lucide-react';

interface Plan {
  id: string;
  name: string;
  slug: string;
  description: string;
  price: string;
  original_price: string;
  duration_days: number;
  features: string[];
  is_active: boolean;
  sort_order: number;
}

interface MembershipPricingProps {
  plans: Plan[];
}

interface PaymentMethod {
  payment_method: string;
  display_name: string;
}

interface UserMembership {
  id: string;
  status: string;
  expired_at: string | null;
  membership_plans: {
    id: string;
    name: string;
    duration_days: number;
  };
}

const planColors: Record<string, { gradient: string; border: string }> = {
  monthly: { 
    gradient: 'from-blue-500 to-cyan-500', 
    border: 'border-blue-200 dark:border-blue-800',
  },
  yearly: { 
    gradient: 'from-purple-500 to-pink-500', 
    border: 'border-purple-200 dark:border-purple-800',
  },
  lifetime: { 
    gradient: 'from-amber-500 to-orange-500', 
    border: 'border-amber-200 dark:border-amber-800',
  },
};

const paymentMethodLabels: Record<string, string> = {
  alipay: '支付宝',
  wechat: '微信支付',
  paypal: 'PayPal',
  stripe: 'Stripe',
};

function getPlanStyle(slug: string) {
  return planColors[slug] || { 
    gradient: 'from-gray-500 to-gray-600', 
    border: 'border-gray-200 dark:border-gray-700',
  };
}

function getDurationText(days: number) {
  if (days === 0) return '永久有效';
  if (days === 30) return '1个月';
  if (days === 90) return '3个月';
  if (days === 180) return '6个月';
  if (days === 365) return '1年';
  return `${days}天`;
}

function formatDate(dateStr: string) {
  return new Date(dateStr).toLocaleDateString('zh-CN', {
    year: 'numeric',
    month: 'long',
    day: 'numeric',
  });
}

export function MembershipPricing({ plans }: MembershipPricingProps) {
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [loading, setLoading] = useState<string | null>(null);
  const [error, setError] = useState('');
  const [paymentMethods, setPaymentMethods] = useState<PaymentMethod[]>([]);
  const [selectedMethod, setSelectedMethod] = useState<string>('');
  
  // 用户会员状态
  const [userMembership, setUserMembership] = useState<UserMembership | null>(null);
  const [isLifetimeMember, setIsLifetimeMember] = useState(false);
  
  // 支付宝支付状态
  const [showAlipayModal, setShowAlipayModal] = useState(false);
  const [alipayQRCode, setAlipayQRCode] = useState<string | null>(null);
  const [alipayLoading, setAlipayLoading] = useState(false);
  const [pendingOrderId, setPendingOrderId] = useState<string | null>(null);
  const [pendingPlan, setPendingPlan] = useState<Plan | null>(null);
  const [polling, setPolling] = useState(false);
  const [paid, setPaid] = useState(false);

  useEffect(() => {
    // 检查登录状态
    fetch('/api/auth/me')
      .then((res) => res.json())
      .then((data) => {
        setIsLoggedIn(!!data.user);
        if (data.user) {
          // 获取用户会员状态
          fetchUserMembership();
        }
      })
      .catch(() => setIsLoggedIn(false));

    // 获取已启用的支付方式
    fetch('/api/payment-configs')
      .then((res) => res.json())
      .then((data) => {
        const enabled = (data.configs || [])
          .filter((c: {is_enabled: boolean}) => c.is_enabled)
          .map((c: {payment_method: string; display_name: string}) => ({
            payment_method: c.payment_method,
            display_name: c.display_name,
          }));
        setPaymentMethods(enabled);
        if (enabled.length > 0) {
          setSelectedMethod(enabled[0].payment_method);
        }
      })
      .catch(console.error);
  }, []);

  const fetchUserMembership = async () => {
    try {
      const res = await fetch('/api/user/membership');
      const data = await res.json();
      if (data.isMember && data.membership) {
        setUserMembership(data.membership);
        setIsLifetimeMember(data.membership.expired_at === null);
      }
    } catch (err) {
      console.error('Fetch membership error:', err);
    }
  };

  // 轮询检查支付状态
  useEffect(() => {
    if (!polling || !pendingOrderId) return;

    const pollPaymentStatus = async () => {
      try {
        // 先检查本地订单状态
        const orderResponse = await fetch(`/api/orders/${pendingOrderId}`);
        const orderData = await orderResponse.json();
        
        console.log('Poll order status:', orderData.order?.payment_status);
        
        if (orderData.order?.payment_status === 'paid') {
          setPaid(true);
          setPolling(false);
          setTimeout(() => {
            setShowAlipayModal(false);
            window.location.href = '/account/membership?success=true';
          }, 1500);
          return;
        }

        // 主动查询支付宝订单状态
        const queryResponse = await fetch('/api/payment/alipay/query', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ orderId: pendingOrderId }),
        });
        const queryData = await queryResponse.json();

        console.log('Alipay query result:', queryData);

        if (queryData.paid) {
          setPaid(true);
          setPolling(false);
          setTimeout(() => {
            setShowAlipayModal(false);
            window.location.href = '/account/membership?success=true';
          }, 1500);
        }
      } catch (err) {
        console.error('Poll payment status error:', err);
      }
    };

    const interval = setInterval(pollPaymentStatus, 3000);
    pollPaymentStatus();

    return () => clearInterval(interval);
  }, [polling, pendingOrderId]);

  const handleSubscribe = async (plan: Plan) => {
    if (!isLoggedIn) {
      window.location.href = '/login?redirect=' + encodeURIComponent('/membership');
      return;
    }

    // 检查是否是永久会员
    if (isLifetimeMember) {
      setError('您已经是永久会员，无需再次购买');
      return;
    }

    if (!selectedMethod) {
      setError('请选择支付方式');
      return;
    }

    setLoading(plan.id);
    setError('');

    try {
      // 创建订单
      const createRes = await fetch('/api/orders', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          type: 'membership',
          plan_id: plan.id,
          payment_method: selectedMethod,
        }),
      });

      const createData = await createRes.json();
      if (!createRes.ok) {
        setError(createData.error || '创建订单失败');
        setLoading(null);
        return;
      }

      const order = createData.order;

      // 如果选择支付宝，直接调用接口获取二维码并弹窗
      if (selectedMethod === 'alipay') {
        setPendingOrderId(order.id);
        setPendingPlan(plan);
        setAlipayLoading(true);
        setShowAlipayModal(true);
        setPaid(false);
        setAlipayQRCode(null);
        
        try {
          const alipayRes = await fetch('/api/payment/alipay/create', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ orderId: order.id }),
          });

          const alipayData = await alipayRes.json();
          if (!alipayRes.ok) {
            setShowAlipayModal(false);
            setError(alipayData.error || '创建支付宝订单失败');
            setAlipayLoading(false);
            setLoading(null);
            return;
          }

          setAlipayQRCode(alipayData.qrCode);
          setPolling(true);
          setAlipayLoading(false);
        } catch (err) {
          setShowAlipayModal(false);
          setError('创建支付宝订单失败');
          setAlipayLoading(false);
        }
        setLoading(null);
        return;
      }

      // 其他支付方式
      setError('该支付方式暂未开放');
      setLoading(null);
    } catch (err) {
      console.error('Subscribe error:', err);
      setError('订阅失败，请稍后重试');
      setLoading(null);
    }
  };

  const handleCloseAlipayModal = () => {
    setShowAlipayModal(false);
    setPolling(false);
    setAlipayQRCode(null);
    setPendingOrderId(null);
    setPendingPlan(null);
  };

  if (plans.length === 0) {
    return (
      <div className="text-center py-12">
        <p className="text-gray-500 dark:text-gray-400">暂无可用套餐</p>
      </div>
    );
  }

  return (
    <div>
      {/* 永久会员提示 */}
      {isLifetimeMember && (
        <div className="mb-6 p-4 bg-gradient-to-r from-amber-50 to-orange-50 dark:from-amber-900/20 dark:to-orange-900/20 border border-amber-200 dark:border-amber-800 rounded-xl">
          <div className="flex items-center gap-3">
            <ShieldCheck className="w-6 h-6 text-amber-500" />
            <div>
              <p className="font-medium text-amber-700 dark:text-amber-300">
                您是尊贵的永久会员
              </p>
              <p className="text-sm text-amber-600 dark:text-amber-400">
                享受全站内容永久免费阅读权益
              </p>
            </div>
          </div>
        </div>
      )}

      {/* 当前会员状态提示 */}
      {userMembership && !isLifetimeMember && (
        <div className="mb-6 p-4 bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-800 rounded-xl">
          <div className="flex items-center gap-3">
            <Crown className="w-5 h-5 text-blue-500" />
            <div>
              <p className="text-sm text-blue-700 dark:text-blue-300">
                当前会员：{userMembership.membership_plans?.name || '会员'}
              </p>
              <p className="text-xs text-blue-600 dark:text-blue-400">
                有效期至：{userMembership.expired_at ? formatDate(userMembership.expired_at) : '永久'}
              </p>
            </div>
          </div>
        </div>
      )}

      {error && (
        <div className="mb-6 p-4 bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 rounded-lg text-red-700 dark:text-red-400 text-sm">
          {error}
        </div>
      )}

      {/* 支付方式选择 - 永久会员不显示 */}
      {!isLifetimeMember && paymentMethods.length > 0 && (
        <div className="mb-6">
          <h3 className="text-sm font-medium text-[#1e293b] dark:text-white mb-3">
            选择支付方式
          </h3>
          <div className="flex flex-wrap gap-2">
            {paymentMethods.map((method) => (
              <button
                key={method.payment_method}
                onClick={() => setSelectedMethod(method.payment_method)}
                className={`px-4 py-2 rounded-lg text-sm transition-all ${
                  selectedMethod === method.payment_method
                    ? 'bg-[#0ea5e9] text-white'
                    : 'bg-gray-100 dark:bg-gray-800 text-gray-700 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-700'
                }`}
              >
                {paymentMethodLabels[method.payment_method] || method.display_name}
              </button>
            ))}
          </div>
        </div>
      )}
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {plans.map((plan) => {
          const style = getPlanStyle(plan.slug);
          const isPopular = plan.slug === 'yearly';
          const isLifetime = plan.duration_days === 0;
          const isCurrentPlan = userMembership?.membership_plans?.id === plan.id;
          
          return (
            <div
              key={plan.id}
              className={`relative bg-white dark:bg-[#1e293b] border-2 rounded-2xl overflow-hidden transition-all hover:shadow-xl flex flex-col ${
                isPopular ? 'border-[#0ea5e9] shadow-lg shadow-[#0ea5e9]/10' : style.border
              } ${isLifetimeMember && !isLifetime ? 'opacity-60' : ''}`}
            >
              {/* Popular Badge */}
              {isPopular && (
                <div className="absolute top-0 right-0 z-10">
                  <div className="bg-[#0ea5e9] text-white text-xs font-medium px-3 py-1 rounded-bl-lg">
                    最受欢迎
                  </div>
                </div>
              )}

              {/* Current Plan Badge */}
              {isCurrentPlan && (
                <div className="absolute top-0 left-0 z-10">
                  <div className="bg-green-500 text-white text-xs font-medium px-3 py-1 rounded-br-lg">
                    当前套餐
                  </div>
                </div>
              )}

              <div className="p-6 flex-1 flex flex-col">
                {/* Plan Header */}
                <div className="text-center mb-4">
                  <div className={`w-12 h-12 bg-gradient-to-br ${style.gradient} rounded-xl flex items-center justify-center mx-auto mb-3`}>
                    <Crown className="w-6 h-6 text-white" />
                  </div>
                  <h3 className="text-lg font-bold text-[#1e293b] dark:text-white mb-1">
                    {plan.name}
                  </h3>
                  {plan.description && (
                    <p className="text-xs text-[#64748b] dark:text-[#94a3b8]">
                      {plan.description}
                    </p>
                  )}
                </div>

                {/* Price */}
                <div className="text-center mb-4">
                  <div className="flex items-baseline justify-center gap-2">
                    <span className="text-3xl font-bold text-[#1e293b] dark:text-white">
                      ¥{plan.price}
                    </span>
                    {plan.original_price && (
                      <span className="text-sm text-gray-400 line-through">
                        ¥{plan.original_price}
                      </span>
                    )}
                  </div>
                  <p className="text-xs text-[#64748b] dark:text-[#94a3b8] mt-1">
                    {getDurationText(plan.duration_days)}
                  </p>
                </div>

                {/* Features */}
                {plan.features && plan.features.length > 0 && (
                  <ul className="space-y-2 mb-4 flex-1">
                    {plan.features.map((feature, idx) => (
                      <li key={idx} className="flex items-center gap-2 text-sm text-[#475569] dark:text-[#cbd5e1]">
                        <Check className="w-4 h-4 text-green-500 flex-shrink-0" />
                        {feature}
                      </li>
                    ))}
                  </ul>
                )}

                {/* Subscribe Button */}
                {isLifetimeMember ? (
                  // 永久会员显示"已拥有"按钮
                  isLifetime ? (
                    <button
                      disabled
                      className="w-full py-3 rounded-xl font-medium bg-green-500 text-white cursor-default flex items-center justify-center gap-2"
                    >
                      <CheckCircle2 className="w-5 h-5" />
                      已拥有
                    </button>
                  ) : (
                    <button
                      disabled
                      className="w-full py-3 rounded-xl font-medium bg-gray-200 dark:bg-gray-700 text-gray-500 dark:text-gray-400 cursor-not-allowed"
                    >
                      无需购买
                    </button>
                  )
                ) : (
                  <button
                    onClick={() => handleSubscribe(plan)}
                    disabled={loading === plan.id || !selectedMethod}
                    className={`w-full py-3 rounded-xl font-medium transition-all flex items-center justify-center gap-2 ${
                      isCurrentPlan
                        ? 'bg-green-500 text-white hover:bg-green-600'
                        : selectedMethod
                          ? 'bg-[#0ea5e9] text-white hover:bg-[#0284c7] shadow-md'
                          : 'bg-gray-300 dark:bg-gray-600 text-white cursor-not-allowed'
                    }`}
                  >
                    {loading === plan.id ? (
                      <>
                        <Loader2 className="w-5 h-5 animate-spin" />
                        创建订单中...
                      </>
                    ) : !isLoggedIn ? (
                      '登录后订阅'
                    ) : isCurrentPlan ? (
                      <>
                        <CreditCard className="w-5 h-5" />
                        续费
                      </>
                    ) : (
                      <>
                        <CreditCard className="w-5 h-5" />
                        立即订阅
                      </>
                    )}
                  </button>
                )}
              </div>
            </div>
          );
        })}
      </div>

      {/* 支付宝二维码弹窗 */}
      {showAlipayModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm">
          <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-2xl p-6 max-w-sm w-full mx-4 relative">
            <button
              onClick={handleCloseAlipayModal}
              className="absolute top-4 right-4 p-1 rounded-full hover:bg-gray-100 dark:hover:bg-gray-700"
            >
              <X className="w-5 h-5 text-gray-500" />
            </button>

            {paid ? (
              <div className="flex flex-col items-center py-8">
                <CheckCircle2 className="w-16 h-16 text-green-500 mb-4" />
                <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-2">支付成功</h3>
                <p className="text-gray-500">正在跳转到会员中心...</p>
              </div>
            ) : (
              <>
                <div className="text-center mb-4">
                  <h3 className="text-lg font-bold text-gray-900 dark:text-white flex items-center justify-center gap-2">
                    <CreditCard className="w-5 h-5 text-[#1677ff]" />
                    支付宝扫码支付
                  </h3>
                  <p className="text-2xl font-bold text-[#1677ff] mt-2">
                    ¥{pendingPlan ? parseFloat(pendingPlan.price).toFixed(2) : '0.00'}
                  </p>
                  {pendingPlan && (
                    <p className="text-xs text-gray-500 mt-1">
                      {pendingPlan.name} - {getDurationText(pendingPlan.duration_days)}
                    </p>
                  )}
                </div>

                {alipayLoading ? (
                  <div className="flex flex-col items-center py-8">
                    <Loader2 className="w-12 h-12 animate-spin text-[#1677ff] mb-4" />
                    <p className="text-gray-500">正在生成支付二维码...</p>
                  </div>
                ) : alipayQRCode ? (
                  <div className="flex flex-col items-center">
                    <div className="bg-white p-4 rounded-lg shadow-inner">
                      <img 
                        src={`https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=${encodeURIComponent(alipayQRCode)}`}
                        alt="支付二维码"
                        width={200}
                        height={200}
                        className="rounded"
                      />
                    </div>
                    <p className="mt-3 text-sm text-gray-500">请使用支付宝扫码支付</p>
                  </div>
                ) : (
                  <div className="text-center py-8 text-gray-500">
                    获取二维码失败，请重试
                  </div>
                )}

                {!alipayLoading && alipayQRCode && (
                  <div className="mt-4 flex items-center justify-center gap-2 text-sm text-gray-500">
                    <Loader2 className="w-4 h-4 animate-spin" />
                    <span>等待支付中...</span>
                  </div>
                )}

                <p className="text-xs text-gray-400 text-center mt-3">
                  请在30分钟内完成支付，支付成功后将自动跳转
                </p>
              </>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
