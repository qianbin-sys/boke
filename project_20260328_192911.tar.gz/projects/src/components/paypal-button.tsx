'use client';

import { useEffect, useState, useRef } from 'react';
import { Loader2 } from 'lucide-react';

interface PayPalButtonProps {
  orderId: string;
  amount: number; // CNY金额
  currency?: string; // 默认USD
  onSuccess: () => void;
  onError: (error: string) => void;
  onCancel?: () => void;
}

interface PayPalConfig {
  enabled: boolean;
  clientId: string | null;
  mode: string;
}

declare global {
  interface Window {
    paypal?: {
      Buttons: (config: {
        createOrder: () => Promise<string>;
        onApprove: (data: { orderID: string }) => Promise<void>;
        onCancel?: () => void;
        onError?: (err: Error) => void;
      }) => {
        render: (container: string) => void;
      };
    };
  }
}

export function PayPalButton({ orderId, amount, currency = 'USD', onSuccess, onError, onCancel }: PayPalButtonProps) {
  const [config, setConfig] = useState<PayPalConfig | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [sdkLoaded, setSdkLoaded] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);
  const buttonsRendered = useRef(false);

  // 转换CNY到USD（汇率约0.14）
  const usdAmount = (amount * 0.14).toFixed(2);

  // 获取PayPal配置
  useEffect(() => {
    fetch('/api/payment/paypal/config')
      .then((res) => res.json())
      .then((data) => {
        setConfig(data);
        if (!data.enabled || !data.clientId) {
          setError('PayPal支付未启用或配置不完整');
        }
      })
      .catch((err) => {
        console.error('Failed to get PayPal config:', err);
        setError('获取PayPal配置失败');
      })
      .finally(() => setLoading(false));
  }, []);

  // 加载PayPal SDK
  useEffect(() => {
    if (!config?.clientId || !config.enabled) return;

    const scriptId = 'paypal-sdk';
    const existingScript = document.getElementById(scriptId);
    
    // 如果已存在脚本且货币相同，直接使用
    if (existingScript) {
      setSdkLoaded(true);
      return;
    }

    // 移除旧脚本（如果有不同货币）
    const oldScript = document.querySelector('script[src*="paypal.com/sdk"]');
    if (oldScript) {
      oldScript.remove();
    }

    const script = document.createElement('script');
    script.id = scriptId;
    script.src = `https://www.paypal.com/sdk/js?client-id=${config.clientId}&currency=${currency}&intent=capture`;
    script.async = true;
    script.onload = () => setSdkLoaded(true);
    script.onerror = () => {
      console.error('Failed to load PayPal SDK');
      setError('加载PayPal SDK失败');
    };
    document.head.appendChild(script);
  }, [config, currency]);

  // 渲染PayPal按钮
  useEffect(() => {
    if (!sdkLoaded || !window.paypal || buttonsRendered.current || !containerRef.current) return;

    buttonsRendered.current = true;

    window.paypal.Buttons({
      createOrder: async () => {
        try {
          const response = await fetch('/api/payment/paypal/create-order', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ orderId }),
          });

          const data = await response.json();

          if (!response.ok) {
            throw new Error(data.error || '创建订单失败');
          }

          return data.paypalOrderId;
        } catch (err) {
          console.error('Create order error:', err);
          onError(err instanceof Error ? err.message : '创建订单失败');
          throw err;
        }
      },
      onApprove: async (data) => {
        try {
          const response = await fetch('/api/payment/paypal/capture-order', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              paypalOrderId: data.orderID,
              orderId,
            }),
          });

          const result = await response.json();

          if (!response.ok) {
            throw new Error(result.error || '支付处理失败');
          }

          onSuccess();
        } catch (err) {
          console.error('Capture order error:', err);
          onError(err instanceof Error ? err.message : '支付处理失败');
        }
      },
      onCancel: () => {
        onCancel?.();
      },
      onError: (err) => {
        console.error('PayPal error:', err);
        onError('PayPal支付出错，请稍后重试');
      },
    }).render(`#paypal-button-container-${orderId}`);
  }, [sdkLoaded, orderId, onSuccess, onError, onCancel]);

  if (loading) {
    return (
      <div className="flex items-center justify-center py-4">
        <Loader2 className="w-5 h-5 animate-spin text-[#0ea5e9]" />
        <span className="ml-2 text-sm text-gray-500">加载PayPal...</span>
      </div>
    );
  }

  if (error) {
    return (
      <div className="text-center py-4 text-red-500 text-sm">
        {error}
      </div>
    );
  }

  if (!config?.enabled || !config.clientId) {
    return null;
  }

  return (
    <div className="w-full">
      <div className="text-center text-sm text-gray-500 mb-3">
        支付金额: <span className="font-semibold text-[#1e293b] dark:text-white">${usdAmount} USD</span>
        <span className="text-xs ml-1">(约 ¥{amount.toFixed(2)} CNY)</span>
      </div>
      <div 
        id={`paypal-button-container-${orderId}`}
        ref={containerRef}
        className="min-h-[50px]"
      />
    </div>
  );
}
