'use client';

import { useState, useRef, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Sparkles, Loader2, Check, AlertCircle } from 'lucide-react';

interface SEOOptimizerProps {
  title: string;
  content: string;
  excerpt?: string;
  category?: string;
  tags?: string[];
  seoTitle: string;
  seoDescription: string;
  seoKeywords: string;
  onApply: (data: { seo_title: string; seo_description: string; seo_keywords: string }) => void;
}

interface SEOResult {
  seo_title: string;
  seo_description: string;
  seo_keywords: string;
}

export function AISEOOptimizer({
  title,
  content,
  excerpt,
  category,
  tags,
  seoTitle,
  seoDescription,
  seoKeywords,
  onApply,
}: SEOOptimizerProps) {
  const [isGenerating, setIsGenerating] = useState(false);
  const [error, setError] = useState('');
  const [result, setResult] = useState<SEOResult | null>(null);
  const [previewContent, setPreviewContent] = useState('');
  const abortControllerRef = useRef<AbortController | null>(null);

  // 清理组件时中止请求
  useEffect(() => {
    return () => {
      if (abortControllerRef.current) {
        abortControllerRef.current.abort();
      }
    };
  }, []);

  const handleGenerate = async () => {
    if (!title || !content) {
      setError('请先填写文章标题和内容');
      return;
    }

    setIsGenerating(true);
    setError('');
    setResult(null);
    setPreviewContent('');

    // 创建新的 AbortController
    abortControllerRef.current = new AbortController();

    try {
      const response = await fetch('/api/ai-seo', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ title, content, excerpt, category, tags }),
        signal: abortControllerRef.current.signal,
      });

      if (!response.ok) {
        const data = await response.json();
        throw new Error(data.error || '生成失败');
      }

      const reader = response.body?.getReader();
      const decoder = new TextDecoder();

      if (!reader) {
        throw new Error('无法读取响应');
      }

      let fullContent = '';

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;

        const chunk = decoder.decode(value, { stream: true });
        const lines = chunk.split('\n');

        for (const line of lines) {
          if (line.startsWith('data: ')) {
            try {
              const data = JSON.parse(line.slice(6));
              
              if (data.error) {
                setError(data.error);
                setIsGenerating(false);
                return;
              }
              
              if (data.content) {
                fullContent += data.content;
                setPreviewContent(fullContent);
              }
              
              if (data.done && data.result) {
                setResult(data.result);
                setIsGenerating(false);
                return;
              }
            } catch {
              // 忽略解析错误
            }
          }
        }
      }
    } catch (err) {
      if (err instanceof Error && err.name === 'AbortError') {
        // 用户取消，不显示错误
        return;
      }
      setError(err instanceof Error ? err.message : '生成失败');
    } finally {
      setIsGenerating(false);
    }
  };

  const handleApply = () => {
    if (result) {
      onApply(result);
      setResult(null);
      setPreviewContent('');
    }
  };

  const handleCancel = () => {
    if (abortControllerRef.current) {
      abortControllerRef.current.abort();
    }
    setIsGenerating(false);
    setPreviewContent('');
    setError('');
  };

  const canGenerate = title.trim() && content.trim();

  return (
    <div className="space-y-4">
      {/* 生成按钮 */}
      <div className="flex items-center gap-2">
        <Button
          type="button"
          variant="outline"
          size="sm"
          onClick={handleGenerate}
          disabled={!canGenerate || isGenerating}
          className="flex items-center gap-2"
        >
          {isGenerating ? (
            <>
              <Loader2 className="w-4 h-4 animate-spin" />
              AI优化中...
            </>
          ) : (
            <>
              <Sparkles className="w-4 h-4" />
              AI自动优化
            </>
          )}
        </Button>
        
        {isGenerating && (
          <Button
            type="button"
            variant="ghost"
            size="sm"
            onClick={handleCancel}
            className="text-gray-500"
          >
            取消
          </Button>
        )}
      </div>

      {/* 错误提示 */}
      {error && (
        <div className="flex items-center gap-2 p-3 bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 rounded-lg text-red-700 dark:text-red-300 text-sm">
          <AlertCircle className="w-4 h-4 flex-shrink-0" />
          {error}
        </div>
      )}

      {/* 生成过程预览 */}
      {isGenerating && previewContent && (
        <div className="p-3 bg-gray-50 dark:bg-gray-800/50 border dark:border-gray-700 rounded-lg">
          <p className="text-xs text-gray-500 mb-2">AI正在生成...</p>
          <pre className="text-xs text-gray-600 dark:text-gray-400 whitespace-pre-wrap font-mono max-h-32 overflow-y-auto">
            {previewContent}
          </pre>
        </div>
      )}

      {/* 生成结果 */}
      {result && (
        <div className="space-y-4 p-4 bg-gradient-to-r from-blue-50 to-cyan-50 dark:from-blue-900/20 dark:to-cyan-900/20 border border-blue-200 dark:border-blue-800 rounded-lg">
          <div className="flex items-center justify-between">
            <h4 className="text-sm font-medium text-blue-700 dark:text-blue-300 flex items-center gap-2">
              <Sparkles className="w-4 h-4" />
              AI优化建议
            </h4>
            <Button
              type="button"
              size="sm"
              onClick={handleApply}
              className="bg-blue-500 hover:bg-blue-600"
            >
              <Check className="w-4 h-4 mr-1" />
              应用建议
            </Button>
          </div>

          <div className="space-y-3">
            <div>
              <Label className="text-xs text-gray-500">SEO标题</Label>
              <p className="text-sm text-gray-700 dark:text-gray-300 mt-1 p-2 bg-white/50 dark:bg-gray-800/50 rounded">
                {result.seo_title}
              </p>
              <p className="text-xs text-gray-400 mt-1">{result.seo_title.length}/60 字符</p>
            </div>

            <div>
              <Label className="text-xs text-gray-500">SEO描述</Label>
              <p className="text-sm text-gray-700 dark:text-gray-300 mt-1 p-2 bg-white/50 dark:bg-gray-800/50 rounded">
                {result.seo_description}
              </p>
              <p className="text-xs text-gray-400 mt-1">{result.seo_description.length}/160 字符</p>
            </div>

            <div>
              <Label className="text-xs text-gray-500">SEO关键词</Label>
              <div className="flex flex-wrap gap-1 mt-1">
                {result.seo_keywords.split(',').map((keyword, index) => (
                  <span
                    key={index}
                    className="inline-flex items-center px-2 py-0.5 rounded-full text-xs bg-blue-100 dark:bg-blue-900/30 text-blue-700 dark:text-blue-300"
                  >
                    {keyword.trim()}
                  </span>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* 当前值展示 */}
      {!result && !isGenerating && (seoTitle || seoDescription || seoKeywords) && (
        <div className="text-xs text-gray-500">
          <p>当前已设置：</p>
          <ul className="mt-1 space-y-1">
            {seoTitle && <li>• 标题: {seoTitle.substring(0, 50)}{seoTitle.length > 50 ? '...' : ''}</li>}
            {seoDescription && <li>• 描述: {seoDescription.substring(0, 50)}{seoDescription.length > 50 ? '...' : ''}</li>}
            {seoKeywords && <li>• 关键词: {seoKeywords.substring(0, 50)}{seoKeywords.length > 50 ? '...' : ''}</li>}
          </ul>
        </div>
      )}
    </div>
  );
}
