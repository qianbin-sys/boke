'use client';

import { useState, useEffect, useCallback } from 'react';
import { 
  Image, 
  Video, 
  FileText, 
  X, 
  Search,
  Upload,
  Check,
  RefreshCw,
  Loader2,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { useToast } from '@/hooks/use-toast';

interface MediaFile {
  id: string;
  filename: string;
  original_name: string;
  mime_type: string;
  size: number;
  url: string;
  created_at: string;
}

interface MediaPickerProps {
  open: boolean;
  onClose: () => void;
  onSelect: (file: MediaFile) => void;
  acceptTypes?: ('image' | 'video' | 'document')[];
  multiple?: boolean;
}

export function MediaPicker({ 
  open, 
  onClose, 
  onSelect, 
  acceptTypes = ['image'],
  multiple = false,
}: MediaPickerProps) {
  const [files, setFiles] = useState<MediaFile[]>([]);
  const [loading, setLoading] = useState(true);
  const [uploading, setUploading] = useState(false);
  const [page, setPage] = useState(1);
  const [total, setTotal] = useState(0);
  const [type, setType] = useState<string>(acceptTypes[0] || 'image');
  const [selectedFile, setSelectedFile] = useState<MediaFile | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const { toast } = useToast();

  const fetchFiles = useCallback(async () => {
    setLoading(true);
    try {
      const params = new URLSearchParams({
        page: page.toString(),
        limit: '30',
      });
      if (type !== 'all') {
        params.set('type', type);
      }

      const response = await fetch(`/api/media?${params}`);
      const data = await response.json();
      
      let filteredFiles = data.files || [];
      
      // 客户端搜索过滤
      if (searchQuery) {
        const query = searchQuery.toLowerCase();
        filteredFiles = filteredFiles.filter((file: MediaFile) =>
          file.original_name.toLowerCase().includes(query)
        );
      }
      
      setFiles(filteredFiles);
      setTotal(data.total || 0);
    } catch (error) {
      console.error('Failed to fetch files:', error);
      toast({
        title: '加载失败',
        description: '无法加载媒体文件',
        variant: 'destructive',
      });
    } finally {
      setLoading(false);
    }
  }, [page, type, searchQuery, toast]);

  useEffect(() => {
    if (open) {
      fetchFiles();
    }
  }, [open, fetchFiles]);

  const handleUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setUploading(true);
    try {
      const formData = new FormData();
      formData.append('file', file);

      const response = await fetch('/api/upload', {
        method: 'POST',
        body: formData,
      });

      const data = await response.json();
      
      if (data.success) {
        fetchFiles();
        toast({
          title: '上传成功',
          description: file.name,
        });
      } else {
        toast({
          title: '上传失败',
          description: data.error,
          variant: 'destructive',
        });
      }
    } catch (error) {
      console.error('Upload error:', error);
      toast({
        title: '上传失败',
        variant: 'destructive',
      });
    } finally {
      setUploading(false);
      e.target.value = '';
    }
  };

  const handleSelect = () => {
    if (selectedFile) {
      onSelect(selectedFile);
      setSelectedFile(null);
      onClose();
    }
  };

  const formatSize = (bytes: number) => {
    if (bytes < 1024) return bytes + ' B';
    if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' KB';
    return (bytes / (1024 * 1024)).toFixed(1) + ' MB';
  };

  const getFileIcon = (mimeType: string) => {
    if (mimeType.startsWith('image/')) return Image;
    if (mimeType.startsWith('video/')) return Video;
    return FileText;
  };

  const tabs = [
    { value: 'image', label: '图片', icon: Image },
    { value: 'video', label: '视频', icon: Video },
    { value: 'application', label: '文档', icon: FileText },
    { value: 'all', label: '全部', icon: null },
  ].filter(tab => tab.value === 'all' || acceptTypes.includes(tab.value as 'image' | 'video' | 'document'));

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-hidden flex flex-col">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Image className="w-5 h-5 text-[#0ea5e9]" />
            选择媒体文件
          </DialogTitle>
        </DialogHeader>

        <div className="flex items-center gap-2 py-2">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
            <Input
              placeholder="搜索文件名..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-9"
            />
          </div>
          <input
            type="file"
            id="media-upload"
            className="hidden"
            onChange={handleUpload}
            accept={acceptTypes.includes('image') ? 'image/*' : 
                    acceptTypes.includes('video') ? 'video/*' : '*'}
          />
          <label htmlFor="media-upload">
            <Button asChild variant="outline" className="cursor-pointer">
              <span>
                {uploading ? (
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                ) : (
                  <Upload className="w-4 h-4 mr-2" />
                )}
                {uploading ? '上传中...' : '上传'}
              </span>
            </Button>
          </label>
          <Button variant="outline" size="icon" onClick={fetchFiles}>
            <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
          </Button>
        </div>

        <Tabs value={type} onValueChange={(value) => { setType(value); setPage(1); }} className="flex-1 overflow-hidden flex flex-col">
          <TabsList className="w-fit">
            {tabs.map(tab => (
              <TabsTrigger key={tab.value} value={tab.value} className="flex items-center gap-1">
                {tab.icon && <tab.icon className="w-4 h-4" />}
                {tab.label}
              </TabsTrigger>
            ))}
          </TabsList>

          <TabsContent value={type} className="flex-1 overflow-auto mt-2">
            {loading ? (
              <div className="flex items-center justify-center h-64">
                <Loader2 className="w-8 h-8 animate-spin text-gray-400" />
              </div>
            ) : files.length === 0 ? (
              <div className="flex flex-col items-center justify-center h-64 text-gray-500">
                <Image className="w-12 h-12 mb-4 text-gray-300" />
                <p>暂无文件</p>
                <p className="text-sm text-gray-400 mt-1">点击上传按钮添加文件</p>
              </div>
            ) : (
              <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-5 lg:grid-cols-6 gap-3">
                {files.map((file) => {
                  const Icon = getFileIcon(file.mime_type);
                  const isImage = file.mime_type.startsWith('image/');
                  const isSelected = selectedFile?.id === file.id;
                  
                  return (
                    <div
                      key={file.id}
                      className={`group relative aspect-square rounded-lg border-2 overflow-hidden cursor-pointer transition-all ${
                        isSelected 
                          ? 'ring-2 ring-[#0ea5e9] border-[#0ea5e9]' 
                          : 'border-gray-200 dark:border-gray-700 hover:border-[#0ea5e9]'
                      }`}
                      onClick={() => setSelectedFile(file)}
                    >
                      {isImage ? (
                        <img
                          src={file.url}
                          alt={file.original_name}
                          className="w-full h-full object-cover"
                        />
                      ) : (
                        <div className="w-full h-full flex flex-col items-center justify-center bg-gray-100 dark:bg-gray-700 p-2">
                          <Icon className="w-8 h-8 text-gray-400" />
                          <span className="text-xs text-gray-500 mt-1 truncate w-full text-center">
                            {file.original_name}
                          </span>
                        </div>
                      )}
                      
                      {isSelected && (
                        <div className="absolute top-1 right-1 w-5 h-5 bg-[#0ea5e9] rounded-full flex items-center justify-center">
                          <Check className="w-3 h-3 text-white" />
                        </div>
                      )}
                      
                      <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/60 to-transparent p-2 opacity-0 group-hover:opacity-100 transition-opacity">
                        <p className="text-xs text-white truncate">{file.original_name}</p>
                        <p className="text-xs text-gray-300">{formatSize(file.size)}</p>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </TabsContent>
        </Tabs>

        <div className="flex items-center justify-between pt-4 border-t">
          <span className="text-sm text-gray-500">
            {selectedFile ? `已选择: ${selectedFile.original_name}` : '请选择一个文件'}
          </span>
          <div className="flex gap-2">
            <Button variant="outline" onClick={onClose}>
              取消
            </Button>
            <Button onClick={handleSelect} disabled={!selectedFile}>
              选择
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
