'use client';

import { useState, useEffect } from 'react';
import { Loader2, CreditCard, QrCode, X, CheckCircle2 } from 'lucide-react';

interface AlipayButtonProps {
  orderId: string;
  amount: number;
  onSuccess?: () => void;
  onError?: (error: string) => void;
}

// 简单的二维码生成组件
function QRCodeDisplay({ value, size = 200 }: { value: string; size?: number }) {
  // 使用支付宝官方二维码接口生成图片
  const qrImageUrl = `https://qr.alipay.com/${value.split('qr.alipay.com/')[1] || value}`;
  
  return (
    <div className="flex flex-col items-center">
      <div 
        className="bg-white p-4 rounded-lg shadow-inner"
        style={{ width: size + 32, height: size + 32 }}
      >
        {/* 使用第三方二维码API生成图片 */}
        <img 
          src={`https://api.qrserver.com/v1/create-qr-code/?size=${size}x${size}&data=${encodeURIComponent(value)}`}
          alt="支付二维码"
          width={size}
          height={size}
          className="rounded"
        />
      </div>
      <p className="mt-3 text-sm text-gray-500">请使用支付宝扫码支付</p>
    </div>
  );
}

export function AlipayButton({ orderId, amount, onSuccess, onError }: AlipayButtonProps) {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [qrCode, setQrCode] = useState<string | null>(null);
  const [showQRModal, setShowQRModal] = useState(false);
  const [polling, setPolling] = useState(false);
  const [paid, setPaid] = useState(false);

  // 轮询检查支付状态 - 通过支付宝主动查询接口确认
  useEffect(() => {
    if (!polling || !orderId) return;

    const pollPaymentStatus = async () => {
      try {
        // 先检查本地订单状态
        const orderResponse = await fetch(`/api/orders/${orderId}`);
        const orderData = await orderResponse.json();
        
        if (orderData.order?.payment_status === 'paid') {
          setPaid(true);
          setPolling(false);
          setTimeout(() => {
            onSuccess?.();
            window.location.href = '/account/membership?success=true';
          }, 1500);
          return;
        }

        // 主动查询支付宝订单状态
        const queryResponse = await fetch('/api/payment/alipay/query', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ orderNo: orderData.order?.order_no }),
        });
        const queryData = await queryResponse.json();

        if (queryData.paid) {
          setPaid(true);
          setPolling(false);
          setTimeout(() => {
            onSuccess?.();
            window.location.href = '/account/membership?success=true';
          }, 1500);
        }
      } catch (err) {
        console.error('Poll payment status error:', err);
      }
    };

    const interval = setInterval(pollPaymentStatus, 3000); // 每3秒检查一次
    
    // 立即执行一次
    pollPaymentStatus();

    return () => clearInterval(interval);
  }, [polling, orderId, onSuccess]);

  const handlePay = async () => {
    setLoading(true);
    setError(null);
    setQrCode(null);

    try {
      const response = await fetch('/api/payment/alipay/create', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ orderId }),
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || '创建支付订单失败');
      }

      if (data.qrCode) {
        setQrCode(data.qrCode);
        setShowQRModal(true);
        setPolling(true);
      } else {
        throw new Error('获取支付二维码失败');
      }
    } catch (err) {
      const errorMsg = err instanceof Error ? err.message : '支付失败';
      setError(errorMsg);
      onError?.(errorMsg);
    } finally {
      setLoading(false);
    }
  };

  const handleCloseModal = () => {
    setShowQRModal(false);
    setPolling(false);
  };

  return (
    <>
      <div className="w-full">
        {error && (
          <div className="mb-3 p-3 bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 rounded-lg text-red-600 dark:text-red-400 text-sm">
            {error}
          </div>
        )}
        
        <div className="text-center text-sm text-gray-500 mb-3">
          支付金额: <span className="font-semibold text-[#1e293b] dark:text-white">¥{amount.toFixed(2)}</span>
        </div>
        
        <button
          onClick={handlePay}
          disabled={loading}
          className="w-full py-3 rounded-xl font-medium transition-all flex items-center justify-center gap-2 bg-[#1677ff] text-white hover:bg-[#0958d9] shadow-md disabled:opacity-50 disabled:cursor-not-allowed"
        >
          {loading ? (
            <>
              <Loader2 className="w-5 h-5 animate-spin" />
              正在生成二维码...
            </>
          ) : (
            <>
              <QrCode className="w-5 h-5" />
              支付宝扫码支付
            </>
          )}
        </button>
        
        <p className="text-xs text-gray-400 text-center mt-2">
          点击按钮生成支付二维码
        </p>
      </div>

      {/* 二维码弹窗 */}
      {showQRModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm">
          <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-2xl p-6 max-w-sm w-full mx-4 relative">
            <button
              onClick={handleCloseModal}
              className="absolute top-4 right-4 p-1 rounded-full hover:bg-gray-100 dark:hover:bg-gray-700"
            >
              <X className="w-5 h-5 text-gray-500" />
            </button>

            {paid ? (
              <div className="flex flex-col items-center py-8">
                <CheckCircle2 className="w-16 h-16 text-green-500 mb-4" />
                <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-2">支付成功</h3>
                <p className="text-gray-500">正在跳转到会员中心...</p>
              </div>
            ) : (
              <>
                <div className="text-center mb-4">
                  <h3 className="text-lg font-bold text-gray-900 dark:text-white flex items-center justify-center gap-2">
                    <CreditCard className="w-5 h-5 text-[#1677ff]" />
                    支付宝扫码支付
                  </h3>
                  <p className="text-2xl font-bold text-[#1677ff] mt-2">¥{amount.toFixed(2)}</p>
                </div>

                {qrCode && (
                  <QRCodeDisplay value={qrCode} size={200} />
                )}

                <div className="mt-4 flex items-center justify-center gap-2 text-sm text-gray-500">
                  <Loader2 className="w-4 h-4 animate-spin" />
                  <span>等待支付中...</span>
                </div>

                <p className="text-xs text-gray-400 text-center mt-3">
                  请在30分钟内完成支付，支付成功后将自动跳转
                </p>
              </>
            )}
          </div>
        </div>
      )}
    </>
  );
}
