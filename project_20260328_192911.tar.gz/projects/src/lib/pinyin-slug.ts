import { pinyin } from 'pinyin-pro';

/**
 * 将中文文本转换为拼音首字母
 * 英文和数字保持原样
 * 
 * @param text 输入文本
 * @returns 拼音首字母组合
 * 
 * @example
 * generatePinyinSlug('你好世界') // 'nhsj'
 * generatePinyinSlug('Python开发教程') // 'pythonkfjc'
 * generatePinyinSlug('今日头条新闻2024') // 'jrttxw2024'
 */
export function generatePinyinSlug(text: string): string {
  if (!text) return '';
  
  let result = '';
  
  for (const char of text) {
    // 跳过空格和特殊字符
    if (/[\s\-_]/.test(char)) {
      continue;
    }
    
    // 英文字母和数字保持原样（转小写）
    if (/[a-zA-Z0-9]/.test(char)) {
      result += char.toLowerCase();
      continue;
    }
    
    // 中文字符转换为拼音首字母
    if (/[\u4e00-\u9fa5]/.test(char)) {
      const py = pinyin(char, { pattern: 'first', toneType: 'none' });
      result += py.toLowerCase();
      continue;
    }
    
    // 其他字符跳过
  }
  
  return result;
}

/**
 * 生成唯一的slug（如果冲突则添加后缀）
 * 
 * @param title 文章标题
 * @returns slug字符串
 */
export function generateUniqueSlug(title: string): string {
  return generatePinyinSlug(title);
}
