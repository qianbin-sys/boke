/**
 * AI模型服务
 * 支持动态选择和调用配置的AI模型
 */

import { LLMClient, Config, ImageGenerationClient } from 'coze-coding-dev-sdk';
import { getSupabaseClient } from '@/storage/database/supabase-client';

export interface AIModel {
  id: string;
  name: string;
  provider: string;
  model_type: 'llm' | 'image';
  model_id: string;
  api_endpoint: string | null;
  api_key_encrypted: string | null;
  config: Record<string, unknown>;
  is_enabled: boolean;
  is_default: boolean;
  priority: number;
}

export interface LLMMessage {
  role: 'system' | 'user' | 'assistant';
  content: string;
}

export interface LLMOptions {
  model?: string;
  modelId?: string; // 指定模型数据库ID
  maxTokens?: number;
  temperature?: number;
  topP?: number;
  stream?: boolean;
}

export interface ImageGenerationOptions {
  model?: string;
  modelId?: string; // 指定模型数据库ID
  size?: '720p' | '1080p' | '2K' | '4K';
}

/**
 * 获取默认或指定的模型配置
 */
export async function getModelConfig(
  modelType: 'llm' | 'image',
  modelId?: string
): Promise<AIModel | null> {
  const supabase = getSupabaseClient();

  let query = supabase
    .from('ai_models')
    .select('*')
    .eq('model_type', modelType)
    .eq('is_enabled', true);

  if (modelId) {
    query = query.eq('id', modelId);
  } else {
    // 优先使用默认模型，其次按优先级选择
    query = query.order('is_default', { ascending: false })
                 .order('priority', { ascending: false });
  }

  const { data: models, error } = await query.limit(1);

  if (error || !models || models.length === 0) {
    return null;
  }

  return models[0] as AIModel;
}

/**
 * 创建LLM客户端
 */
export function createLLMClient(model: AIModel): {
  client: LLMClient | null;
  customConfig: { endpoint: string; apiKey: string } | null;
} {
  // 豆包默认使用SDK
  if (model.provider === 'doubao' && !model.api_key_encrypted) {
    const config = new Config();
    return { client: new LLMClient(config), customConfig: null };
  }

  // 其他提供商或自定义配置
  if (model.api_endpoint && model.api_key_encrypted) {
    return {
      client: null,
      customConfig: {
        endpoint: model.api_endpoint,
        apiKey: model.api_key_encrypted,
      },
    };
  }

  throw new Error(`模型 ${model.name} 缺少必要的API配置`);
}

/**
 * 创建图片生成客户端
 */
export function createImageClient(model: AIModel): {
  client: ImageGenerationClient | null;
  customConfig: { endpoint: string; apiKey: string } | null;
} {
  // 豆包默认使用SDK
  if (model.provider === 'doubao' && !model.api_key_encrypted) {
    const config = new Config();
    return { client: new ImageGenerationClient(config), customConfig: null };
  }

  // 其他提供商暂不支持
  throw new Error(`图片模型 ${model.name} 暂不支持自定义配置`);
}

/**
 * 调用LLM（流式输出）
 */
export async function* streamLLM(
  messages: LLMMessage[],
  options: LLMOptions = {}
): AsyncGenerator<string, void, unknown> {
  // 获取模型配置
  const model = await getModelConfig('llm', options.modelId);
  
  if (!model) {
    throw new Error('未找到可用的LLM模型');
  }

  const { client, customConfig } = createLLMClient(model);

  // 使用SDK客户端
  if (client) {
    const stream = client.stream(messages, {
      model: options.model || model.model_id,
      temperature: options.temperature,
    });

    for await (const chunk of stream) {
      if (chunk.content) {
        yield chunk.content.toString();
      }
    }
    return;
  }

  // 使用自定义API
  if (customConfig) {
    const response = await fetch(`${customConfig.endpoint}/chat/completions`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${customConfig.apiKey}`,
      },
      body: JSON.stringify({
        model: options.model || model.model_id,
        messages,
        max_tokens: options.maxTokens || 4096,
        temperature: options.temperature,
        top_p: options.topP,
        stream: true,
      }),
    });

    if (!response.ok) {
      throw new Error(`LLM API错误: ${response.status}`);
    }

    const reader = response.body?.getReader();
    if (!reader) {
      throw new Error('无法读取响应流');
    }

    const decoder = new TextDecoder();
    let buffer = '';

    while (true) {
      const { done, value } = await reader.read();
      if (done) break;

      buffer += decoder.decode(value, { stream: true });
      const lines = buffer.split('\n');
      buffer = lines.pop() || '';

      for (const line of lines) {
        if (line.startsWith('data: ')) {
          const data = line.slice(6);
          if (data === '[DONE]') continue;
          
          try {
            const parsed = JSON.parse(data);
            const content = parsed.choices?.[0]?.delta?.content;
            if (content) {
              yield content;
            }
          } catch {
            // 忽略解析错误
          }
        }
      }
    }
  }
}

/**
 * 调用LLM（非流式）
 */
export async function callLLM(
  messages: LLMMessage[],
  options: LLMOptions = {}
): Promise<string> {
  let fullContent = '';
  for await (const chunk of streamLLM(messages, options)) {
    fullContent += chunk;
  }
  return fullContent;
}

/**
 * 生成图片
 */
export async function generateImage(
  prompt: string,
  options: ImageGenerationOptions = {}
): Promise<string[]> {
  // 获取模型配置
  const model = await getModelConfig('image', options.modelId);
  
  if (!model) {
    throw new Error('未找到可用的图片生成模型');
  }

  const { client } = createImageClient(model);

  if (!client) {
    throw new Error('图片模型暂不支持自定义配置');
  }

  const response = await client.generate({
    prompt,
    size: options.size || '2K',
  });

  const helper = client.getResponseHelper(response);

  if (helper.success) {
    return helper.imageUrls;
  }

  throw new Error(helper.errorMessages.join(', ') || '图片生成失败');
}

/**
 * 获取所有可用的LLM模型
 */
export async function getAvailableLLMModels(): Promise<AIModel[]> {
  const supabase = getSupabaseClient();
  
  const { data: models, error } = await supabase
    .from('ai_models')
    .select('*')
    .eq('model_type', 'llm')
    .eq('is_enabled', true)
    .order('is_default', { ascending: false })
    .order('priority', { ascending: false });

  if (error) {
    console.error('Get LLM models error:', error);
    return [];
  }

  return (models || []) as AIModel[];
}

/**
 * 获取所有可用的图片模型
 */
export async function getAvailableImageModels(): Promise<AIModel[]> {
  const supabase = getSupabaseClient();
  
  const { data: models, error } = await supabase
    .from('ai_models')
    .select('*')
    .eq('model_type', 'image')
    .eq('is_enabled', true)
    .order('is_default', { ascending: false })
    .order('priority', { ascending: false });

  if (error) {
    console.error('Get image models error:', error);
    return [];
  }

  return (models || []) as AIModel[];
}
