import { LLMClient, Config } from 'coze-coding-dev-sdk';
import { getSupabaseClient } from '@/storage/database/supabase-client';
import { generateCoverImage } from './generate-cover-image';
import { generatePinyinSlug } from './pinyin-slug';
import { getModelConfig, createLLMClient } from './ai-model-service';

interface TaskConfig {
  id: string;
  name: string;
  article_type: string;
  writing_style: string;
  article_length: number;
  publish_interval: number;
  category_id: string | null;
  tags: string[];
}

interface ExecutionResult {
  success: boolean;
  postId?: string;
  title?: string;
  error?: string;
}

/**
 * 清理Markdown格式符号（#和*）
 */
function cleanMarkdownSymbols(text: string): string {
  let cleaned = text;
  
  // 移除标题标记 # ## ### 等（行首的#）
  cleaned = cleaned.replace(/^#{1,6}\s+/gm, '');
  
  // 移除粗体标记 **text** 或 __text__
  cleaned = cleaned.replace(/\*\*([^*]+)\*\*/g, '$1');
  cleaned = cleaned.replace(/__([^_]+)__/g, '$1');
  
  // 移除斜体标记 *text* 或 _text_（注意不要匹配中文）
  cleaned = cleaned.replace(/\*([^*\n]+)\*/g, '$1');
  cleaned = cleaned.replace(/_([^_\n]+)_/g, '$1');
  
  // 移除删除线 ~~text~~
  cleaned = cleaned.replace(/~~([^~]+)~~/g, '$1');
  
  // 移除列表标记（行首的 - 或 * 后跟空格）
  cleaned = cleaned.replace(/^[\*\-]\s+/gm, '');
  
  // 移除数字列表标记（如 1. 2. 等，但保留内容）
  // cleaned = cleaned.replace(/^\d+\.\s+/gm, '');
  
  // 清理多余的空行（超过2个连续空行变为2个）
  cleaned = cleaned.replace(/\n{3,}/g, '\n\n');
  
  return cleaned.trim();
}

/**
 * 生成SEO元数据
 */
async function generateSEOData(
  title: string,
  content: string,
  categoryName?: string,
  tagNames?: string[]
): Promise<{ seoTitle: string; seoDescription: string; seoKeywords: string }> {
  // 获取模型配置
  const modelConfig = await getModelConfig('llm');
  
  const systemPrompt = `你是一位SEO优化专家。请根据提供的文章信息生成优化的SEO元数据。
要求：
1. SEO标题：简洁有吸引力，包含主要关键词，控制在60字符以内
2. SEO描述：概括文章核心内容，吸引用户点击，控制在120-160字符
3. SEO关键词：3-5个核心关键词，用逗号分隔

请严格按照以下JSON格式输出，不要包含其他内容：
{"seo_title":"...","seo_description":"...","seo_keywords":"..."}`;

  const tagList = tagNames?.length ? tagNames.join('、') : '';
  const userContent = `文章标题：${title}
文章摘要：${content.substring(0, 500)}
${categoryName ? `分类：${categoryName}` : ''}
${tagList ? `标签：${tagList}` : ''}

请生成SEO元数据。`;

  const messages = [
    { role: 'system' as const, content: systemPrompt },
    { role: 'user' as const, content: userContent }
  ];

  try {
    let fullResponse = '';
    
    if (modelConfig) {
      const { client, customConfig } = createLLMClient(modelConfig);
      
      if (client) {
        // 使用SDK客户端
        const stream = client.stream(messages, {
          temperature: 0.5,
          model: modelConfig.model_id,
        });

        for await (const chunk of stream) {
          if (chunk.content) {
            fullResponse += chunk.content.toString();
          }
        }
      } else if (customConfig) {
        // 使用自定义API
        const response = await fetch(`${customConfig.endpoint}/chat/completions`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${customConfig.apiKey}`,
          },
          body: JSON.stringify({
            model: modelConfig.model_id,
            messages,
            temperature: 0.5,
          }),
        });

        if (response.ok) {
          const data = await response.json();
          fullResponse = data.choices?.[0]?.message?.content || '';
        }
      }
    } else {
      // 使用默认配置
      const config = new Config();
      const client = new LLMClient(config);
      const stream = client.stream(messages, {
        temperature: 0.5,
        model: 'doubao-seed-2-0-pro-260215',
      });

      for await (const chunk of stream) {
        if (chunk.content) {
          fullResponse += chunk.content.toString();
        }
      }
    }

    // 解析JSON
    const jsonMatch = fullResponse.match(/\{[\s\S]*\}/);
    if (jsonMatch) {
      const seoData = JSON.parse(jsonMatch[0]);
      return {
        seoTitle: seoData.seo_title || title,
        seoDescription: seoData.seo_description || content.substring(0, 160),
        seoKeywords: seoData.seo_keywords || '',
      };
    }
  } catch (error) {
    console.error('Generate SEO data error:', error);
  }

  // 降级处理：使用默认值
  return {
    seoTitle: title,
    seoDescription: content.substring(0, 160),
    seoKeywords: categoryName ? `${categoryName},${title.split(' ').slice(0, 3).join(',')}` : '',
  };
}

/**
 * 执行AI任务
 */
export async function executeAITask(taskId: string, userId: string): Promise<ExecutionResult> {
  const supabase = getSupabaseClient();
  const startTime = Date.now();
  
  try {
    // 获取任务配置
    const { data: task, error: taskError } = await supabase
      .from('ai_scheduled_tasks')
      .select('*')
      .eq('id', taskId)
      .single();

    if (taskError || !task) {
      throw new Error('任务不存在');
    }

    // 生成文章主题
    const topic = await generateArticleTopic(task.article_type);
    
    // 调用AI生成文章
    const article = await generateArticle({
      topic,
      style: task.writing_style,
      length: task.article_length,
    });

    if (!article.title || !article.content) {
      throw new Error('文章生成失败');
    }

    // 清理Markdown格式符号（#和*）
    const cleanedContent = cleanMarkdownSymbols(article.content);
    const cleanedTitle = cleanMarkdownSymbols(article.title);

    // 获取分类名称和标签名称（用于SEO）
    let categoryName = '';
    if (task.category_id) {
      const { data: category } = await supabase
        .from('categories')
        .select('name')
        .eq('id', task.category_id)
        .single();
      categoryName = category?.name || '';
    }

    let tagNames: string[] = [];
    if (task.tags && task.tags.length > 0) {
      const { data: tagData } = await supabase
        .from('tags')
        .select('name')
        .in('id', task.tags);
      tagNames = tagData?.map((t: { name: string }) => t.name) || [];
    }

    // 生成SEO元数据
    const seoData = await generateSEOData(
      cleanedTitle,
      cleanedContent,
      categoryName,
      tagNames
    );

    // 生成封面图
    const coverResult = await generateCoverImage({
      title: cleanedTitle,
      content: cleanedContent,
      userId,
    });

    // 生成文章别名
    const slug = generatePinyinSlug(cleanedTitle);
    
    // 提取摘要
    const excerpt = cleanedContent.substring(0, 200);

    // 发布文章（包含SEO数据）
    const { data: post, error: postError } = await supabase
      .from('posts')
      .insert({
        title: cleanedTitle,
        slug,
        content: cleanedContent,
        excerpt,
        category_id: task.category_id,
        featured_image: coverResult.imageUrl || null,
        status: 'published',
        author_id: userId,
        published_at: new Date().toISOString(),
        // SEO字段
        seo_title: seoData.seoTitle,
        seo_description: seoData.seoDescription,
        seo_keywords: seoData.seoKeywords,
      })
      .select()
      .single();

    if (postError) {
      throw new Error(`发布文章失败: ${postError.message}`);
    }

    // 关联标签
    if (task.tags && task.tags.length > 0) {
      const tagInserts = task.tags.map((tagId: string) => ({
        post_id: post.id,
        tag_id: tagId,
      }));
      
      await supabase.from('post_tags').insert(tagInserts);
    }

    const executionTime = Math.round((Date.now() - startTime) / 1000);

    // 记录执行日志 - 成功
    await supabase.from('ai_task_logs').insert({
      task_id: taskId,
      post_id: post.id,
      title: cleanedTitle,
      status: 'success',
      execution_time: executionTime,
    });

    // 更新任务状态
    const nextRunAt = new Date();
    nextRunAt.setHours(nextRunAt.getHours() + task.publish_interval);
    
    await supabase
      .from('ai_scheduled_tasks')
      .update({
        last_run_at: new Date().toISOString(),
        next_run_at: nextRunAt.toISOString(),
        total_published: (task.total_published || 0) + 1,
        updated_at: new Date().toISOString(),
      })
      .eq('id', taskId);

    return {
      success: true,
      postId: post.id,
      title: cleanedTitle,
    };
  } catch (error) {
    const executionTime = Math.round((Date.now() - startTime) / 1000);
    
    // 记录执行日志 - 失败
    await supabase.from('ai_task_logs').insert({
      task_id: taskId,
      status: 'failed',
      error_message: error instanceof Error ? error.message : '未知错误',
      execution_time: executionTime,
    });

    return {
      success: false,
      error: error instanceof Error ? error.message : '执行失败',
    };
  }
}

/**
 * 生成文章主题
 */
async function generateArticleTopic(articleType: string): Promise<string> {
  // 文章类型对应的主题池
  const topicPools: Record<string, string[]> = {
    '水果': [
      '苹果的种植技术与病虫害防治',
      '葡萄栽培要点与采收技巧',
      '柑橘类水果的嫁接方法',
      '草莓立体种植技术',
      '桃树修剪与整形技术',
      '樱桃种植的土壤要求',
      '猕猴桃人工授粉技术',
      '芒果种植的温度管理',
      '荔枝保花保果技术',
      '蓝莓种植的酸碱度调节',
      '火龙果的支架栽培技术',
      '西瓜嫁接育苗技术',
      '柿子脱涩与储存方法',
      '石榴修剪与花果管理',
      '无花果的扦插繁殖技术',
      '香蕉的吸芽繁殖方法',
      '龙眼保花保果管理',
      '杨梅的嫁接育苗技术',
      '枇杷的套袋技术',
      '枣树的高接换种技术',
    ],
    '花草种植': [
      '玫瑰的扦插繁殖技巧',
      '兰花的分株与换盆技术',
      '月季的修剪与花期调控',
      '多肉植物的叶插繁殖',
      '君子兰的四季养护要点',
      '茉莉花的促花技巧',
      '栀子花的土壤配制',
      '绣球花调色技术',
      '牡丹的分株繁殖方法',
      '菊花的摘心与整形',
      '蝴蝶兰的家庭养护',
      '杜鹃花的酸碱性调节',
      '茶花的疏蕾技术',
      '百合花的种球种植',
      '向日葵的播种时间与方法',
      '康乃馨的扦插繁殖',
      '薰衣草的修剪与采收',
      '芍药的种植与分株',
      '睡莲的水培技术',
      '荷花的种植与越冬管理',
    ],
    '蔬菜种植': [
      '番茄的整枝打杈技术',
      '黄瓜的嫁接育苗方法',
      '辣椒的病虫害防治',
      '茄子的整枝技巧',
      '豆角的支架栽培技术',
      '生菜的水培种植',
      '白菜的播种时间与方法',
      '菠菜的反季节种植',
      '萝卜的肉质根管理',
      '胡萝卜的土壤要求',
    ],
    '园艺技术': [
      '阳台蔬菜种植指南',
      '家庭花园设计布局',
      '盆栽植物的换盆技巧',
      '植物扦插的生根方法',
      '园艺工具的选购与保养',
      '有机肥料的制作方法',
      '堆肥的制作与应用',
      '植物病虫害的生态防治',
      '温室种植的温度控制',
      '滴灌系统的安装与维护',
    ],
  };

  // 获取对应类型的主题池
  const topics = topicPools[articleType] || topicPools['园艺技术'];
  
  // 随机选择一个主题
  const randomIndex = Math.floor(Math.random() * topics.length);
  return topics[randomIndex];
}

/**
 * 调用AI生成文章
 */
async function generateArticle(options: {
  topic: string;
  style: string;
  length: number;
}): Promise<{ title: string; content: string }> {
  const { topic, style, length } = options;

  // 获取模型配置
  const modelConfig = await getModelConfig('llm');

  const styleMap: Record<string, string> = {
    'professional': '专业严谨',
    'casual': '轻松活泼',
    'academic': '学术研究',
    'storytelling': '故事叙述',
    'tutorial': '教程指南',
  };

  const systemPrompt = `你是一位专业的农业和园艺领域的内容创作专家，擅长撰写实用的种植技术文章。
请根据用户的主题创作一篇高质量的文章，注意：
1. 文章标题要简洁明确，突出主题
2. 内容要实用、专业，有具体的技术要点
3. 结构清晰，分章节讲解
4. 包含实际操作步骤和注意事项
5. 适当加入常见问题解答
写作风格：${styleMap[style] || '专业严谨'}
文章长度：约${length}字

重要格式要求：
- 第一行直接输出标题（不要加#号）
- 正文内容不要使用任何Markdown格式符号（如#、*、_等）
- 使用自然的段落分隔和数字编号来组织内容
- 直接输出纯文本格式的文章

请直接输出文章内容，第一行为标题，然后是正文内容。`;

  const messages = [
    { role: 'system' as const, content: systemPrompt },
    { role: 'user' as const, content: `请写一篇关于"${topic}"的文章` }
  ];

  let fullContent = '';

  try {
    if (modelConfig) {
      const { client, customConfig } = createLLMClient(modelConfig);
      
      if (client) {
        // 使用SDK客户端
        const stream = client.stream(messages, {
          temperature: 0.8,
          model: modelConfig.model_id,
        });

        for await (const chunk of stream) {
          if (chunk.content) {
            fullContent += chunk.content.toString();
          }
        }
      } else if (customConfig) {
        // 使用自定义API
        const response = await fetch(`${customConfig.endpoint}/chat/completions`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${customConfig.apiKey}`,
          },
          body: JSON.stringify({
            model: modelConfig.model_id,
            messages,
            temperature: 0.8,
          }),
        });

        if (response.ok) {
          const data = await response.json();
          fullContent = data.choices?.[0]?.message?.content || '';
        }
      }
    } else {
      // 使用默认配置
      const config = new Config();
      const client = new LLMClient(config);
      const stream = client.stream(messages, {
        temperature: 0.8,
        model: 'doubao-seed-2-0-pro-260215',
      });

      for await (const chunk of stream) {
        if (chunk.content) {
          fullContent += chunk.content.toString();
        }
      }
    }

    // 提取标题（第一行）
    const lines = fullContent.split('\n').filter(line => line.trim());
    const title = lines[0]?.replace(/^#+\s*/, '').trim() || topic;

    return {
      title,
      content: fullContent,
    };
  } catch (error) {
    console.error('Generate article error:', error);
    throw new Error('文章生成失败');
  }
}

/**
 * 检查并执行到期的任务（供定时调用）
 */
export async function checkAndExecuteTasks(): Promise<void> {
  const supabase = getSupabaseClient();
  
  // 查找到期的活跃任务
  const now = new Date().toISOString();
  const { data: tasks, error } = await supabase
    .from('ai_scheduled_tasks')
    .select('*')
    .eq('status', 'active')
    .lte('next_run_at', now);

  if (error || !tasks || tasks.length === 0) {
    return;
  }

  // 逐个执行任务
  for (const task of tasks) {
    try {
      console.log(`Executing task: ${task.name} (${task.id})`);
      await executeAITask(task.id, task.created_by);
    } catch (error) {
      console.error(`Failed to execute task ${task.id}:`, error);
    }
  }
}
