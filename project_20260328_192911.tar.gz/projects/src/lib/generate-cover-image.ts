import { ImageGenerationClient, Config, HeaderUtils } from 'coze-coding-dev-sdk';
import { S3Storage } from 'coze-coding-dev-sdk';
import { getSupabaseClient } from '@/storage/database/supabase-client';

interface GenerateCoverImageOptions {
  title: string;
  content?: string;
  userId: string;
  customHeaders?: Record<string, string>;
}

interface GenerateCoverImageResult {
  success: boolean;
  imageUrl?: string;
  mediaId?: string;
  error?: string;
}

// 初始化存储
const storage = new S3Storage({
  endpointUrl: process.env.COZE_BUCKET_ENDPOINT_URL,
  accessKey: '',
  secretKey: '',
  bucketName: process.env.COZE_BUCKET_NAME,
  region: 'cn-beijing',
});

/**
 * 根据文章标题生成封面图
 */
export async function generateCoverImage(options: GenerateCoverImageOptions): Promise<GenerateCoverImageResult> {
  const { title, content, userId, customHeaders } = options;

  try {
    // 构建图片生成提示词
    const imagePrompt = buildImagePrompt(title, content);
    
    // 生成图片
    const config = new Config();
    const client = new ImageGenerationClient(config, customHeaders);
    
    const response = await client.generate({
      prompt: imagePrompt,
      size: '2K',
      watermark: false,
    });

    const helper = client.getResponseHelper(response);

    if (!helper.success || !helper.imageUrls[0]) {
      return {
        success: false,
        error: helper.errorMessages.join(', ') || '图片生成失败',
      };
    }

    // 下载生成的图片
    const imageUrl = helper.imageUrls[0];
    const imageResponse = await fetch(imageUrl);
    
    if (!imageResponse.ok) {
      return {
        success: false,
        error: '下载生成的图片失败',
      };
    }

    const imageBuffer = Buffer.from(await imageResponse.arrayBuffer());

    // 上传到对象存储
    const timestamp = Date.now();
    const randomStr = Math.random().toString(36).substring(2, 8);
    const fileName = `media/covers/${timestamp}_${randomStr}.png`;
    
    const fileKey = await storage.uploadFile({
      fileContent: imageBuffer,
      fileName,
      contentType: 'image/png',
    });

    // 生成访问URL (有效期30天)
    const storedUrl = await storage.generatePresignedUrl({
      key: fileKey,
      expireTime: 30 * 24 * 60 * 60,
    });

    // 保存到数据库
    const supabase = getSupabaseClient();
    const { data: mediaRecord, error: dbError } = await supabase
      .from('media')
      .insert({
        filename: fileKey,
        original_name: `${title.substring(0, 30)}_封面.png`,
        mime_type: 'image/png',
        size: imageBuffer.length,
        url: storedUrl,
        uploader_id: userId,
      })
      .select()
      .single();

    if (dbError) {
      console.error('Database save error:', dbError);
      // 图片已上传，但数据库保存失败，仍返回URL
    }

    return {
      success: true,
      imageUrl: storedUrl,
      mediaId: mediaRecord?.id,
    };
  } catch (error) {
    console.error('Generate cover image error:', error);
    return {
      success: false,
      error: error instanceof Error ? error.message : '生成封面图失败',
    };
  }
}

/**
 * 构建图片生成提示词 - 写实风格
 */
function buildImagePrompt(title: string, content?: string): string {
  // 基于标题生成图片描述
  // 提取标题中的关键词
  const keywords = extractKeywords(title);
  
  // 构建写实风格的封面图提示词
  const basePrompt = `Create a photorealistic, professional blog cover image with the following theme: ${keywords}. 

CRITICAL REQUIREMENTS - ABSOLUTELY NO TEXT:
- ZERO text, words, letters, characters, numbers, or typography of ANY kind
- NO written content in ANY language (no Chinese, English, or any other language)
- NO captions, titles, labels, or watermarks
- NO signatures or artist names
- The image must be 100% text-free

Photorealistic Style Requirements:
- Ultra-realistic photography style, like a professional DSLR photo
- Natural lighting and authentic color reproduction
- Sharp focus and high detail throughout
- Realistic depth of field when appropriate
- No filters, special effects, or artificial enhancements
- Authentic textures and materials (soil, leaves, bark, water droplets, etc.)
- Natural composition following photography principles (rule of thirds, leading lines)
- Cinematic quality with natural ambient lighting

Subject Matter:
- Real plants, fruits, vegetables, or gardens in natural settings
- Authentic agricultural or gardening scenes
- Close-up macro shots of natural elements (leaves, flowers, fruits)
- Natural outdoor environments with realistic weather and lighting
- Professional food photography style for edible plants/fruits

Technical Specifications:
- High resolution, 2K quality
- Professional photography aesthetic
- Suitable for blog post covers
- Rich, natural colors with accurate representation
- No artificial or cartoon-like elements

IMPORTANT: Generate a photorealistic image that looks like a real photograph taken by a professional photographer, with absolutely no text or graphic design elements.`;

  return basePrompt;
}

/**
 * 从标题提取关键词
 */
function extractKeywords(title: string): string {
  // 移除常见的中英文停用词
  const stopWords = ['的', '了', '和', '是', '在', '有', '与', '为', '对', '这', '那', 'the', 'a', 'an', 'is', 'are', 'was', 'were', 'be', 'been', 'being', 'have', 'has', 'had', 'do', 'does', 'did', 'will', 'would', 'could', 'should', 'may', 'might', 'must', 'shall', 'can', 'need', 'dare', 'ought', 'used', 'to', 'of', 'in', 'for', 'on', 'with', 'at', 'by', 'from', 'as', 'into', 'through', 'during', 'before', 'after', 'above', 'below', 'between', 'under', 'again', 'further', 'then', 'once', 'and', 'but', 'or', 'nor', 'so', 'yet', 'both', 'either', 'neither', 'not', 'only', 'own', 'same', 'than', 'too', 'very', 'just'];
  
  // 分词（简单按空格和常见标点分割）
  const words = title
    .toLowerCase()
    .replace(/[，。！？、；：""''【】（）\[\]().,!?;:'"-]/g, ' ')
    .split(/\s+/)
    .filter(word => word.length > 1 && !stopWords.includes(word));
  
  // 返回前几个关键词
  const keywords = words.slice(0, 5).join(', ');
  
  return keywords || title.substring(0, 50);
}
