import { getSupabaseClient } from '@/storage/database/supabase-client';

/**
 * 处理支付成功后的订单更新和会员开通
 * @param orderId 订单ID
 * @param transactionId 支付平台返回的交易ID
 * @param paymentMethod 支付方式
 */
export async function handlePaymentSuccess(
  orderId: string,
  transactionId: string,
  paymentMethod: string
): Promise<{ success: boolean; error?: string }> {
  const client = getSupabaseClient();

  try {
    // 获取订单
    const { data: order, error: orderError } = await client
      .from('orders')
      .select('*')
      .eq('id', orderId)
      .eq('payment_status', 'pending')
      .single();

    if (orderError || !order) {
      return { success: false, error: '订单不存在或已支付' };
    }

    const metadata = order.metadata as Record<string, unknown>;

    // 1. 更新订单状态
    const { error: updateError } = await client
      .from('orders')
      .update({
        payment_status: 'paid',
        paid_at: new Date().toISOString(),
        transaction_id: transactionId,
      })
      .eq('id', orderId);

    if (updateError) {
      console.error('Update order error:', updateError);
      return { success: false, error: updateError.message };
    }

    // 2. 根据订单类型处理
    if (metadata.plan_id) {
      // 会员订单 - 创建或更新会员记录
      const planId = metadata.plan_id as string;
      const durationDays = metadata.duration_days as number;
      const userId = order.user_id as string;
      const isLifetime = durationDays === 0;

      // 检查是否已有会员记录
      const { data: existingMembership } = await client
        .from('user_memberships')
        .select('*')
        .eq('user_id', userId)
        .maybeSingle();

      let expiredAt: Date | null = null;

      if (isLifetime) {
        // 永久会员，无过期时间
        expiredAt = null;
      } else if (existingMembership) {
        // 已有会员记录，在现有到期时间基础上顺延
        const currentExpiredAt = existingMembership.expired_at 
          ? new Date(existingMembership.expired_at) 
          : null;
        
        // 如果当前会员已过期，从现在开始计算；否则从到期时间开始计算
        const baseDate = currentExpiredAt && currentExpiredAt > new Date() 
          ? currentExpiredAt 
          : new Date();
        
        expiredAt = new Date(baseDate);
        expiredAt.setDate(expiredAt.getDate() + durationDays);
        
        console.log('Extending membership:', {
          currentExpiredAt: currentExpiredAt?.toISOString(),
          baseDate: baseDate.toISOString(),
          durationDays,
          newExpiredAt: expiredAt.toISOString()
        });
      } else {
        // 新会员，从现在开始计算
        expiredAt = new Date();
        expiredAt.setDate(expiredAt.getDate() + durationDays);
      }

      if (existingMembership) {
        // 更新现有会员记录
        const { error: membershipError } = await client
          .from('user_memberships')
          .update({
            plan_id: planId,
            order_id: orderId,
            status: 'active',
            expired_at: expiredAt ? expiredAt.toISOString() : null,
            updated_at: new Date().toISOString(),
          })
          .eq('user_id', userId);

        if (membershipError) {
          console.error('Update membership error:', membershipError);
          return { success: false, error: membershipError.message };
        }
      } else {
        // 创建新会员记录
        const { error: membershipError } = await client
          .from('user_memberships')
          .insert({
            user_id: userId,
            plan_id: planId,
            order_id: orderId,
            status: 'active',
            expired_at: expiredAt ? expiredAt.toISOString() : null,
          });

        if (membershipError) {
          console.error('Create membership error:', membershipError);
          return { success: false, error: membershipError.message };
        }
      }
    } else if (metadata.post_id) {
      // 文章购买订单 - 创建购买记录
      const postId = metadata.post_id as string;
      const userId = order.user_id as string;

      const { error: purchaseError } = await client
        .from('post_purchases')
        .insert({
          user_id: userId,
          post_id: postId,
          order_id: orderId,
          price: order.amount,
          payment_method: paymentMethod,
          status: 'completed',
        });

      if (purchaseError) {
        console.error('Create purchase error:', purchaseError);
        return { success: false, error: purchaseError.message };
      }
    }

    return { success: true };
  } catch (error) {
    console.error('Handle payment success error:', error);
    return { 
      success: false, 
      error: error instanceof Error ? error.message : '处理支付失败' 
    };
  }
}

/**
 * 检查用户是否可以购买指定套餐
 * @param userId 用户ID
 * @param planId 套餐ID
 * @param durationDays 套餐有效期天数
 */
export async function checkCanPurchase(
  userId: string,
  planId: string,
  durationDays: number
): Promise<{ canPurchase: boolean; reason?: string }> {
  const client = getSupabaseClient();

  try {
    // 检查用户当前会员状态
    const { data: membership } = await client
      .from('user_memberships')
      .select('*, membership_plans(duration_days)')
      .eq('user_id', userId)
      .eq('status', 'active')
      .maybeSingle();

    if (!membership) {
      // 没有会员记录，可以购买
      return { canPurchase: true };
    }

    // 检查是否是永久会员
    const isCurrentLifetime = membership.expired_at === null;
    const isPurchasingLifetime = durationDays === 0;

    if (isCurrentLifetime) {
      // 已经是永久会员，不能再购买任何会员
      return { 
        canPurchase: false, 
        reason: '您已经是永久会员，无需再次购买' 
      };
    }

    if (isPurchasingLifetime) {
      // 非永久会员可以购买永久会员
      return { canPurchase: true };
    }

    // 普通会员可以续费
    return { canPurchase: true };
  } catch (error) {
    console.error('Check can purchase error:', error);
    return { canPurchase: false, reason: '检查会员状态失败' };
  }
}
