import { cookies } from 'next/headers';
import { SignJWT, jwtVerify } from 'jose';
import { getSupabaseClient } from '@/storage/database/supabase-client';
import bcrypt from 'bcryptjs';
import { User } from '@/storage/database/shared/schema';

const JWT_SECRET = process.env.JWT_SECRET || 'your-secret-key-change-in-production';

interface SessionData {
  userId: string;
  username: string;
  role: string;
  [key: string]: unknown;
}

// 密码哈希
export async function hashPassword(password: string): Promise<string> {
  return bcrypt.hash(password, 10);
}

// 验证密码
export async function verifyPassword(password: string, hash: string): Promise<boolean> {
  return bcrypt.compare(password, hash);
}

// 创建 Session Token
export async function createSessionToken(payload: SessionData): Promise<string> {
  const secret = new TextEncoder().encode(JWT_SECRET);
  return new SignJWT(payload)
    .setProtectedHeader({ alg: 'HS256' })
    .setIssuedAt()
    .setExpirationTime('7d')
    .sign(secret);
}

// 验证 Session Token
export async function verifySessionToken(token: string): Promise<SessionData | null> {
  try {
    const secret = new TextEncoder().encode(JWT_SECRET);
    const { payload } = await jwtVerify(token, secret);
    return {
      userId: payload.userId as string,
      username: payload.username as string,
      role: payload.role as string,
    };
  } catch {
    return null;
  }
}

// 获取当前用户
export async function getCurrentUser(): Promise<(SessionData & { email: string; display_name?: string }) | null> {
  const cookieStore = await cookies();
  const token = cookieStore.get('session')?.value;
  
  if (!token) return null;
  
  const session = await verifySessionToken(token);
  if (!session) return null;
  
  // 从数据库获取用户完整信息
  const client = getSupabaseClient();
  const { data, error } = await client
    .from('users')
    .select('id, username, email, role, display_name')
    .eq('id', session.userId)
    .maybeSingle();
  
  if (error || !data) return null;
  
  return {
    userId: data.id,
    username: data.username,
    email: data.email,
    role: data.role,
    display_name: data.display_name || undefined,
  };
}

// 检查是否是管理员
export async function isAdmin(): Promise<boolean> {
  const user = await getCurrentUser();
  return user?.role === 'admin';
}

// 登录
export async function login(username: string, password: string): Promise<{ success: boolean; error?: string }> {
  const client = getSupabaseClient();
  
  // 查找用户
  const { data: user, error } = await client
    .from('users')
    .select('*')
    .eq('username', username)
    .maybeSingle();
  
  if (error) {
    return { success: false, error: '数据库查询失败' };
  }
  
  if (!user) {
    return { success: false, error: '用户不存在' };
  }
  
  // 验证密码
  const isValid = await verifyPassword(password, user.password_hash);
  if (!isValid) {
    return { success: false, error: '密码错误' };
  }
  
  // 检查用户是否激活
  if (!user.is_active) {
    return { success: false, error: '账户已被禁用' };
  }
  
  // 创建 Session
  const token = await createSessionToken({
    userId: user.id,
    username: user.username,
    role: user.role,
  });
  
  const cookieStore = await cookies();
  cookieStore.set('session', token, {
    httpOnly: true,
    secure: process.env.NODE_ENV === 'production',
    sameSite: 'lax',
    maxAge: 60 * 60 * 24 * 7, // 7 天
    path: '/',
  });
  
  return { success: true };
}

// 登出
export async function logout(): Promise<void> {
  const cookieStore = await cookies();
  cookieStore.delete('session');
}
