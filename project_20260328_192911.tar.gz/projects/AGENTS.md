# WordPress风格博客系统

## 项目概览

基于 Next.js 16 和 Supabase 构建的WordPress风格博客系统，支持文章管理、分类管理、用户管理、支付接口配置、付费阅读、会员订阅及AI智能写作功能。

### 版本技术栈

- **Framework**: Next.js 16 (App Router)
- **Core**: React 19
- **Language**: TypeScript 5
- **UI 组件**: shadcn/ui (基于 Radix UI)
- **Styling**: Tailwind CSS 4
- **Database**: Supabase (PostgreSQL)
- **Auth**: JWT (jose) + bcrypt
- **Storage**: S3 对象存储 (coze-coding-dev-sdk)
- **LLM**: coze-coding-dev-sdk
- **Payment**: alipay-sdk 4.14.0

## 目录结构

```
├── public/                 # 静态资源
├── scripts/                # 构建与启动脚本
├── src/
│   ├── app/                # 页面路由与布局
│   │   ├── account/        # 用户账户页面（会员、订单）
│   │   ├── admin/          # 管理后台（仪表盘、文章、分类、标签、用户、会员、支付、设置）
│   │   ├── api/            # API接口
│   │   ├── category/       # 分类页面
│   │   ├── login/          # 登录页面
│   │   ├── membership/     # 会员订阅页面
│   │   ├── post/           # 文章详情页面
│   │   ├── posts/          # 文章列表页面
│   │   ├── register/       # 注册页面
│   │   ├── search/         # 搜索页面
│   │   └── tag/            # 标签页面
│   ├── components/ui/      # Shadcn UI 组件库
│   ├── components/         # 业务组件（评论、会员定价、付费内容保护等）
│   ├── hooks/              # 自定义 Hooks
│   ├── lib/                # 工具库（认证、支付等）
│   └── storage/            # 数据库配置和Schema
├── next.config.ts          # Next.js 配置
├── package.json            # 项目依赖管理
└── tsconfig.json           # TypeScript 配置
```

## API接口清单

### 认证接口 (`/api/auth`)
- `POST /api/auth/register` - 用户注册
- `POST /api/auth/login` - 用户登录
- `POST /api/auth/logout` - 用户登出
- `GET /api/auth/me` - 获取当前用户信息

### 文章接口 (`/api/posts`)
- `GET /api/posts` - 获取文章列表
- `POST /api/posts` - 创建文章
- `GET /api/posts/[id]` - 获取文章详情
- `PUT /api/posts/[id]` - 更新文章
- `DELETE /api/posts/[id]` - 删除文章
- `GET /api/posts/[id]/access` - 检查文章访问权限

### 分类接口 (`/api/categories`)
- `GET /api/categories` - 获取分类列表
- `POST /api/categories` - 创建分类
- `PUT /api/categories/[id]` - 更新分类
- `DELETE /api/categories/[id]` - 删除分类

### 标签接口 (`/api/tags`)
- `GET /api/tags` - 获取标签列表
- `POST /api/tags` - 创建标签
- `PUT /api/tags/[id]` - 更新标签
- `DELETE /api/tags/[id]` - 删除标签

### 评论接口 (`/api/comments`)
- `GET /api/comments` - 获取评论列表
- `POST /api/comments` - 创建评论
- `PUT /api/comments/[id]` - 更新评论
- `DELETE /api/comments/[id]` - 删除评论

### 用户接口 (`/api/users`)
- `GET /api/users` - 获取用户列表（管理员）
- `POST /api/users` - 创建用户（管理员）
- `PUT /api/users/[id]` - 更新用户（管理员）
- `DELETE /api/users/[id]` - 删除用户（管理员）

### 会员接口
- `GET /api/membership-plans` - 获取会员套餐列表
- `POST /api/membership-plans` - 创建会员套餐（管理员）
- `GET /api/user/membership` - 获取当前用户会员信息
- `GET /api/user-memberships` - 获取用户会员列表（管理员）

### 订单接口 (`/api/orders`)
- `GET /api/orders` - 获取订单列表
- `POST /api/orders` - 创建订单
- `GET /api/orders/[id]` - 获取订单详情

### 支付接口
- `POST /api/payment/alipay/create` - 创建支付宝支付订单
- `POST /api/payment/alipay/query` - 查询支付宝订单状态
- `POST /api/payment/alipay/notify` - 支付宝回调通知
- `GET /api/payment-configs` - 获取支付配置

### 其他接口
- `GET /api/settings` - 获取网站设置
- `POST /api/settings` - 更新网站设置（管理员）
- `GET /api/search` - 搜索文章
- `POST /api/upload` - 上传文件（需要登录）
- `GET /api/media` - 获取媒体列表（管理员）
- `GET /api/media/[id]` - 获取单个媒体文件
- `DELETE /api/media/[id]` - 删除媒体文件（管理员）
- `POST /api/ai-write` - AI写作（流式输出）
- `POST /api/ai-seo` - AI SEO优化（流式输出）
- `GET /api/dashboard/stats` - 获取仪表盘统计（管理员）
- `GET /api/local-articles` - 获取本地草稿文章
- `POST /api/admin/cleanup-users` - 清理非管理员用户
- `GET /api/ai-tasks` - 获取AI自动任务列表
- `POST /api/ai-tasks` - 创建AI自动任务
- `GET /api/ai-tasks/[id]` - 获取任务详情
- `PUT /api/ai-tasks/[id]` - 更新任务
- `DELETE /api/ai-tasks/[id]` - 删除任务
- `POST /api/ai-tasks/[id]/action` - 任务操作（暂停/恢复/执行）
- `GET /api/cron/ai-tasks` - 定时检查执行任务
- `GET /api/ai-models` - 获取AI模型配置列表
- `POST /api/ai-models` - 创建/更新AI模型配置
- `DELETE /api/ai-models` - 批量删除AI模型配置
- `GET /api/ai-models/[id]` - 获取单个模型详情
- `PUT /api/ai-models/[id]` - 更新模型配置
- `DELETE /api/ai-models/[id]` - 删除单个模型
- `POST /api/ai-models/[id]/action` - 模型操作（设为默认/测试）
- `GET /api/init-ai-models` - 初始化AI模型配置表

## 核心功能

### 1. 用户认证
- JWT Session认证机制
- 密码bcrypt加密存储
- 角色权限控制（admin, editor, author, subscriber）

### 2. 文章管理
- Markdown文章编辑
- 分类和标签管理
- 文章状态（草稿、已发布）
- SEO设置（标题、描述、关键词）
- 付费文章设置

### 3. 会员系统
- 两种付费模式：会员订阅（全站免费）和单篇购买
- 永久会员限制：购买后无法再购买任何会员套餐
- 普通会员续费：在现有到期时间基础上顺延

### 4. 支付功能
- 支付宝扫码支付（当面付）
- 订单状态轮询机制（每3秒）
- 支付成功自动跳转

### 5. AI写作
- 流式输出支持
- 支持自定义主题、风格、长度
- 本地草稿保存

### 6. AI SEO优化
- 基于文章标题、内容、分类和标签自动生成SEO元数据
- 流式输出支持，实时显示生成结果
- 一键应用优化结果到文章设置

### 7. AI自动任务
- 定时自动写作和发布文章
- 支持多种文章类型（水果、花草种植、蔬菜种植、园艺技术）
- 可配置写作风格、文章长度、发布频率
- 自动生成封面图并保存到媒体库
- 支持暂停/恢复/手动执行任务
- 执行日志记录和查看

### 8. AI模型配置
- 支持配置多个AI模型提供商（豆包、DeepSeek、Kimi、OpenAI、自定义）
- 支持大语言模型（LLM）和图片生成模型配置
- 动态模型选择，优先使用默认模型或按优先级选择
- 模型测试功能，验证配置是否正确
- API密钥安全存储
- 模型启用/禁用控制

## 包管理规范

**仅允许使用 pnpm** 作为包管理器，**严禁使用 npm 或 yarn**。

常用命令：
- 安装依赖：`pnpm add <package>`
- 安装开发依赖：`pnpm add -D <package>`
- 安装所有依赖：`pnpm install`
- 移除依赖：`pnpm remove <package>`

## 开发规范

- **Hydration 错误预防**：严禁在 JSX 渲染逻辑中直接使用 typeof window、Date.now()、Math.random() 等动态数据。必须使用 'use client' 并配合 useEffect + useState 确保动态内容仅在客户端挂载后渲染；同时严禁非法 HTML 嵌套（如 <p> 嵌套 <div>）。
- **API路由规范**：所有需要认证的接口都应使用 `getCurrentUser()` 获取用户信息，并根据角色进行权限控制。
- **流式响应**：AI写作等长时间操作使用 SSE 协议返回流式响应。

## UI 设计与组件规范

- 模板默认预装核心组件库 `shadcn/ui`，位于`src/components/ui/`目录下
- Next.js 项目**必须默认**采用 shadcn/ui 组件、风格和规范

## 环境变量配置

### 必需环境变量

| 变量名 | 说明 | 示例值 |
|--------|------|--------|
| `COZE_SUPABASE_URL` | Supabase 项目 URL | `https://xxx.supabase.co` |
| `COZE_SUPABASE_ANON_KEY` | Supabase 匿名密钥 | `eyJhbGciOiJ...` |
| `JWT_SECRET` | JWT 签名密钥 | `your-secure-secret` |
| `COZE_BUCKET_ENDPOINT_URL` | 对象存储端点 | `https://bucket.tos-cn-beijing.volces.com` |
| `COZE_BUCKET_NAME` | 存储桶名称 | `my-bucket` |

### 系统环境变量（沙箱自动注入）

| 变量名 | 说明 | 默认值 |
|--------|------|--------|
| `COZE_WORKSPACE_PATH` | 项目工作目录 | `/workspace/projects/` |
| `COZE_PROJECT_DOMAIN_DEFAULT` | 对外访问域名 | `https://xxx.dev.coze.site` |
| `DEPLOY_RUN_PORT` | 服务监听端口 | `5000` |
| `COZE_PROJECT_ENV` | 运行环境 | `DEV` / `PROD` |

### 配置方式

**开发环境**：在项目根目录创建 `.env.local` 文件

```env
COZE_SUPABASE_URL=https://your-project.supabase.co
COZE_SUPABASE_ANON_KEY=your-anon-key
JWT_SECRET=your-jwt-secret
COZE_BUCKET_ENDPOINT_URL=https://your-bucket.tos-cn-beijing.volces.com
COZE_BUCKET_NAME=your-bucket-name
```

**生产环境**：在平台控制台或 Docker 启动参数中配置

## 启动步骤

### 开发环境

```bash
# 1. 安装依赖
pnpm install

# 2. 配置环境变量（创建 .env.local）

# 3. 启动开发服务器
coze dev
# 或
pnpm dev

# 服务运行在 http://localhost:5000
```

### 生产环境

```bash
# 1. 构建
coze build
# 或
pnpm build

# 2. 启动生产服务
coze start
# 或
pnpm start

# 服务运行在 http://localhost:5000
```

## 部署指南

### 方式一：Coze 平台部署（推荐）

1. **构建命令**：`bash ./scripts/build.sh`
2. **启动命令**：`bash ./scripts/start.sh`
3. **端口**：5000
4. **依赖**：nodejs-24, git

配置 `.coze` 文件已预设好，直接部署即可。

### 方式二：Docker 部署

```dockerfile
FROM node:20-alpine
WORKDIR /app
RUN npm install -g pnpm
COPY package.json pnpm-lock.yaml ./
RUN pnpm install --frozen-lockfile
COPY . .
RUN pnpm build
EXPOSE 5000
CMD ["node", "dist/server.js"]
```

```bash
docker build -t blog-system .
docker run -d -p 5000:5000 \
  -e COZE_SUPABASE_URL=xxx \
  -e COZE_SUPABASE_ANON_KEY=xxx \
  -e JWT_SECRET=xxx \
  -e COZE_BUCKET_ENDPOINT_URL=xxx \
  -e COZE_BUCKET_NAME=xxx \
  blog-system
```

### 方式三：PM2 部署

```bash
# 安装 PM2
npm install -g pm2

# 构建项目
pnpm build

# 启动
PORT=5000 pm2 start dist/server.js --name blog

# 开机自启
pm2 startup
pm2 save
```

### 方式四：Vercel 部署

⚠️ 注意：本项目使用自定义服务器，部分功能在 Vercel 上可能受限。

1. 导入 Git 仓库
2. 配置环境变量
3. 自动部署

## 数据库表结构

- `users` - 用户表
- `posts` - 文章表
- `categories` - 分类表
- `tags` - 标签表
- `post_tags` - 文章标签关联表
- `comments` - 评论表
- `membership_plans` - 会员套餐表
- `user_memberships` - 用户会员表
- `orders` - 订单表
- `post_purchases` - 文章购买记录表
- `payment_configs` - 支付配置表
- `settings` - 网站设置表
- `media` - 媒体文件表
- `ai_scheduled_tasks` - AI自动任务配置表
- `ai_task_logs` - AI任务执行日志表


